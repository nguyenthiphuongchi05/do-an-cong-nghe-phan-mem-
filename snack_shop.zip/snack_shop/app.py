from datetime import datetime

from flask import Flask, send_from_directory, render_template, request, flash, redirect, url_for, jsonify
from flask_wtf.csrf import CSRFError
from flask_login import current_user, logout_user

from config import Config
from extensions import db, login_manager, mail, csrf
from utils.helpers import format_vnd, order_status_label, order_status_class
from utils.banks import get_bank, transfer_content, qr_payload, DEMO_PAYMENT, DEMO_NOTICE
from utils.branch import init_request_context, active_branches, current_branch
from utils.qr import make_qr_svg
from utils.timeutil import vn_dt_filter, vn_now


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Khởi tạo extension
    db.init_app(app)
    login_manager.init_app(app)
    mail.init_app(app)
    csrf.init_app(app)

    # Đăng ký blueprint (routes)
    from routes.home import home_bp
    from routes.auth import auth_bp
    from routes.product import product_bp
    from routes.cart import cart_bp
    from routes.order import order_bp
    from routes.admin import admin_bp
    from routes.voucher import voucher_bp
    from routes.wishlist import wishlist_bp
    from routes.receipts import receipt_bp
    from routes.reports import report_bp
    from routes.system import system_bp
    from routes.branch import branch_bp
    from routes.transfer import transfer_bp
    from routes.adjust import adjust_bp
    from routes.team import team_bp

    for bp in (home_bp, auth_bp, product_bp, cart_bp, order_bp, admin_bp, voucher_bp, wishlist_bp,
               receipt_bp, report_bp, system_bp, branch_bp, transfer_bp, adjust_bp, team_bp):
        app.register_blueprint(bp)

    # Serve ảnh upload (nằm ngoài static/, nên Flask không tự phục vụ -> cần route riêng)
    @app.route("/uploads/products/<path:filename>")
    def uploaded_product_image(filename):
        return send_from_directory(app.config["UPLOAD_FOLDER"], filename)

    @app.route("/uploads/system/<path:filename>")
    def uploaded_system_file(filename):
        return send_from_directory(app.config["SYSTEM_UPLOAD_FOLDER"], filename)

    # Cho phép dùng format_vnd(...) trực tiếp trong mọi file .html mà không cần import
    app.jinja_env.filters["vnd"] = format_vnd
    app.jinja_env.filters["vn_dt"] = vn_dt_filter
    app.jinja_env.globals["get_bank"] = get_bank
    app.jinja_env.globals["transfer_content"] = transfer_content
    app.jinja_env.globals["bank_qr_svg"] = lambda order, bank: make_qr_svg(qr_payload(order, bank), module=5)
    app.jinja_env.globals["DEMO_PAYMENT"] = DEMO_PAYMENT
    app.jinja_env.globals["DEMO_NOTICE"] = DEMO_NOTICE
    app.jinja_env.globals["order_status_label"] = order_status_label
    app.jinja_env.globals["order_status_class"] = order_status_class

    # Tạo bảng DB nếu chưa có (dùng cho SQLite lúc dev; với MySQL nên dùng migration)
    with app.app_context():
        db.create_all()
        from utils.migrate import upgrade_schema
        upgrade_schema()  # thêm cột mới / chuyển is_admin,is_staff -> role cho CSDL cũ
        from utils.branch import ensure_default_branch
        ensure_default_branch()  # luôn có ít nhất 1 chi nhánh

    @app.context_processor
    def inject_cart_count():
        from routes.cart import _cart_count
        if current_user.is_authenticated:
            return dict(cart_count=_cart_count(current_user.id))
        return dict(cart_count=0)

    @app.context_processor
    def inject_store():
        """Thông tin cửa hàng (tên, logo, liên hệ) + nhãn vai trò dùng chung trong mọi template."""
        from models.setting import get_all_settings, DEFAULT_SETTINGS
        from models.user import ROLE_LABELS
        try:
            store = get_all_settings()
        except Exception:  # noqa: BLE001 - DB chưa sẵn sàng (vd lúc khôi phục)
            store = dict(DEFAULT_SETTINGS)
        try:
            branches = active_branches()
            current_branch_obj = current_branch()
        except Exception:  # noqa: BLE001
            branches, current_branch_obj = [], None
        if current_branch_obj is not None:
            # Đang chọn một chi nhánh: hiện địa chỉ/SĐT của chi nhánh đó (thiếu thì dùng cấu hình chung)
            store = dict(store)
            if current_branch_obj.address:
                store["store_address"] = current_branch_obj.address
            if current_branch_obj.phone:
                store["store_phone"] = current_branch_obj.phone
        return dict(store=store, ROLE_LABELS=ROLE_LABELS, now=vn_now(),
                    branches=branches, current_branch=current_branch_obj)

    @app.before_request
    def enforce_account_and_maintenance():
        """1) Đăng xuất ngay tài khoản bị khóa. 2) Chế độ bảo trì: chỉ nhân sự nội bộ vào được."""
        if request.endpoint in (None, "static"):
            return None
        init_request_context()  # chi nhánh đang dùng + phạm vi dữ liệu theo chi nhánh
        if current_user.is_authenticated and current_user.is_locked:
            logout_user()
            flash("Tài khoản của bạn đã bị khóa. Vui lòng liên hệ quản trị viên.", "danger")
            return redirect(url_for("auth.login"))

        from models.setting import get_setting
        if get_setting("maintenance_mode") == "1":
            allowed = request.endpoint in ("auth.login", "auth.logout", "uploaded_system_file")
            if not allowed and not (current_user.is_authenticated and current_user.is_backoffice):
                return render_template("errors/maintenance.html",
                                       message=get_setting("maintenance_message")), 503
        return None

    @app.after_request
    def security_headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        resp.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; font-src 'self' https://cdn.jsdelivr.net data:; "
            "img-src 'self' data: https:; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; "
            "form-action 'self'; object-src 'none'")
        resp.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if request.endpoint not in (None, "static") and current_user.is_authenticated:
            resp.headers.setdefault("Cache-Control", "no-store")  # không để trình duyệt lưu trang đã đăng nhập
        return resp

    @app.errorhandler(CSRFError)
    def csrf_failed(error):
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify(ok=False, message="Phiên làm việc đã hết hạn, vui lòng tải lại trang."), 400
        flash("Phiên làm việc đã hết hạn hoặc yêu cầu không hợp lệ. Vui lòng thử lại.", "danger")
        ref = request.referrer or ""
        return redirect(ref if ref.startswith(request.host_url) else url_for("home.index"))

    if (not app.config.get("TESTING") and app.config["SECRET_KEY"] == "chuoi-bi-mat-mac-dinh-khong-an-toan"):
        app.logger.warning("SECRET_KEY đang dùng giá trị mặc định - hãy đặt SECRET_KEY ngẫu nhiên trong .env trước khi triển khai.")

    @app.errorhandler(401)
    def unauthorized(error):
        flash("Vui lòng đăng nhập để tiếp tục.", "warning")
        return redirect(url_for("auth.login", next=request.path))

    @app.errorhandler(403)
    def forbidden(error):
        from utils.audit import log_event
        log_event("access_denied", f"Bị từ chối truy cập {request.method} {request.path}",
                  category="security", level="warning")
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(error):
        return render_template("errors/404.html"), 404

    @app.errorhandler(500)
    def server_error(error):
        from utils.audit import log_event
        db.session.rollback()
        original = getattr(error, "original_exception", None)
        log_event("server_error", f"Lỗi 500 tại {request.method} {request.path}: {original!r}",
                  category="error", level="error")
        return render_template("errors/500.html"), 500

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=app.config["DEBUG"])
