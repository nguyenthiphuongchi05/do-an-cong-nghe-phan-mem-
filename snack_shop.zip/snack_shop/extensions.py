from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_mail import Mail
from flask_wtf.csrf import CSRFProtect

# Khởi tạo ở đây (chưa gắn app) để models/ và app.py đều import được
# mà không bị lỗi import vòng (circular import)
db = SQLAlchemy()
# Mọi cột chuỗi dùng kiểu Unicode (lưu đúng tiếng Việt có dấu),
# trên SQLite/MySQL không khác gì VARCHAR/TEXT thường.
db.String = db.Unicode
db.Text = db.UnicodeText
login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.login_message = "Vui lòng đăng nhập để tiếp tục."
login_manager.login_message_category = "warning"
mail = Mail()
csrf = CSRFProtect()  # chống CSRF cho mọi request POST/PUT/DELETE
