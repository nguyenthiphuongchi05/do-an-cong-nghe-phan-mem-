# Snack Shop 🍿

Web bán đồ ăn vặt xây bằng Flask. Có sẵn: trang chủ, danh sách/chi tiết sản phẩm (bấm ảnh
hoặc tên là vào thẳng trang giới thiệu), đánh giá sao + bình luận sản phẩm, sản phẩm yêu
thích (wishlist), tìm kiếm gợi ý (autocomplete), giỏ hàng, thanh toán (COD / chuyển khoản
ngân hàng có chọn ngân hàng kèm huy hiệu), voucher (áp dụng nhiều mã cùng lúc ngay tại
trang thanh toán không cần rời trang, giới hạn 1 lần/người), gửi email xác nhận đơn hàng,
lịch sử + chi tiết đơn hàng, đăng nhập/đăng ký, và trang quản trị (CRUD sản phẩm/danh
mục/voucher, quản lý đơn hàng, xác nhận đã nhận tiền chuyển khoản, phân quyền 4 vai trò, nhập hàng, nhật ký hệ thống, thống kê doanh thu có biểu đồ).

## 1. Cài đặt

```bash
# Tạo môi trường ảo (khuyến nghị)
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# Cài thư viện
pip install -r requirements.txt

# Tạo file .env từ mẫu
cp .env.example .env
```

Dự án dùng **SQLite**: không cần cài DB server, file dữ liệu `snack_shop.db` tự tạo ở thư mục dự án khi
chạy `python seed.py`. Email là **tùy chọn** — để trống `MAIL_USERNAME` trong `.env` thì
app vẫn chạy bình thường, chỉ là không gửi được email xác nhận đơn hàng.

## 2. Tạo dữ liệu mẫu (tài khoản admin + sản phẩm + voucher)

```bash
python seed.py
```

Sau khi chạy, bạn sẽ có:
- Tài khoản **Admin**: **admin@gmail.com** / **admin123**
- Tài khoản **Quản lý chuỗi**: **quanlychuoi@snackshop.vn** / **quanly123** (không thuộc chi nhánh nào, xem tất cả)
- Tài khoản **Quản lý chi nhánh**: **quanly@snackshop.vn** / **quanly123** (Chi nhánh Hà Nội; xem thêm mục 3e cho 2 chi nhánh còn lại)
- Tài khoản **Nhân viên**: **nhanvien@snackshop.vn** / **nhanvien123** (và nhanvien2@snackshop.vn cùng mật khẩu)
- Tài khoản khách demo (đã có sẵn vài đánh giá mẫu): **khach@demo.vn** / **demo123**
- 4 danh mục, 4 nhà cung cấp, 72 sản phẩm mẫu, đều có ảnh thật (Snack 20, Nước Giải Khát 20, Bánh Tráng 16, Đồ Khô 16), 3 voucher mẫu (`SALE10`, `FREESHIP`, `GIAM20K`)

Seed cũng tạo sẵn vài phiếu nhập và đơn hàng mẫu để xem báo cáo. **Hãy đổi mật khẩu các tài khoản mẫu khi triển khai thật.**

## 3. Chạy dự án

```bash
python app.py
```

Mở trình duyệt tại: http://127.0.0.1:5000

- Khu vực nội bộ: http://127.0.0.1:5000/admin — admin / quản lý / nhân viên đăng nhập xong tự được đưa vào đây, menu hiển thị theo quyền
- Đăng ký tài khoản khách hàng mới tại: http://127.0.0.1:5000/tai-khoan/dang-ky

## 3b. Phân quyền 5 vai trò

Vai trò lưu ở cột `users.role` (`admin`, `chain_manager`, `manager`, `staff`, `customer`). Ma trận quyền nằm ở
`utils/permissions.py`; route dùng `@permission_required("...")`, menu dùng `current_user.has_permission("...")`.
Trang **Admin → Tài khoản & phân quyền** hiển thị bảng này. Mọi giới hạn đều được kiểm tra ở **server** (không chỉ ẩn nút).

Nguyên tắc: mỗi việc có **một** chủ rõ ràng, quyền chồng nhau ở mức tối thiểu.

| Vai trò | Phạm vi | Được làm | Không được làm |
|---|---|---|---|
| **Admin** | Hệ thống | Tạo/sửa mọi tài khoản, phân quyền, khóa/mở khóa, đặt lại mật khẩu, gỡ 2FA; quản lý chi nhánh; cấu hình, sao lưu, nhật ký, bảo trì | Mọi nghiệp vụ kinh doanh: sản phẩm, đơn, kho, báo cáo (403) |
| **Quản lý chuỗi** | Cả chuỗi, không thuộc chi nhánh nào | Danh mục, sản phẩm, **giá chung**, nhà cung cấp, voucher (mọi phạm vi); **báo cáo gộp mọi chi nhánh** (hoặc chọn từng chi nhánh); hiệu suất nhân viên; **duyệt phiếu điều chỉnh kho** (đặc biệt phiếu của quản lý chi nhánh); tạo/quản lý **quản lý chi nhánh và nhân viên** ở mọi chi nhánh; xem đơn, tồn kho, khách hàng | Bán hàng, xử lý đơn, lập phiếu nhập/điều chỉnh/chuyển kho (việc của chi nhánh); tạo Admin hoặc Quản lý chuỗi khác |
| **Quản lý chi nhánh** | Đúng **một** chi nhánh (bắt buộc) | Đơn hàng, bán tại quầy, yêu cầu đổi/hủy; lập/phân công/hủy phiếu nhập; **chuyển kho** giữa chi nhánh; lập và **duyệt phiếu điều chỉnh kho của nhân viên**; tạo/khóa/đặt lại mật khẩu **nhân viên của chi nhánh mình**; voucher riêng chi nhánh; báo cáo và hiệu suất của chi nhánh mình; xem sản phẩm | **Sửa sản phẩm/giá/danh mục/nhà cung cấp** (chỉ xem), thấy dữ liệu chi nhánh khác, tự duyệt phiếu của chính mình, tạo quản lý/admin, đổi chi nhánh của nhân viên |
| **Nhân viên** | Đúng một chi nhánh (bắt buộc) | Tra cứu sản phẩm & tồn kho; xác nhận/cập nhật đơn & giao hàng; bán tại quầy; ghi nhận nhập hàng được phân công; xử lý yêu cầu đổi/hủy; tra cứu khách hàng; **lập phiếu điều chỉnh kho** (chờ quản lý duyệt) | Duyệt phiếu, sửa sản phẩm/giá/voucher, báo cáo, quản lý nhân sự |
| **Khách hàng** | Chi nhánh đang chọn | Đăng ký/đăng nhập; hồ sơ; xem/tìm sản phẩm; giỏ hàng, đặt hàng, voucher; theo dõi đơn, đánh giá; yêu cầu hủy/đổi đơn | Mọi thứ trong `/admin`; chỉ thấy dữ liệu của chính mình |

**Tồn kho không còn sửa trực tiếp** (đã bỏ ô "Tồn kho" ở form sản phẩm). Tồn chỉ đổi qua: phiếu nhập, bán hàng,
chuyển kho, hoặc **phiếu điều chỉnh kho** (`/admin/dieu-chinh-kho`): nhân viên/quản lý chi nhánh nhập số đếm thực tế + lý do →
hệ thống tính chênh lệch (ví dụ tồn 50, thực tế 45, chênh -5) → phiếu chờ duyệt. Phiếu của **nhân viên** do **quản lý chi nhánh**
duyệt; phiếu của **quản lý chi nhánh** do **quản lý chuỗi** duyệt; **không ai tự duyệt phiếu của mình**. Khi duyệt, đúng phần chênh lệch
được áp vào tồn hiện tại (nguyên tử, không để tồn âm; mỗi phiếu chỉ xử lý một lần); từ chối phải ghi lý do. Có lịch sử đầy đủ và được tính vào
đối soát sổ kho.

**Nhân sự** (`/admin/nhan-su`): quản lý chi nhánh chỉ tạo nhân viên của chi nhánh mình; quản lý chuỗi tạo quản lý chi nhánh và nhân viên
ở mọi chi nhánh. Vai trò và chi nhánh gửi từ form luôn bị đối chiếu lại với quyền thật; không thể tạo/sửa Admin, Quản lý chuỗi, hay chính mình;
khi sửa chỉ đổi được tên, số điện thoại (và chi nhánh, nếu là quản lý chuỗi), không đổi vai trò hay email. Admin vẫn quản lý mọi tài khoản
tại *Hệ thống → Tài khoản & phân quyền* (quản lý chi nhánh và nhân viên bắt buộc có chi nhánh; quản lý chuỗi không có).

Các quy tắc an toàn khác: đăng ký công khai luôn tạo khách hàng; admin không thể tự khóa mình / tự đổi vai trò / hạ admin cuối cùng; tài khoản
bị khóa bị đăng xuất ngay ở request kế tiếp; mỗi lần bị từ chối truy cập (403) đều ghi vào nhật ký.

## 3c. Các bảng mới

- **`phieu_nhap` (`PhieuNhap`) / `chi_tiet_phieu_nhap` (`ChiTietPhieuNhap`)** — quản lý lập phiếu
  (nhà cung cấp, dòng hàng, giá nhập, hạn dùng) và phân công nhân viên → nhân viên ghi nhận số lượng
  thực nhận → hệ thống **cộng tồn kho** và cập nhật **giá vốn** sản phẩm (dùng tính lợi nhuận).
  Trạng thái: `pending` → `completed` / `cancelled`. Phiếu đã nhập kho không sửa/hủy được.
- **`nhat_ky_he_thong` (`NhatKyHeThong`)** — nhật ký hoạt động & sự kiện bảo trì: đăng nhập (kể cả sai),
  tài khoản/phân quyền, cấu hình, sao lưu/khôi phục, bảo trì, đơn hàng, nhập hàng, truy cập bị từ chối,
  lỗi 500. Lưu snapshot email + vai trò + IP. Xem/lọc/phân trang tại *Admin → Nhật ký hoạt động*.
- **`cau_hinh_he_thong`** — cấu hình key-value (tên, logo, địa chỉ, hotline, chế độ bảo trì).
- Cột mới: `users.role/is_locked/last_login_at` (thay `is_admin`/`is_staff`), `products.cost_price`,
  `order_items.cost_price`, `orders.channel/handled_by_id/completed_at/request_*`.

CSDL SQLite cũ tự được nâng cấp khi khởi động (`utils/migrate.py`: thêm cột, chuyển `is_admin`/`is_staff`
sang `role`).

## 3d. Một số chức năng đáng chú ý

- **Bán tại quầy** (`/admin/ban-hang`): tạo đơn `channel=counter`, trừ kho nguyên tử, hoàn thành ngay,
  in hóa đơn `/admin/don-hang/<mã>/hoa-don`. Khách vãng lai dùng tài khoản hệ thống `khachle@snackshop.local`
  (bị khóa, không đăng nhập được, ẩn khỏi danh sách khách hàng).
- **Luồng đơn hàng** chặt: `pending → confirmed → shipping → completed`, hủy được trước khi hoàn thành
  (hoàn tồn kho); đơn đã hủy/hoàn thành không đổi lại. Đơn COD hoàn thành tự tính là đã thu tiền.
- **Yêu cầu đổi/hủy** của khách: hủy khi đơn chưa giao; đổi trong 7 ngày sau khi hoàn thành. Nhân viên
  chấp nhận (hủy → hoàn kho) hoặc từ chối (bắt buộc ghi lý do). Nếu đã nhận tiền chuyển khoản, hệ thống nhắc
  hoàn tiền thủ công.
- **Hiệu suất nhân viên**: đơn xử lý/hoàn thành/hủy, tỉ lệ hoàn thành, bán tại quầy, doanh thu, phiếu nhập
  đã ghi nhận, yêu cầu đổi/hủy đã xử lý. Các báo cáo đều lọc theo ngày và xuất CSV (`?format=csv`).
- **Lợi nhuận gộp** = (giá bán − giá vốn) × SL, chỉ tính các dòng có giá vốn.
- **Hàng gần hết hạn**: theo dõi theo **lô nhập** (hạn dùng ghi trên dòng phiếu nhập), cảnh báo trong 30 ngày;
  tồn kho không tách theo từng lô nên "tồn hiện tại" là tổng của sản phẩm.
- **Sao lưu/khôi phục** (SQLite): dùng sqlite3 backup API, file ở `backups/`; khôi phục cần gõ `KHOI PHUC`
  và tự tạo bản `truoc-khoi-phuc-*` trước.
- **Chế độ bảo trì**: khách thấy trang 503, nhân sự nội bộ vẫn làm việc bình thường.

## 3e. Nhiều chi nhánh (3 chi nhánh)

- Bảng `chi_nhanh` và `ton_kho` (tồn kho **riêng từng chi nhánh**, duy nhất theo sản phẩm + chi nhánh).
  `Product.stock` là thuộc tính tính theo chi nhánh đang chọn (không chọn = tổng các chi nhánh).
- **Khách hàng** chọn chi nhánh ở thanh trên cùng; giá, tồn kho, đặt hàng theo chi nhánh đó.
- **Quản lý chi nhánh/Nhân viên** thuộc đúng một chi nhánh và chỉ thấy đơn, phiếu nhập, báo cáo của chi nhánh mình.
  **Quản lý chuỗi** (không thuộc chi nhánh nào) chọn xem từng chi nhánh hoặc "Tất cả".
- Admin quản lý chi nhánh tại `/admin/chi-nhanh` (thêm/sửa/ngừng hoạt động; không được ngừng chi nhánh cuối cùng).
- Tài khoản mẫu sau `seed.py` (mật khẩu `quanly123` / `nhanvien123`):
  CN01: quanly@, nhanvien@, nhanvien2@ · CN02: quanly2@, nhanvien3@, nhanvien4@ · CN03: quanly3@, nhanvien5@, nhanvien6@
  (đuôi `@snackshop.vn`). Admin: `admin@gmail.com` / `admin123`.
- **Chuyển kho** (`/admin/chuyen-kho`, quyền Quản lý), có bước nhận hàng: chi nhánh gửi lập phiếu (`CK...`) thì bị **trừ kho ngay**,
  phiếu ở trạng thái *Đang chuyển*; chi nhánh nhận bấm **Đã nhận** thì mới được **cộng kho**. Chi nhánh gửi có thể *Thu hồi*, chi nhánh
  nhận có thể *Từ chối* (bắt buộc ghi lý do): hàng hoàn lại kho chi nhánh gửi. Mỗi phiếu chỉ xử lý một lần (cập nhật có điều kiện).
  Nhân viên và Admin không có quyền này.
- **Voucher theo chi nhánh**: voucher có phạm vi *Toàn hệ thống* hoặc *Chỉ một chi nhánh* (ví dụ `HANOI15`, `HCM15`, `NAMDINH15`).
  Khách chỉ thấy và dùng được mã của chi nhánh đang chọn. Quản lý gán chi nhánh chỉ thấy mã toàn hệ thống + mã chi nhánh mình, chỉ
  tạo / sửa / xóa mã của chi nhánh mình (mã toàn hệ thống chỉ xem); quản lý chưa gán chi nhánh quản lý được tất cả. Giá bán vẫn dùng chung.

## 3f. Bảo mật

- **CSRF**: bật cho toàn bộ ứng dụng (Flask-WTF `CSRFProtect`). Mọi form POST có `csrf_token`, các lệnh `fetch` gửi header
  `X-CSRFToken` lấy từ thẻ `<meta name="csrf-token">`. Đăng xuất là POST.
- **Chính sách mật khẩu** (`utils/password_policy.py`): tối thiểu 8 ký tự, có cả chữ và số, không nằm trong danh sách mật khẩu
  phổ biến / mặc định, không trùng phần tên trước `@` của email. Áp dụng khi đăng ký, đổi mật khẩu, tạo / sửa / đặt lại mật khẩu
  tài khoản nội bộ (mật khẩu tạm do hệ thống sinh luôn đạt chính sách). Tài khoản nội bộ còn dùng mật khẩu mặc định của dữ liệu
  mẫu (`admin123`, `quanly123`...) sẽ thấy banner nhắc đổi ngay trong khu quản trị.
- **Xác thực hai lớp (TOTP)**: tùy chọn cho mọi tài khoản tại *Thông tin cá nhân → Xác thực hai lớp* (Google/Microsoft
  Authenticator, nhập khóa thiết lập). Khi bật, đăng nhập cần thêm mã 6 số. Mã sai nhiều lần bị khóa tạm như đăng nhập sai.
  Admin gỡ 2FA cho người mất điện thoại ở trang tài khoản. Mã TOTP viết bằng thư viện chuẩn (`utils/totp.py`, kiểm theo vector RFC 6238).
- **Chống dò mật khẩu**: sai quá `LOGIN_MAX_FAILURES` (mặc định 5) lần trong `LOGIN_LOCK_MINUTES` (15 phút) thì tạm chặn email đó;
  một IP sai quá `LOGIN_MAX_FAILURES_PER_IP` (20) lần cũng bị chặn (HTTP 429), có ghi nhật ký. Chỉ tin `X-Forwarded-For` khi đặt
  `TRUST_PROXY_HEADERS=1` (chạy sau Nginx), nếu không dùng IP kết nối trực tiếp.
- **Cookie phiên**: `HttpOnly`, `SameSite=Lax`; khi chạy HTTPS đặt `SESSION_COOKIE_SECURE=1` trong `.env`.
- **Header**: `Content-Security-Policy` (chỉ nạp script / style từ chính site và cdn.jsdelivr.net, chặn nhúng khung, `object-src 'none'`,
  `form-action 'self'`), `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`; trang đã đăng nhập `no-store`.
  CSP còn cho phép script / style nhúng trong trang (`'unsafe-inline'`) vì giao diện hiện dùng nhiều đoạn nhúng; muốn chặt hơn cần chuyển
  chúng ra file riêng.
- **Khác**: mật khẩu băm (werkzeug), phân quyền theo vai trò ở từng route, chống open redirect (`next`), upload ảnh chỉ nhận
  png/jpg/jpeg/webp, đổi tên ngẫu nhiên và giới hạn 2MB, truy vấn qua ORM (không nối chuỗi SQL).
- **Trước khi triển khai**: đặt `SECRET_KEY` ngẫu nhiên trong `.env` (app cảnh báo nếu còn giá trị mặc định), bật HTTPS,
  tắt `FLASK_DEBUG`, đặt thêm Nginx (giới hạn tốc độ theo IP ở tầng web).

## 4. Dữ liệu lịch sử 3 tháng cho 3 chi nhánh

```bash
python seed.py                          # 3 chi nhánh, sản phẩm, tài khoản, voucher
python seed_history.py                  # 1.500 đơn trong 90 ngày gần nhất (3 tháng)
```

Sinh khoảng 1.500 đơn (online + tại quầy) chia cho 3 chi nhánh theo tỉ lệ 45/30/25, vài chục phiếu nhập đã hoàn tất,
30 khách mẫu (`khach001@demo.vn` đến `khach030@demo.vn` / `demo123`). Tùy chọn: `--orders 3000 --days 120 --seed 7`; chạy lại cần `--force`.
Phiếu nhập được tính để **sổ kho khớp**: với mỗi sản phẩm ở mỗi chi nhánh, tổng nhập - tổng bán (đơn chưa hủy) ± chuyển kho
± điều chỉnh = tồn hiện tại; cuối lệnh in kết quả đối soát (hàm `reconcile_stock()` dùng lại được bất kỳ lúc nào).

Muốn làm lại từ đầu: xóa file `snack_shop.db` rồi chạy lại hai lệnh trên.
Xuất cấu trúc bảng ra file SQL để xem hoặc đính kèm báo cáo: `python scripts/export_schema.py`
(tạo `database/snack_shop_sqlite.sql`). Có thể mở `snack_shop.db` bằng DB Browser for SQLite để xem dữ liệu.

## 5. Bật gửi email xác nhận đơn hàng (tùy chọn)

Sửa file `.env`, ví dụ dùng Gmail:
```
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=1
MAIL_USERNAME=email_cua_ban@gmail.com
MAIL_PASSWORD=mat_khau_ung_dung_16_ky_tu
MAIL_DEFAULT_SENDER=email_cua_ban@gmail.com
```
Mật khẩu ứng dụng (App Password) lấy tại https://myaccount.google.com/apppasswords
(yêu cầu tài khoản Google đã bật xác minh 2 bước) — **không dùng mật khẩu Gmail thường**,
Google sẽ chặn đăng nhập SMTP thông thường.

Nếu để trống `MAIL_USERNAME`, hệ thống tự bỏ qua việc gửi email mà không báo lỗi.

## 6. Chỉnh thông tin tài khoản ngân hàng nhận chuyển khoản

Danh sách ngân hàng + số tài khoản hiển thị cho khách khi chọn "Chuyển khoản ngân hàng"
nằm trong `utils/banks.py`:
```python
BANKS = [
    {"code": "vcb", "name": "Vietcombank", "account_number": "...", "account_holder": "...", "color": "..."},
    ...
]
```
Sửa `account_number` và `account_holder` thành thông tin tài khoản thật của bạn cho từng
ngân hàng. Huy hiệu ảnh trong `static/images/banks/*.png` hiện là **huy hiệu tự tạo** (màu
nền + chữ viết tắt), không phải logo chính thức của ngân hàng — bạn có thể thay bằng logo
thật nếu có quyền sử dụng.

Sau khi khách chọn ngân hàng và đặt hàng, đơn ở trạng thái "Chờ chuyển khoản". Admin vào
`/admin/don-hang` bấm **"Xác nhận đã nhận tiền"** sau khi kiểm tra sao kê ngân hàng — đây
là xác nhận **thủ công**, dự án không tích hợp cổng thanh toán tự động xác thực giao dịch.

### Mã QR + nội dung chuyển khoản (chế độ MÔ PHỎNG)

Sau khi đặt hàng (trang "Đặt hàng thành công" và "Chi tiết đơn") khách thấy: mã QR, ngân hàng,
số tài khoản, số tiền và **nội dung chuyển khoản = mã đơn hàng** (có nút "Sao chép"). Nhân viên
đối chiếu sao kê theo đúng mã đơn rồi bấm "Đánh dấu đã nhận tiền".

- Dự án **chưa tích hợp ngân hàng/cổng thanh toán thật**, nên mọi nơi hiển thị thông tin này
  đều có nhãn **"MÔ PHỎNG"** (bật/tắt bằng `DEMO_PAYMENT` trong `utils/banks.py`).
- Mã QR được tạo bằng `utils/qr.py` (Python thuần, không cần cài thêm thư viện) và chỉ chứa
  **văn bản mô phỏng**, không phải mã VietQR/NAPAS — app ngân hàng không thể dùng nó để tạo
  lệnh chuyển tiền thật, tránh chuyển nhầm vào số tài khoản giả.
- Khi có tài khoản thật: sửa `BANKS`, đặt `DEMO_PAYMENT = False` và thay hàm `qr_payload()`
  bằng chuỗi VietQR của ngân hàng (chuẩn EMVCo/NAPAS, có CRC16).

## 7. Chạy test

`tests/test_roles.py` kiểm thử ma trận phân quyền, nhập hàng, luồng đơn, yêu cầu đổi/hủy, nhật ký, bảo trì, sao lưu/khôi phục và nâng cấp CSDL cũ.

```bash
pip install pytest
pytest
```

## 8. Cấu trúc thư mục

```
snack_shop/
├── app.py                  # Application factory + đăng ký blueprint
├── config.py                # Đọc cấu hình từ .env
├── extensions.py            # Khởi tạo db, login_manager, mail (tránh import vòng)
├── seed.py                  # Script tạo dữ liệu mẫu
├── requirements.txt
├── .env.example
├── .gitignore
│
├── database/
│   └── snack_shop_sqlite.sql     # Schema SQLite (sinh bởi scripts/export_schema.py)
│
├── models/                   # SQLAlchemy models
│   ├── receipt.py            # PhieuNhap, ChiTietPhieuNhap
│   ├── system_log.py         # NhatKyHeThong
│   ├── setting.py            # CauHinhHeThong (key-value)
│   ├── user.py               # 4 vai trò
│   ├── product.py
│   ├── category.py
│   ├── supplier.py           # nhà cung cấp (liên kết với sản phẩm)
│   ├── cart.py
│   ├── order.py              # Order (có bank_code, is_paid), OrderItem, OrderVoucher
│   ├── voucher.py            # Voucher, SavedVoucher
│   ├── review.py             # đánh giá sản phẩm
│   └── wishlist.py           # sản phẩm yêu thích
│
├── forms/                    # Flask-WTF forms
│   ├── auth_form.py
│   ├── product_form.py
│   ├── supplier_form.py
│   └── voucher_form.py
│
├── routes/                   # Blueprints (controllers)
│   ├── home.py
│   ├── auth.py
│   ├── product.py            # danh sách/chi tiết, đánh giá, gợi ý tìm kiếm
│   ├── cart.py
│   ├── order.py               # checkout AJAX, nhiều voucher, chọn ngân hàng, lịch sử/chi tiết
│   ├── admin.py              # sản phẩm, danh mục, NCC, voucher, đơn hàng, bán tại quầy, khách hàng
│   ├── receipts.py           # phiếu nhập hàng + tồn kho
│   ├── reports.py            # doanh thu, lợi nhuận, báo cáo, hiệu suất nhân viên
│   ├── system.py             # (Admin) tài khoản, cấu hình, sao lưu, nhật ký, bảo trì
│   ├── voucher.py            # danh sách voucher công khai, lưu mã, voucher của tôi
│   └── wishlist.py           # sản phẩm yêu thích
│
├── utils/
│   ├── helpers.py            # format tiền, slugify, sinh mã đơn hàng, validate SĐT
│   ├── decorators.py          # @permission_required, @roles_required, @backoffice_required
│   ├── permissions.py         # ma trận quyền theo vai trò
│   ├── audit.py               # log_event() -> NhatKyHeThong
│   ├── order_service.py       # luồng trạng thái đơn, yêu cầu đổi/hủy
│   ├── backup.py, migrate.py  # sao lưu/khôi phục SQLite, nâng cấp schema
│   ├── upload.py              # xử lý upload ảnh sản phẩm
│   ├── email.py                # gửi email xác nhận đơn hàng
│   └── banks.py                 # danh sách ngân hàng nhận chuyển khoản
│
├── templates/                 # Jinja2 templates (theo module)
├── static/                    # css, js, ảnh mặc định + huy hiệu ngân hàng
├── uploads/products/           # ảnh do admin upload lúc chạy (KHÔNG commit lên Git)
└── tests/                      # unit test (pytest)
```

## 9. Một vài quyết định thiết kế cần biết

- **Giỏ hàng yêu cầu đăng nhập**: giỏ hàng lưu trong DB theo `user_id` thay vì session cho
  khách vãng lai.
- **Phân biệt 2 loại ảnh sản phẩm**: cột `image_source` xác định ảnh nằm ở
  `static/images/products/` (mặc định) hay `uploads/products/` (admin upload).
- **Giá tiền lưu dạng số nguyên (VNĐ)**, không dùng số thập phân, tránh sai số làm tròn.
- **Tên sản phẩm không được trùng nhau** (không phân biệt hoa/thường) khi thêm/sửa ở trang
  quản trị.
- **Áp dụng nhiều voucher cùng lúc, ngay tại trang thanh toán**: ô nhập mã và danh sách mã
  gợi ý (nút "Chọn mã có sẵn") gọi AJAX (fetch) thay vì submit cả trang — nhờ vậy các
  trường thông tin giao hàng đang gõ dở (tên, SĐT, địa chỉ...) **không bị mất** khi áp
  dụng/gỡ mã. Mỗi đơn tối đa 5 mã (`MAX_VOUCHERS_PER_ORDER` trong `routes/order.py`), mỗi
  mã vẫn giới hạn 1 lần/người riêng biệt. Bảng `order_vouchers` lưu chi tiết từng mã đã
  dùng cho từng đơn. Tổng số tiền giảm không vượt quá tổng tiền đơn hàng.
- **Chuyển khoản ngân hàng có chọn ngân hàng**: khi checkout chọn "Chuyển khoản ngân hàng",
  khách chọn 1 trong các ngân hàng (hiện huy hiệu ảnh) để xem đúng số tài khoản cần chuyển
  — tránh phí chuyển khoản liên ngân hàng nếu khách dùng cùng ngân hàng với shop. Đây là
  xác nhận **thủ công**: đơn ở trạng thái "Chờ chuyển khoản" cho đến khi admin bấm "Xác
  nhận đã nhận tiền" ở trang quản lý đơn hàng sau khi kiểm tra sao kê. Không có cổng thanh
  toán tự động xác thực giao dịch trong dự án này.
- **Email xác nhận** gửi ngay sau khi đặt hàng thành công (áp dụng cho cả COD và chuyển
  khoản). Lỗi gửi email không làm hỏng đơn hàng.
- **Bấm ảnh hoặc tên sản phẩm** ở bất kỳ card nào (trang chủ, danh sách, yêu thích, sản
  phẩm liên quan) đều vào thẳng trang giới thiệu/chi tiết sản phẩm — không cần thêm bước
  bấm nút "Xem chi tiết" riêng.
- **Trừ tồn kho chống race condition**: khi tạo đơn, tồn kho được trừ bằng 1 câu lệnh
  `UPDATE ... WHERE stock >= quantity` nguyên tử ở tầng database, thay vì kiểu "đọc rồi ghi"
  — tránh trường hợp 2 khách cùng mua sản phẩm cuối cùng gần như đồng thời khiến tồn kho
  bị âm. Nếu không đủ hàng tại thời điểm này, toàn bộ đơn được rollback và báo lỗi.
- **Số điện thoại** (đăng ký tài khoản và người nhận hàng lúc checkout) được validate đúng
  định dạng di động VN (10 số, đầu số 03/05/07/08/09) qua `utils/helpers.is_valid_vn_phone`.
- **Voucher hết hạn/hết lượt tự động ẩn** khỏi trang chủ và trang "Mã giảm giá" công khai
  (không chỉ vô hiệu hóa nút). Trang quản trị voucher có nút "Xem ai đã dùng" để xem danh
  sách khách hàng + số tiền đã giảm cho từng mã.
- **Đánh giá sản phẩm**: chỉ khách đã từng mua sản phẩm đó (kiểm tra qua lịch sử `order_items`)
  mới được đánh giá; mỗi khách 1 đánh giá/sản phẩm, gửi lại sẽ ghi đè đánh giá cũ.
- **Sản phẩm yêu thích (wishlist)**: bấm 🤍/❤️ ở bất kỳ card sản phẩm nào để thêm/bỏ, xem lại
  tại trang "Yêu thích" trên navbar (yêu cầu đăng nhập).
- **Tìm kiếm gợi ý (autocomplete)**: gõ từ 2 ký tự trở lên ở ô tìm kiếm (navbar hoặc trang chủ)
  sẽ gọi `/san-pham/goi-y` để hiện dropdown gợi ý kèm ảnh + giá, có debounce 250ms.
- **Phân quyền 4 vai trò**: xem mục 3b.
- **Thống kê doanh thu**: trang `/admin/thong-ke` vẽ biểu đồ doanh thu theo ngày (Chart.js,
  7/30/90 ngày qua) + top 5 sản phẩm bán chạy, chỉ tính đơn không bị hủy.
- **`db.create_all()`** trong `app.py` phù hợp cho môi trường dev/đồ án. Khi dự án lớn hơn,
  nên chuyển sang `Flask-Migrate` để quản lý thay đổi schema an toàn hơn.

### Quy ước thời gian, mã đơn và tồn kho (đã xử lý để chạy ổn định lâu dài)

- **Giờ:** DB lưu giờ UTC. Mọi nơi hiển thị giờ dùng bộ lọc `|vn_dt('%d/%m/%Y %H:%M')`, và mọi báo cáo
  nhóm/lọc theo ngày dùng `vn_date_sql()` / `vn_midnight_utc()` trong `utils/timeutil.py` — nhờ đó đơn
  đặt lúc 0h–7h sáng được tính đúng ngày Việt Nam. Viết code mới nên dùng đúng các hàm này, đừng gọi
  `func.date(created_at)` hay `strftime` trực tiếp trên cột giờ.
- **Mã đơn / mã phiếu nhập:** hai đơn cùng giây không còn trùng mã (tự thêm hậu tố 01, 02...) —
  dùng `add_order_with_unique_code()` khi tạo đơn mới.
- **Tồn kho:** bán hàng (online + tại quầy), hoàn kho khi hủy đơn và nhập hàng đều dùng UPDATE nguyên tử.
  Form sửa sản phẩm chỉ áp dụng phần chênh lệch quản lý đã sửa, nên không ghi đè lên các đơn vừa bán.

## 10. Việc cần làm tiếp (gợi ý mở rộng)
- Thanh toán online tự động qua cổng thật (VNPay/MoMo/ZaloPay) nếu muốn xác thực giao dịch
  tự động thay vì admin xác nhận thủ công
- Áp dụng voucher theo danh mục cụ thể (hiện tại mã áp dụng cho toàn đơn)
- Thông báo (push/email) cho admin khi có đơn hàng mới
