"""Kiểm thử chi nhánh: tồn kho riêng, đơn hàng / phiếu nhập theo chi nhánh, phạm vi dữ liệu."""
import sqlite3

import pytest
from flask import g
from flask.testing import FlaskClient
from flask import has_app_context
from sqlalchemy import text

from app import create_app
from config import Config
from extensions import db
from models import (User, Category, Product, Supplier, Order, PhieuNhap, ChiNhanh, TonKho)


class FreshUserClient(FlaskClient):
    def open(self, *args, **kwargs):
        if has_app_context():
            g.pop("_login_user", None)
        return super().open(*args, **kwargs)


class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False


@pytest.fixture
def app(tmp_path):
    class Cfg(TestConfig):
        BACKUP_FOLDER = str(tmp_path / "backups")
        SYSTEM_UPLOAD_FOLDER = str(tmp_path / "sys")
    app = create_app(Cfg)
    app.test_client_class = FreshUserClient
    with app.app_context():
        b1 = ChiNhanh.query.first()  # chi nhánh mặc định tự tạo khi khởi động
        b2 = ChiNhanh(code="CN02", name="Chi nhánh 2")
        db.session.add(b2)
        db.session.flush()
        for name, email, role, branch in [
            ("Admin", "a@t.vn", "admin", None),
            ("Manager1", "m1@t.vn", "manager", b1.id), ("Manager2", "m2@t.vn", "manager", b2.id),
            ("Staff1", "s1@t.vn", "staff", b1.id), ("Staff2", "s2@t.vn", "staff", b2.id),
            ("Cust", "c@t.vn", "customer", None),
        ]:
            u = User(full_name=name, email=email, role=role, phone="0912345678", branch_id=branch)
            u.set_password("pw123456")
            db.session.add(u)
        cat, sup = Category(name="Snack", slug="snack"), Supplier(name="NCC A")
        db.session.add_all([cat, sup])
        db.session.flush()
        p = Product(name="Bim bim", slug="bim-bim", price=10000, category_id=cat.id, supplier_id=sup.id, cost_price=6000)
        p.set_stock(b1.id, 5)
        p.set_stock(b2.id, 8)
        db.session.add(p)
        db.session.commit()
        yield app


def login(app, email):
    c = app.test_client()
    assert c.post("/tai-khoan/dang-nhap", data={"email": email, "password": "pw123456"}).status_code == 302
    return c


def stock(branch_code):
    db.session.expire_all()
    b = ChiNhanh.query.filter_by(code=branch_code).one()
    return Product.query.first().stock_at(b.id)


def checkout(client, product_id, qty):
    client.post(f"/gio-hang/them/{product_id}", data={"quantity": qty})
    return client.post("/don-hang/thanh-toan", data={
        "receiver_name": "An", "receiver_phone": "0912345678", "shipping_address": "1 Lê Lợi", "payment_method": "cod"})


def test_default_branch_created_and_stock_is_per_branch(app):
    assert ChiNhanh.query.count() == 2
    p = Product.query.first()
    assert p.stock == 13  # ngoài request: tổng các chi nhánh
    assert stock("CN01") == 5 and stock("CN02") == 8


def test_customer_sees_and_buys_from_selected_branch(app):
    p = Product.query.first()
    c = login(app, "c@t.vn")
    b2 = ChiNhanh.query.filter_by(code="CN02").one()
    assert c.post("/chi-nhanh/chon", data={"branch_id": b2.id}).status_code == 302
    page = c.get(f"/san-pham/{p.slug}").get_data(as_text=True)
    assert "chỉ còn 8 sản phẩm" in page
    r = checkout(c, p.id, 3)
    assert r.status_code == 302
    order = Order.query.one()
    assert order.branch_id == b2.id
    assert stock("CN02") == 5 and stock("CN01") == 5  # chỉ trừ ở chi nhánh 2


def test_customer_cannot_buy_more_than_branch_stock(app):
    p = Product.query.first()
    c = login(app, "c@t.vn")  # mặc định chi nhánh 1: tồn 5 (chi nhánh 2 có 8 nhưng không dùng được)
    c.post(f"/gio-hang/them/{p.id}", data={"quantity": 6})
    from models import CartItem
    assert CartItem.query.count() == 0


def test_staff_only_sees_orders_of_own_branch(app):
    p = Product.query.first()
    c = login(app, "c@t.vn")
    checkout(c, p.id, 1)  # đơn của chi nhánh 1
    code = Order.query.one().code
    assert login(app, "s1@t.vn").get(f"/admin/don-hang/chi-tiet/{code}").status_code == 200
    assert login(app, "s2@t.vn").get(f"/admin/don-hang/chi-tiet/{code}").status_code == 404
    assert code not in login(app, "s2@t.vn").get("/admin/don-hang").get_data(as_text=True)
    assert code in login(app, "s1@t.vn").get("/admin/don-hang").get_data(as_text=True)


def test_counter_sale_uses_staff_branch_stock(app):
    p = Product.query.first()
    r = login(app, "s2@t.vn").post("/admin/ban-hang", data={"product_id": [p.id], "quantity": ["2"]})
    assert r.status_code == 302
    o = Order.query.one()
    assert o.branch_id == ChiNhanh.query.filter_by(code="CN02").one().id
    assert stock("CN02") == 6 and stock("CN01") == 5


def test_counter_sale_oversell_checks_own_branch_only(app):
    p = Product.query.first()
    login(app, "s1@t.vn").post("/admin/ban-hang", data={"product_id": [p.id], "quantity": ["7"]})  # CN01 chỉ có 5
    assert Order.query.count() == 0 and stock("CN01") == 5


def test_cancel_restores_stock_to_order_branch(app):
    p = Product.query.first()
    c = login(app, "c@t.vn")
    c.post("/chi-nhanh/chon", data={"branch_id": ChiNhanh.query.filter_by(code="CN02").one().id})
    checkout(c, p.id, 4)
    order = Order.query.one()
    assert stock("CN02") == 4
    r = login(app, "s2@t.vn").post(f"/admin/don-hang/cap-nhat/{order.id}", data={"status": "cancelled"})
    assert r.status_code in (200, 302)
    assert stock("CN02") == 8 and stock("CN01") == 5


def test_receipt_adds_stock_to_its_branch(app):
    p, sup = Product.query.first(), Supplier.query.first()
    staff = User.query.filter_by(email="s2@t.vn").one()
    m2 = login(app, "m2@t.vn")
    assert m2.post("/admin/nhap-hang/tao", data={
        "supplier_id": sup.id, "assigned_to_id": staff.id, "product_id": [p.id], "quantity": ["10"],
        "import_price": ["7000"], "expiry_date": ["2099-01-01"]}).status_code == 302
    receipt = PhieuNhap.query.one()
    assert receipt.branch_id == ChiNhanh.query.filter_by(code="CN02").one().id
    # quản lý chi nhánh 1 không thấy phiếu của chi nhánh 2
    assert login(app, "m1@t.vn").get(f"/admin/nhap-hang/{receipt.code}").status_code == 404
    item = receipt.items[0]
    login(app, "s2@t.vn").post(f"/admin/nhap-hang/{receipt.code}/ghi-nhan", data={
        f"received_{item.id}": "10", f"price_{item.id}": "7000"})
    assert stock("CN02") == 18 and stock("CN01") == 5


def test_receipt_codes_do_not_clash_across_branches(app):
    p, sup = Product.query.first(), Supplier.query.first()
    for email in ("m1@t.vn", "m2@t.vn"):
        r = login(app, email).post("/admin/nhap-hang/tao", data={
            "supplier_id": sup.id, "product_id": [p.id], "quantity": ["1"], "import_price": ["1000"], "expiry_date": ["2099-01-01"]})
        assert r.status_code == 302
    codes = [r.code for r in db.session.query(PhieuNhap).execution_options(skip_branch_scope=True).all()]
    assert len(codes) == 2 and len(set(codes)) == 2


def test_report_is_scoped_to_branch(app):
    p = Product.query.first()
    login(app, "s1@t.vn").post("/admin/ban-hang", data={"product_id": [p.id], "quantity": ["1"]})
    login(app, "s2@t.vn").post("/admin/ban-hang", data={"product_id": [p.id], "quantity": ["3"]})
    body1 = login(app, "m1@t.vn").get("/admin/bao-cao/ban-hang?format=csv").get_data(as_text=True)
    body2 = login(app, "m2@t.vn").get("/admin/bao-cao/ban-hang?format=csv").get_data(as_text=True)
    assert "Bim bim,1,10.000đ" in body1 and "Bim bim,3,30.000đ" in body2


def test_manager_and_staff_cannot_switch_locked_branch(app):
    c = login(app, "m1@t.vn")
    b2 = ChiNhanh.query.filter_by(code="CN02").one()
    c.post("/chi-nhanh/chon", data={"branch_id": b2.id})
    p = Product.query.first()
    c.post("/admin/ban-hang", data={"product_id": [p.id], "quantity": ["1"]})
    assert Order.query.one().branch_id == ChiNhanh.query.filter_by(code="CN01").one().id


def test_admin_manages_branches_and_assigns_staff(app):
    a = login(app, "a@t.vn")
    r = a.post("/admin/chi-nhanh/them", data={"code": "cn03", "name": "Chi nhánh 3", "address": "x", "is_active": "y"})
    assert r.status_code == 302
    b3 = ChiNhanh.query.filter_by(code="CN03").one()
    s = User.query.filter_by(email="s1@t.vn").one()
    r = a.post(f"/admin/he-thong/tai-khoan/{s.id}/sua", data={
        "full_name": s.full_name, "email": s.email, "role": "staff", "branch_id": b3.id})
    assert r.status_code == 302
    db.session.expire_all()
    assert User.query.filter_by(email="s1@t.vn").one().branch_id == b3.id
    # khách hàng không có quyền
    assert login(app, "c@t.vn").get("/admin/chi-nhanh").status_code == 403
    assert login(app, "m1@t.vn").get("/admin/chi-nhanh").status_code == 403


def test_cannot_deactivate_last_active_branch(app):
    a = login(app, "a@t.vn")
    b2 = ChiNhanh.query.filter_by(code="CN02").one()
    b2.is_active = False
    db.session.commit()
    b1 = ChiNhanh.query.filter_by(code="CN01").one()
    a.post(f"/admin/chi-nhanh/{b1.id}/sua", data={"code": "CN01", "name": "Chi nhánh 1"})  # bỏ tick hoạt động
    db.session.expire_all()
    assert ChiNhanh.query.filter_by(code="CN01").one().is_active is True


def test_legacy_database_stock_is_migrated(tmp_path):
    """CSDL từ bản cũ (cột products.stock, chưa có chi nhánh) được chuyển sang tồn kho chi nhánh mặc định."""
    path = tmp_path / "old.db"
    con = sqlite3.connect(path)
    con.executescript("""
        CREATE TABLE categories (id INTEGER PRIMARY KEY, name VARCHAR(100), slug VARCHAR(120), icon VARCHAR(20));
        CREATE TABLE products (id INTEGER PRIMARY KEY, name VARCHAR(180) NOT NULL, slug VARCHAR(200) NOT NULL UNIQUE,
            description TEXT, price INTEGER NOT NULL, sale_price INTEGER, stock INTEGER NOT NULL,
            image_filename VARCHAR(255), image_source VARCHAR(10), category_id INTEGER NOT NULL,
            supplier_id INTEGER, created_at DATETIME);
        INSERT INTO categories (id, name, slug) VALUES (1, 'Snack', 'snack');
        INSERT INTO products (id, name, slug, price, stock, category_id) VALUES (1, 'Cũ', 'cu', 1000, 42, 1);
    """)
    con.commit()
    con.close()

    class Cfg(TestConfig):
        SQLALCHEMY_DATABASE_URI = f"sqlite:///{path}"
        BACKUP_FOLDER = str(tmp_path / "b")
        SYSTEM_UPLOAD_FOLDER = str(tmp_path / "s")
    app = create_app(Cfg)
    with app.app_context():
        assert Product.query.one().stock == 42
        assert TonKho.query.count() == 1
        cols = {r[1] for r in db.session.execute(text("PRAGMA table_info(products)"))}
        assert "stock" not in cols


# ---------------- Chuyển kho giữa chi nhánh (có bước nhận hàng) ----------------

def _send(c, p, b2, qty, note=""):
    return c.post("/admin/chuyen-kho/tao", data={"product_id": p.id, "to_branch_id": b2.id, "quantity": qty, "note": note})


def test_transfer_send_then_receive_moves_stock(app):
    from models import ChuyenKho
    p = Product.query.first()
    b2 = ChiNhanh.query.filter_by(code="CN02").one()
    m1, m2 = login(app, "m1@t.vn"), login(app, "m2@t.vn")
    assert m1.get("/admin/chuyen-kho/tao").status_code == 200
    assert _send(m1, p, b2, 3, "Cân kho").status_code == 302
    t = ChuyenKho.query.one()
    assert t.status == "in_transit" and t.code.startswith("CK") and t.created_by.email == "m1@t.vn"
    assert stock("CN01") == 2 and stock("CN02") == 8  # mới trừ bên gửi, bên nhận chưa được cộng
    assert t.code in m2.get("/admin/chuyen-kho").get_data(as_text=True)
    assert "Đã nhận" in m2.get("/admin/chuyen-kho").get_data(as_text=True)
    assert m2.post(f"/admin/chuyen-kho/{t.id}/nhan").status_code == 302
    db.session.expire_all()
    assert ChuyenKho.query.one().status == "received" and ChuyenKho.query.one().handled_by.email == "m2@t.vn"
    assert stock("CN01") == 2 and stock("CN02") == 11
    m2.post(f"/admin/chuyen-kho/{t.id}/nhan")  # bấm lại lần 2 không cộng thêm
    assert stock("CN02") == 11


def test_only_receiving_branch_can_receive_and_sender_can_recall(app):
    from models import ChuyenKho
    p = Product.query.first()
    b2 = ChiNhanh.query.filter_by(code="CN02").one()
    m1, m2 = login(app, "m1@t.vn"), login(app, "m2@t.vn")
    _send(m1, p, b2, 4)
    t = ChuyenKho.query.one()
    m1.post(f"/admin/chuyen-kho/{t.id}/nhan")  # chi nhánh gửi không tự xác nhận nhận được
    db.session.expire_all()
    assert ChuyenKho.query.one().status == "in_transit" and stock("CN02") == 8
    m1.post(f"/admin/chuyen-kho/{t.id}/huy")  # thu hồi: hoàn kho gửi
    db.session.expire_all()
    assert ChuyenKho.query.one().status == "cancelled" and stock("CN01") == 5 and stock("CN02") == 8
    m2.post(f"/admin/chuyen-kho/{t.id}/nhan")  # đã hủy thì không nhận được nữa
    assert stock("CN02") == 8


def test_receiving_branch_rejection_needs_reason_and_refunds_sender(app):
    from models import ChuyenKho
    p = Product.query.first()
    b2 = ChiNhanh.query.filter_by(code="CN02").one()
    m1, m2 = login(app, "m1@t.vn"), login(app, "m2@t.vn")
    _send(m1, p, b2, 2)
    t = ChuyenKho.query.one()
    m2.post(f"/admin/chuyen-kho/{t.id}/huy", data={"reason": ""})
    db.session.expire_all()
    assert ChuyenKho.query.one().status == "in_transit"
    m2.post(f"/admin/chuyen-kho/{t.id}/huy", data={"reason": "Hàng móp"})
    db.session.expire_all()
    t = ChuyenKho.query.one()
    assert t.status == "cancelled" and t.response_note == "Hàng móp" and stock("CN01") == 5 and stock("CN02") == 8


def test_transfer_rejects_over_quantity_same_branch_and_non_manager(app):
    from models import ChuyenKho
    p = Product.query.first()
    b1 = ChiNhanh.query.filter_by(code="CN01").one()
    b2 = ChiNhanh.query.filter_by(code="CN02").one()
    c = login(app, "m1@t.vn")
    _send(c, p, b2, 6)  # CN01 chỉ có 5
    _send(c, p, b1, 1)  # chuyển cho chính mình
    _send(c, p, b2, 0)
    assert ChuyenKho.query.count() == 0 and stock("CN01") == 5 and stock("CN02") == 8
    assert login(app, "s1@t.vn").get("/admin/chuyen-kho").status_code == 403
    assert login(app, "a@t.vn").get("/admin/chuyen-kho").status_code == 403


def test_transfer_to_branch_without_stock_row_creates_it_on_receive(app):
    from models import ChuyenKho
    p = Product.query.first()
    b3 = ChiNhanh(code="CN03", name="Chi nhánh 3")
    db.session.add(b3)
    db.session.flush()
    m3 = User(full_name="M3", email="m3@t.vn", role="manager", phone="0912345678", branch_id=b3.id)
    m3.set_password("pw123456")
    db.session.add(m3)
    db.session.commit()
    _send(login(app, "m1@t.vn"), p, b3, 2)
    login(app, "m3@t.vn").post(f"/admin/chuyen-kho/{ChuyenKho.query.one().id}/nhan")
    assert stock("CN03") == 2 and stock("CN01") == 3


# ---------------- Voucher theo chi nhánh ----------------

def _vouchers(app):
    from models import Voucher
    b2 = ChiNhanh.query.filter_by(code="CN02").one()
    db.session.add_all([
        Voucher(code="ALL10", discount_type="percent", discount_value=10, active=True),
        Voucher(code="CN2ONLY", discount_type="fixed", discount_value=2000, active=True, branch_id=b2.id),
    ])
    db.session.commit()
    return b2


def test_branch_voucher_only_applies_in_its_branch(app):
    b2 = _vouchers(app)
    p = Product.query.first()
    c = login(app, "c@t.vn")
    c.post(f"/gio-hang/them/{p.id}", data={"quantity": 2})
    # chi nhánh 1 (mặc định): mã riêng chi nhánh 2 bị từ chối, mã toàn hệ thống dùng được
    assert "CN2ONLY" not in c.get("/voucher/").get_data(as_text=True)
    assert "ALL10" in c.get("/voucher/").get_data(as_text=True)
    r = c.post("/don-hang/ap-dung-voucher", data={"voucher_code": "CN2ONLY"}, headers={"X-Requested-With": "XMLHttpRequest"})
    assert r.get_json()["ok"] is False and "chỉ áp dụng" in r.get_json()["message"]
    assert c.post("/don-hang/ap-dung-voucher", data={"voucher_code": "ALL10"}, headers={"X-Requested-With": "XMLHttpRequest"}).get_json()["ok"] is True
    # đổi sang chi nhánh 2: mã riêng dùng được
    c.post("/chi-nhanh/chon", data={"branch_id": b2.id})
    assert "CN2ONLY" in c.get("/voucher/").get_data(as_text=True)


def test_manager_sees_global_and_own_branch_vouchers_but_edits_only_own(app):
    from models import Voucher
    _vouchers(app)
    m1 = login(app, "m1@t.vn")  # chi nhánh 1
    page = m1.get("/admin/voucher").get_data(as_text=True)
    assert "ALL10" in page and "CN2ONLY" not in page
    cn2 = Voucher.query.filter_by(code="CN2ONLY").one()
    all10 = Voucher.query.filter_by(code="ALL10").one()
    assert m1.get(f"/admin/voucher/sua/{cn2.id}").status_code == 404  # mã chi nhánh khác: không thấy
    assert m1.get(f"/admin/voucher/sua/{all10.id}").status_code == 403  # mã toàn hệ thống: chỉ xem
    assert m1.post(f"/admin/voucher/xoa/{all10.id}").status_code == 403
    # tạo mã mới: tự gắn chi nhánh của mình dù cố gửi phạm vi khác
    b2 = ChiNhanh.query.filter_by(code="CN02").one()
    r = m1.post("/admin/voucher/them", data={"code": "MYSHOP", "discount_type": "fixed", "discount_value": 5000,
                                              "branch_id": b2.id, "active": "y"})
    assert r.status_code == 302
    assert Voucher.query.filter_by(code="MYSHOP").one().branch_id == ChiNhanh.query.filter_by(code="CN01").one().id


def test_unassigned_manager_can_create_global_voucher(app):
    from models import Voucher
    u = User(full_name="M0", email="m0@t.vn", role="manager", phone="0912345678")
    u.set_password("pw123456")
    db.session.add(u)
    db.session.commit()
    m0 = login(app, "m0@t.vn")
    m0.post("/admin/voucher/them", data={"code": "GLOBAL5", "discount_type": "fixed", "discount_value": 5000,
                                          "branch_id": 0, "active": "y"})
    assert Voucher.query.filter_by(code="GLOBAL5").one().branch_id is None
