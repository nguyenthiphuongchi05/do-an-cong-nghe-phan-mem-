from utils.helpers import generate_order_code, format_vnd, slugify


def test_generate_order_code_format():
    code = generate_order_code()
    assert code.startswith("DH")
    assert len(code) == 16  # 'DH' + 14 số (yyyymmddHHMMSS)


def test_format_vnd():
    assert format_vnd(25000) == "25.000đ"
    assert format_vnd(0) == "0đ"


def test_slugify_vietnamese():
    assert slugify("Bánh Tráng Trộn") == "banh-trang-tron"
