"""Kiểm thử 3 lỗi đã sửa: (1) mã đơn/mã phiếu trùng khi cùng giây, (2) lệch múi giờ (giờ hiển thị + nhóm theo
ngày), (3) tranh chấp tồn kho khi sửa sản phẩm / hoàn kho. Dùng chung fixture với tests/test_roles.py."""
import json
import re
from datetime import date, datetime, timedelta

from extensions import db
from models import CartItem, Order, PhieuNhap, Product, Supplier, User, Voucher
from utils import order_service
from utils.order_service import add_order_with_unique_code
from utils.timeutil import vn_date_sql, vn_dt_filter, vn_midnight_utc, vn_now
from tests.test_roles import app, login, make_order  # noqa: F401  (fixture dùng chung)


def _blank_order(user_id):
    return Order(user_id=user_id, code="", receiver_name="A", receiver_phone="0912345678",
                 shipping_address="x", subtotal_amount=1, total_amount=1)


# ====================================================================== Lỗi 1: mã đơn trùng

def test_same_second_orders_get_unique_codes(app, monkeypatch):
    monkeypatch.setattr(order_service, "generate_order_code", lambda: "DH20260101000000")
    uid = User.query.filter_by(email="c@t.vn").one().id
    codes = []
    for _ in range(3):
        codes.append(add_order_with_unique_code(_blank_order(uid)).code)
        db.session.commit()
    assert codes == ["DH20260101000000", "DH2026010100000001", "DH2026010100000002"]


def test_checkout_survives_two_orders_in_same_second(app, monkeypatch):
    monkeypatch.setattr(order_service, "generate_order_code", lambda: "DH20260101000000")
    cust = User.query.filter_by(email="c@t.vn").one()
    product = Product.query.first()
    client = login(app, "c@t.vn")
    for _ in range(2):
        db.session.add(CartItem(user_id=cust.id, product_id=product.id, quantity=1))
        db.session.commit()
        r = client.post("/don-hang/thanh-toan", data={
            "receiver_name": "Cust", "receiver_phone": "0912345678", "shipping_address": "Hà Nội",
            "payment_method": "cod"})
        assert r.status_code == 302 and "/thanh-cong/" in r.headers["Location"]
    codes = sorted(o.code for o in Order.query.all())
    assert codes == ["DH20260101000000", "DH2026010100000001"]
    assert Product.query.first().stock == 3  # 5 - 1 - 1, mỗi đơn trừ đúng 1 lần


def test_counter_sale_two_orders_same_second(app, monkeypatch):
    monkeypatch.setattr(order_service, "generate_order_code", lambda: "DH20260101000000")
    product = Product.query.first()
    staff = login(app, "s@t.vn")
    for _ in range(2):
        r = staff.post("/admin/ban-hang", data={"product_id": [product.id], "quantity": ["1"], "payment_method": "cash"})
        assert r.status_code == 302
    assert sorted(o.code for o in Order.query.all()) == ["DH20260101000000", "DH2026010100000001"]


def test_receipt_code_retries_when_taken(app):
    sup = Supplier.query.first()
    manager = User.query.filter_by(email="m@t.vn").one()
    taken = f"PN{vn_now():%Y%m%d}002"  # chính là mã mà lần lập phiếu kế tiếp sẽ sinh ra (đã có 1 phiếu -> số 002)
    db.session.add(PhieuNhap(code=taken, supplier_id=sup.id, created_by_id=manager.id))
    db.session.commit()
    product = Product.query.first()
    r = login(app, "m@t.vn").post("/admin/nhap-hang/tao", data={
        "supplier_id": sup.id, "product_id": [product.id], "quantity": ["5"], "import_price": ["7000"],
        "expiry_date": [""]})
    assert r.status_code == 302
    codes = sorted(p.code for p in PhieuNhap.query.all())
    assert codes == [taken, f"PN{vn_now():%Y%m%d}003"]


# ====================================================================== Lỗi 2: múi giờ

def test_vn_helpers():
    assert vn_dt_filter(datetime(2026, 10, 17, 18, 30)) == "18/10/2026 01:30"   # UTC 18:30 = 01:30 hôm sau (VN)
    assert vn_dt_filter(date(2026, 10, 17), "%d/%m/%Y") == "17/10/2026"          # ngày thuần không bị dịch
    assert vn_dt_filter(None) == ""
    assert vn_midnight_utc(date(2026, 10, 18)) == datetime(2026, 10, 17, 17, 0)  # 0h VN = 17h UTC hôm trước


def test_group_by_vn_day_not_utc_day(app):
    o = make_order(app)
    o.created_at = datetime(2026, 10, 17, 18, 30)  # 01:30 ngày 18/10 theo giờ VN
    db.session.commit()
    day = db.session.query(vn_date_sql(Order.created_at)).filter(Order.id == o.id).scalar()
    assert str(day)[:10] == "2026-10-18"


def test_order_time_is_shown_in_vn_time(app):
    o = make_order(app)
    o.created_at = datetime(2026, 10, 17, 18, 30)
    db.session.commit()
    html = login(app, "c@t.vn").get(f"/don-hang/chi-tiet/{o.code}").get_data(as_text=True)
    assert "18/10/2026 01:30" in html and "17/10/2026 18:30" not in html


def test_sales_report_range_uses_vn_days(app):
    o = make_order(app)
    o.created_at = datetime(2026, 10, 17, 18, 30)  # thuộc ngày 18/10 (VN)
    db.session.commit()
    m = login(app, "m@t.vn")
    on_18 = m.get("/admin/bao-cao/ban-hang?start=2026-10-18&end=2026-10-18").get_data(as_text=True)
    on_17 = m.get("/admin/bao-cao/ban-hang?start=2026-10-17&end=2026-10-17").get_data(as_text=True)
    assert "Bim bim" in on_18 and "Bim bim" not in on_17


def test_revenue_chart_puts_early_morning_order_on_vn_day(app):
    o = make_order(app)  # 2 x 10.000đ
    vn_today = vn_now().date()
    o.created_at = vn_midnight_utc(vn_today) + timedelta(minutes=30)  # 00:30 hôm nay (VN) = chiều hôm qua (UTC)
    db.session.commit()
    html = login(app, "m@t.vn").get("/admin/bao-cao/thong-ke?days=7").get_data(as_text=True)
    labels = json.loads(re.search(r"const labels = (\[.*?\]);", html).group(1))
    revenues = json.loads(re.search(r"data: (\[.*?\]),", html).group(1))
    assert labels[-1] == vn_today.isoformat()
    assert revenues[-1] == 20000 and sum(revenues) == 20000


def test_voucher_expiry_is_compared_in_vn_time(app):
    assert not Voucher(code="A", discount_value=10, expires_at=vn_now() + timedelta(hours=1)).is_expired
    assert Voucher(code="B", discount_value=10, expires_at=vn_now() - timedelta(hours=1)).is_expired
    # hạn nhập là 3 tiếng nữa theo giờ UTC nhưng đã qua theo giờ VN (UTC+7) -> phải coi là hết hạn
    assert Voucher(code="C", discount_value=10, expires_at=datetime.utcnow() + timedelta(hours=3)).is_expired


# ====================================================================== Lỗi 3: tồn kho
# (Sửa tồn trực tiếp ở form sản phẩm đã bỏ: tồn chỉ đổi qua phiếu nhập / bán / chuyển kho / phiếu điều chỉnh; xem test_team_adjust.py)

def test_cancel_restock_is_added_to_current_stock(app):
    o = make_order(app, qty=2)  # tồn 5 -> 3
    Product.query.first().stock = 10  # có hàng nhập thêm trong lúc đơn đang chờ
    db.session.commit()
    ok, _ = order_service.change_order_status(o, "cancelled", User.query.filter_by(email="s@t.vn").one())
    assert ok
    db.session.expire_all()
    assert Product.query.first().stock == 12

