"""Đơn chuyển khoản chưa thu tiền thì không được giao hàng / hoàn thành."""
from extensions import db
from models import Order
from tests.test_roles import app, login, make_order  # noqa: F401


def _staff_email():
    from models import User
    return User.query.filter(User.role.in_(["staff", "manager"])).first().email


def _post_status(c, order, status):
    return c.post(f"/admin/don-hang/cap-nhat/{order.id}", data={"status": status}, follow_redirects=True)


def test_bank_transfer_unpaid_cannot_ship_or_complete(app):
    o = make_order(app, status="confirmed")
    o.payment_method = "bank_transfer"
    o.is_paid = False
    db.session.commit()
    c = login(app, _staff_email())
    r = _post_status(c, o, "shipping")
    assert "chưa thu được tiền" in r.get_data(as_text=True)
    assert Order.query.get(o.id).status == "confirmed"
    # trang chi tiết cũng không có nút giao hàng bấm được
    html = c.get(f"/admin/don-hang/chi-tiet/{o.code}").get_data(as_text=True)
    assert "Chưa thu được tiền chuyển khoản" in html


def test_bank_transfer_paid_can_ship_and_complete_and_cannot_unmark(app):
    o = make_order(app, status="confirmed")
    o.payment_method = "bank_transfer"
    db.session.commit()
    c = login(app, _staff_email())
    c.post(f"/admin/don-hang/xac-nhan-thanh-toan/{o.id}")
    assert Order.query.get(o.id).is_paid is True
    _post_status(c, o, "shipping")
    assert Order.query.get(o.id).status == "shipping"
    c.post(f"/admin/don-hang/xac-nhan-thanh-toan/{o.id}")  # thử bỏ đánh dấu khi đang giao
    assert Order.query.get(o.id).is_paid is True
    _post_status(c, o, "completed")
    assert Order.query.get(o.id).status == "completed"


def test_cod_and_unpaid_bank_can_still_confirm_or_cancel(app):
    o = make_order(app, status="pending")
    o.payment_method = "bank_transfer"
    db.session.commit()
    c = login(app, _staff_email())
    _post_status(c, o, "confirmed")
    assert Order.query.get(o.id).status == "confirmed"
    _post_status(c, o, "cancelled")
    assert Order.query.get(o.id).status == "cancelled"
