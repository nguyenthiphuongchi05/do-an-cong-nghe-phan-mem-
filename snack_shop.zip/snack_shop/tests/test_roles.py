"""Kiểm thử phân quyền 4 vai trò + nghiệp vụ nhập hàng, nhật ký, sao lưu."""
import sqlite3
import pytest

from app import create_app
from config import Config
from extensions import db
from models import (ChiNhanh, User, Category, Product, Supplier, Order, OrderItem, PhieuNhap, ChiTietPhieuNhap,
                    NhatKyHeThong)


from flask import g, has_app_context
from flask.testing import FlaskClient


class FreshUserClient(FlaskClient):
    """Fixture giữ 1 app context mở suốt test nên `g` (và g._login_user của Flask-Login) bị dùng chung
    giữa các request/giữa các client. Xóa cache người dùng trước mỗi request để mô phỏng đúng thực tế."""
    def open(self, *args, **kwargs):
        if has_app_context():
            g.pop("_login_user", None)
        return super().open(*args, **kwargs)


class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False


@pytest.fixture
def app(tmp_path):
    class Cfg(TestConfig):
        BACKUP_FOLDER = str(tmp_path / "backups")
        SYSTEM_UPLOAD_FOLDER = str(tmp_path / "sys")
    app = create_app(Cfg)
    app.test_client_class = FreshUserClient
    with app.app_context():
        for name, email, role in [("Admin", "a@t.vn", "admin"), ("Chain", "cm@t.vn", "chain_manager"),
                                  ("Manager", "m@t.vn", "manager"),
                                  ("Staff", "s@t.vn", "staff"), ("Staff2", "s2@t.vn", "staff"),
                                  ("Cust", "c@t.vn", "customer")]:
            u = User(full_name=name, email=email, role=role, phone="0912345678")
            u.set_password("pw123456")
            db.session.add(u)
        cat = Category(name="Snack", slug="snack")
        sup = Supplier(name="NCC A")
        db.session.add_all([cat, sup])
        db.session.flush()
        db.session.add(Product(name="Bim bim", slug="bim-bim", price=10000, stock=5, category_id=cat.id,
                               supplier_id=sup.id, cost_price=6000))
        db.session.commit()
        yield app


def login(app, email):
    c = app.test_client()
    r = c.post("/tai-khoan/dang-nhap", data={"email": email, "password": "pw123456"})
    assert r.status_code == 302
    return c


def make_order(app, status="pending", qty=2):
    p = Product.query.first()
    cust = User.query.filter_by(email="c@t.vn").first()
    p.stock -= qty
    o = Order(user_id=cust.id, code="DH-T1", receiver_name="C", receiver_phone="0912345678",
              shipping_address="x", subtotal_amount=p.price * qty, total_amount=p.price * qty, status=status)
    o.items.append(OrderItem(product_id=p.id, product_name=p.name, price=p.price, quantity=qty, cost_price=p.cost_price))
    db.session.add(o)
    db.session.commit()
    return o


# ---------- Ma trận phân quyền ----------

ADMIN_ONLY = ["/admin/he-thong/tai-khoan", "/admin/he-thong/cau-hinh", "/admin/he-thong/sao-luu",
              "/admin/he-thong/nhat-ky", "/admin/he-thong/bao-tri"]
MANAGER_ONLY = ["/admin/san-pham", "/admin/danh-muc", "/admin/nha-cung-cap", "/admin/voucher",
                "/admin/bao-cao/thong-ke", "/admin/bao-cao/ban-hang", "/admin/bao-cao/nhap-hang",
                "/admin/bao-cao/xuat-hang", "/admin/bao-cao/nhan-vien", "/admin/nhap-hang/tao"]
SHARED = ["/admin/", "/admin/don-hang", "/admin/ton-kho", "/admin/ban-hang", "/admin/khach-hang", "/admin/nhap-hang"]
ADMIN_AREA_FORBIDDEN_FOR_ADMIN = ["/admin/don-hang", "/admin/ton-kho", "/admin/ban-hang", "/admin/khach-hang",
                                  "/admin/nhap-hang"] + MANAGER_ONLY


@pytest.mark.parametrize("url", ADMIN_ONLY + MANAGER_ONLY + SHARED)
def test_customer_blocked_everywhere_in_backoffice(app, url):
    assert login(app, "c@t.vn").get(url).status_code == 403


@pytest.mark.parametrize("url", ADMIN_ONLY + MANAGER_ONLY + SHARED)
def test_anonymous_redirected_to_login(app, url):
    r = app.test_client().get(url)
    assert r.status_code == 302 and "/tai-khoan/dang-nhap" in r.headers["Location"]


@pytest.mark.parametrize("url", ADMIN_ONLY)
def test_admin_pages_ok_for_admin_forbidden_for_others(app, url):
    assert login(app, "a@t.vn").get(url).status_code == 200
    for email in ("cm@t.vn", "m@t.vn", "s@t.vn"):
        assert login(app, email).get(url).status_code == 403


@pytest.mark.parametrize("url", ADMIN_AREA_FORBIDDEN_FOR_ADMIN)
def test_admin_cannot_run_daily_sales(app, url):
    assert login(app, "a@t.vn").get(url).status_code == 403


BUSINESS_PAGES = ["/admin/voucher", "/admin/bao-cao/thong-ke", "/admin/bao-cao/ban-hang", "/admin/bao-cao/nhap-hang",
                  "/admin/bao-cao/xuat-hang", "/admin/bao-cao/nhan-vien"]
CHAIN_ONLY_PAGES = ["/admin/danh-muc", "/admin/nha-cung-cap"]
BRANCH_MANAGER_ONLY_PAGES = ["/admin/nhap-hang/tao"]


@pytest.mark.parametrize("url", BUSINESS_PAGES)
def test_business_pages_for_chain_and_branch_manager_not_staff(app, url):
    assert login(app, "cm@t.vn").get(url).status_code == 200
    assert login(app, "m@t.vn").get(url).status_code == 200
    assert login(app, "s@t.vn").get(url).status_code == 403


@pytest.mark.parametrize("url", CHAIN_ONLY_PAGES)
def test_catalog_pages_only_for_chain_manager(app, url):
    assert login(app, "cm@t.vn").get(url).status_code == 200
    assert login(app, "m@t.vn").get(url).status_code == 403
    assert login(app, "s@t.vn").get(url).status_code == 403


@pytest.mark.parametrize("url", BRANCH_MANAGER_ONLY_PAGES)
def test_branch_operations_only_for_branch_manager(app, url):
    assert login(app, "m@t.vn").get(url).status_code == 200
    assert login(app, "cm@t.vn").get(url).status_code == 403  # quản lý chuỗi không vận hành chi nhánh
    assert login(app, "s@t.vn").get(url).status_code == 403


def test_product_list_is_read_only_for_branch_roles(app):
    assert login(app, "a@t.vn").get("/admin/san-pham").status_code == 403
    chain = login(app, "cm@t.vn").get("/admin/san-pham").get_data(as_text=True)
    assert "Thêm sản phẩm" in chain
    for email in ("m@t.vn", "s@t.vn"):
        page = login(app, email).get("/admin/san-pham")
        assert page.status_code == 200 and "Thêm sản phẩm" not in page.get_data(as_text=True)
    p = Product.query.first()
    for email in ("m@t.vn", "s@t.vn"):
        c = login(app, email)
        assert c.get("/admin/san-pham/them").status_code == 403
        assert c.get(f"/admin/san-pham/sua/{p.id}").status_code == 403
        assert c.post(f"/admin/san-pham/xoa/{p.id}").status_code == 403


@pytest.mark.parametrize("url", SHARED[1:])
def test_shared_pages_for_manager_and_staff(app, url):
    for email in ("m@t.vn", "s@t.vn"):
        assert login(app, email).get(url).status_code == 200


def test_every_role_sees_own_dashboard(app):
    for email in ("a@t.vn", "cm@t.vn", "m@t.vn", "s@t.vn"):
        assert login(app, email).get("/admin/").status_code == 200


def test_register_always_creates_customer(app):
    c = app.test_client()
    c.post("/tai-khoan/dang-ky", data={"full_name": "Moi", "email": "n@t.vn", "phone": "0912345678",
                                        "password": "abcdef12", "confirm_password": "abcdef12", "role": "admin"})
    assert User.query.filter_by(email="n@t.vn").one().role == "customer"


# ---------- Quản lý tài khoản (Admin) ----------

def test_lock_blocks_login_and_unlock_restores(app):
    admin = login(app, "a@t.vn")
    cust = User.query.filter_by(email="c@t.vn").one()
    admin.post(f"/admin/he-thong/tai-khoan/{cust.id}/khoa")
    assert User.query.get(cust.id).is_locked
    r = app.test_client().post("/tai-khoan/dang-nhap", data={"email": "c@t.vn", "password": "pw123456"})
    assert r.status_code == 200  # ở lại trang đăng nhập
    admin.post(f"/admin/he-thong/tai-khoan/{cust.id}/khoa")
    assert app.test_client().post("/tai-khoan/dang-nhap", data={"email": "c@t.vn", "password": "pw123456"}).status_code == 302


def test_locked_session_is_logged_out_immediately(app):
    cust_client = login(app, "c@t.vn")
    cust = User.query.filter_by(email="c@t.vn").one()
    cust.is_locked = True
    db.session.commit()
    r = cust_client.get("/don-hang/lich-su")
    assert r.status_code == 302 and "dang-nhap" in r.headers["Location"]


def test_admin_cannot_lock_self_or_demote_last_admin(app):
    admin = login(app, "a@t.vn")
    me = User.query.filter_by(email="a@t.vn").one()
    admin.post(f"/admin/he-thong/tai-khoan/{me.id}/khoa")
    assert not User.query.get(me.id).is_locked
    admin.post(f"/admin/he-thong/tai-khoan/{me.id}/sua", data={"full_name": "Admin", "email": "a@t.vn", "role": "staff"})
    assert User.query.get(me.id).role == "admin"


def test_admin_assigns_role_and_resets_password(app):
    admin = login(app, "a@t.vn")
    c = User.query.filter_by(email="c@t.vn").one()
    admin.post(f"/admin/he-thong/tai-khoan/{c.id}/sua",
               data={"full_name": "Cust", "email": "c@t.vn", "phone": "0912345678", "role": "staff",
                     "branch_id": ChiNhanh.query.first().id})
    assert User.query.get(c.id).role == "staff"
    admin.post(f"/admin/he-thong/tai-khoan/{c.id}/dat-lai-mat-khau", data={"new_password": "moi12345"})
    assert User.query.get(c.id).check_password("moi12345")
    assert NhatKyHeThong.query.filter_by(action="role_change").count() == 1
    assert NhatKyHeThong.query.filter_by(action="password_reset").count() == 1


def test_admin_creates_staff_account(app):
    login(app, "a@t.vn").post("/admin/he-thong/tai-khoan/tao", data={
        "full_name": "NV Moi", "email": "nvmoi@t.vn", "phone": "", "role": "staff", "password": "Nvmoi9876",
        "branch_id": ChiNhanh.query.first().id})
    u = User.query.filter_by(email="nvmoi@t.vn").one()
    assert u.role == "staff" and u.branch_id == ChiNhanh.query.first().id


def test_admin_cannot_create_branch_role_without_branch(app):
    login(app, "a@t.vn").post("/admin/he-thong/tai-khoan/tao", data={
        "full_name": "NV Moi", "email": "nvmoi@t.vn", "phone": "", "role": "staff", "password": "Nvmoi9876"})
    assert User.query.filter_by(email="nvmoi@t.vn").first() is None


def test_chain_manager_account_has_no_branch(app):
    login(app, "a@t.vn").post("/admin/he-thong/tai-khoan/tao", data={
        "full_name": "CM2", "email": "cm2@t.vn", "phone": "", "role": "chain_manager", "password": "Chain9876x",
        "branch_id": ChiNhanh.query.first().id})
    u = User.query.filter_by(email="cm2@t.vn").one()
    assert u.role == "chain_manager" and u.branch_id is None


# ---------- Nhập hàng ----------

def create_receipt(app, assigned_email="s@t.vn"):
    staff = User.query.filter_by(email=assigned_email).one()
    p, sup = Product.query.first(), Supplier.query.first()
    r = login(app, "m@t.vn").post("/admin/nhap-hang/tao", data={
        "supplier_id": sup.id, "assigned_to_id": staff.id, "product_id": [p.id], "quantity": ["20"],
        "import_price": ["7000"], "expiry_date": ["2099-01-01"]})
    assert r.status_code == 302
    return PhieuNhap.query.one()


def test_receipt_flow_updates_stock_and_cost(app):
    receipt = create_receipt(app)
    assert receipt.status == "pending" and Product.query.first().stock == 5
    item = receipt.items[0]
    s = login(app, "s@t.vn")
    s.post(f"/admin/nhap-hang/{receipt.code}/ghi-nhan", data={
        f"received_{item.id}": "18", f"price_{item.id}": "7500", f"expiry_{item.id}": "2099-02-02"})
    db.session.expire_all()
    p = Product.query.first()
    assert p.stock == 23 and p.cost_price == 7500
    r = PhieuNhap.query.one()
    assert r.status == "completed" and r.total_amount == 18 * 7500 and r.received_by.email == "s@t.vn"
    # không ghi nhận lần 2
    s.post(f"/admin/nhap-hang/{receipt.code}/ghi-nhan", data={f"received_{item.id}": "99"})
    db.session.expire_all()
    assert Product.query.first().stock == 23


def test_unassigned_staff_cannot_see_or_record_receipt(app):
    receipt = create_receipt(app)
    other = login(app, "s2@t.vn")
    assert other.get(f"/admin/nhap-hang/{receipt.code}").status_code == 403
    assert other.post(f"/admin/nhap-hang/{receipt.code}/ghi-nhan", data={}).status_code == 403
    assert Product.query.first().stock == 5


def test_staff_cannot_create_or_cancel_receipt(app):
    receipt = create_receipt(app)
    s = login(app, "s@t.vn")
    assert s.post("/admin/nhap-hang/tao", data={}).status_code == 403
    assert s.post(f"/admin/nhap-hang/{receipt.code}/huy").status_code == 403


def test_manager_cancel_receipt_leaves_stock(app):
    receipt = create_receipt(app)
    login(app, "m@t.vn").post(f"/admin/nhap-hang/{receipt.code}/huy")
    assert PhieuNhap.query.one().status == "cancelled" and Product.query.first().stock == 5


def test_near_expiry_listed_in_inventory(app):
    from datetime import date, timedelta
    receipt = create_receipt(app)
    item = receipt.items[0]
    login(app, "s@t.vn").post(f"/admin/nhap-hang/{receipt.code}/ghi-nhan", data={
        f"received_{item.id}": "5", f"price_{item.id}": "7000",
        f"expiry_{item.id}": (date.today() + timedelta(days=5)).isoformat()})
    html = login(app, "m@t.vn").get("/admin/ton-kho").get_data(as_text=True)
    assert "Bim bim" in html and "ngày" in html and "PN" in html


# ---------- Đơn hàng ----------

def test_staff_order_flow_and_cancel_restocks(app):
    o = make_order(app)
    s = login(app, "s@t.vn")
    s.post(f"/admin/don-hang/cap-nhat/{o.id}", data={"status": "confirmed"})
    s.post(f"/admin/don-hang/cap-nhat/{o.id}", data={"status": "shipping"})
    db.session.expire_all()
    o = Order.query.one()
    assert o.status == "shipping" and o.handled_by.email == "s@t.vn"
    s.post(f"/admin/don-hang/cap-nhat/{o.id}", data={"status": "cancelled"})
    db.session.expire_all()
    assert Order.query.one().status == "cancelled" and Product.query.first().stock == 5


def test_invalid_transition_rejected_and_final_state_locked(app):
    o = make_order(app)
    s = login(app, "s@t.vn")
    s.post(f"/admin/don-hang/cap-nhat/{o.id}", data={"status": "completed"})  # nhảy cóc
    assert Order.query.one().status == "pending"
    s.post(f"/admin/don-hang/cap-nhat/{o.id}", data={"status": "cancelled"})
    s.post(f"/admin/don-hang/cap-nhat/{o.id}", data={"status": "pending"})  # sống lại đơn đã hủy
    db.session.expire_all()
    assert Order.query.one().status == "cancelled" and Product.query.first().stock == 5


def test_completed_cod_marks_paid(app):
    o = make_order(app, status="shipping")
    login(app, "s@t.vn").post(f"/admin/don-hang/cap-nhat/{o.id}", data={"status": "completed"})
    db.session.expire_all()
    o = Order.query.one()
    assert o.is_paid and o.completed_at is not None


def test_customer_cancel_request_approved_by_staff(app):
    o = make_order(app)
    c = login(app, "c@t.vn")
    c.post(f"/don-hang/yeu-cau/{o.code}", data={"request_type": "cancel", "reason": "Đặt nhầm sản phẩm"})
    assert Order.query.one().request_status == "pending"
    # khách không tự duyệt được
    assert c.post(f"/admin/don-hang/{o.id}/xu-ly-yeu-cau", data={"decision": "approve"}).status_code == 403
    login(app, "s@t.vn").post(f"/admin/don-hang/{o.id}/xu-ly-yeu-cau", data={"decision": "approve", "note": "OK"})
    db.session.expire_all()
    o = Order.query.one()
    assert o.status == "cancelled" and o.request_status == "approved" and Product.query.first().stock == 5


def test_staff_must_explain_rejection(app):
    o = make_order(app)
    login(app, "c@t.vn").post(f"/don-hang/yeu-cau/{o.code}", data={"request_type": "cancel", "reason": "Muốn hủy đơn"})
    s = login(app, "s@t.vn")
    s.post(f"/admin/don-hang/{o.id}/xu-ly-yeu-cau", data={"decision": "reject", "note": ""})
    assert Order.query.one().request_status == "pending"
    s.post(f"/admin/don-hang/{o.id}/xu-ly-yeu-cau", data={"decision": "reject", "note": "Đơn đã đóng gói"})
    assert Order.query.one().request_status == "rejected"


def test_customer_cannot_cancel_shipping_or_exchange_pending(app):
    o = make_order(app, status="shipping")
    c = login(app, "c@t.vn")
    c.post(f"/don-hang/yeu-cau/{o.code}", data={"request_type": "cancel", "reason": "Không muốn nữa"})
    c.post(f"/don-hang/yeu-cau/{o.code}", data={"request_type": "exchange", "reason": "Muốn đổi hàng"})
    assert Order.query.one().request_status is None


def test_customer_sees_only_own_orders(app):
    make_order(app)
    other = User(full_name="Khac", email="k@t.vn", role="customer")
    other.set_password("pw123456")
    db.session.add(other)
    db.session.commit()
    c = app.test_client()
    c.post("/tai-khoan/dang-nhap", data={"email": "k@t.vn", "password": "pw123456"})
    assert c.get("/don-hang/chi-tiet/DH-T1").status_code == 404
    assert login(app, "c@t.vn").get("/don-hang/chi-tiet/DH-T1").status_code == 200


# ---------- Bán tại quầy + hóa đơn ----------

def test_counter_sale_creates_invoice_and_deducts_stock(app):
    p = Product.query.first()
    s = login(app, "s@t.vn")
    r = s.post("/admin/ban-hang", data={"product_id": [p.id], "quantity": ["3"], "customer_name": "An"})
    assert r.status_code == 302
    o = Order.query.one()
    assert o.channel == "counter" and o.status == "completed" and o.total_amount == 30000 and o.profit == 12000
    assert Product.query.first().stock == 2
    assert s.get(r.headers["Location"]).status_code == 200


def test_counter_sale_rejects_oversell(app):
    p = Product.query.first()
    login(app, "s@t.vn").post("/admin/ban-hang", data={"product_id": [p.id], "quantity": ["50"]})
    assert Order.query.count() == 0 and Product.query.first().stock == 5


def test_walkin_account_cannot_login_and_hidden_from_customer_list(app):
    p = Product.query.first()
    s = login(app, "s@t.vn")
    s.post("/admin/ban-hang", data={"product_id": [p.id], "quantity": ["1"]})
    r = app.test_client().post("/tai-khoan/dang-nhap", data={"email": "khachle@snackshop.local", "password": "x"})
    assert r.status_code == 200
    assert "khachle@snackshop.local" not in s.get("/admin/khach-hang").get_data(as_text=True)


# ---------- Báo cáo ----------

def test_reports_profit_and_csv(app):
    p = Product.query.first()
    login(app, "s@t.vn").post("/admin/ban-hang", data={"product_id": [p.id], "quantity": ["2"]})
    m = login(app, "m@t.vn")
    for url in ("/admin/bao-cao/thong-ke", "/admin/bao-cao/ban-hang", "/admin/bao-cao/xuat-hang",
                "/admin/bao-cao/nhap-hang", "/admin/bao-cao/nhan-vien"):
        assert m.get(url).status_code == 200
    csv_resp = m.get("/admin/bao-cao/ban-hang?format=csv")
    assert csv_resp.mimetype == "text/csv" and "Bim bim" in csv_resp.get_data(as_text=True)
    perf = m.get("/admin/bao-cao/nhan-vien").get_data(as_text=True)
    assert "Staff" in perf


# ---------- Nhật ký ----------

def test_activity_is_logged_and_filterable(app):
    login(app, "s@t.vn")
    app.test_client().post("/tai-khoan/dang-nhap", data={"email": "s@t.vn", "password": "sai"})
    assert NhatKyHeThong.query.filter_by(action="login").count() == 1
    assert NhatKyHeThong.query.filter_by(action="login_failed", level="warning").count() == 1
    login(app, "c@t.vn").get("/admin/")  # bị từ chối -> ghi nhật ký bảo mật
    assert NhatKyHeThong.query.filter_by(category="security").count() == 1
    html = login(app, "a@t.vn").get("/admin/he-thong/nhat-ky?category=security").get_data(as_text=True)
    assert "c@t.vn" in html and "s@t.vn" not in html.split("<tbody>")[1]


def test_next_param_open_redirect_blocked(app):
    r = app.test_client().post("/tai-khoan/dang-nhap?next=https://evil.example",
                               data={"email": "c@t.vn", "password": "pw123456"})
    assert "evil" not in r.headers["Location"]


# ---------- Cấu hình, bảo trì, sao lưu ----------

def test_maintenance_mode_blocks_customers_not_staff(app):
    admin = login(app, "a@t.vn")
    staff, cust = login(app, "s@t.vn"), login(app, "c@t.vn")
    admin.post("/admin/he-thong/bao-tri/che-do", data={"message": "Bảo trì tí"})
    assert cust.get("/").status_code == 503
    assert app.test_client().get("/san-pham/").status_code == 503
    assert staff.get("/admin/").status_code == 200
    assert app.test_client().get("/tai-khoan/dang-nhap").status_code == 200
    admin.post("/admin/he-thong/bao-tri/che-do")
    assert cust.get("/").status_code == 200
    assert NhatKyHeThong.query.filter_by(category="maintenance").count() == 2


def test_store_config_shows_on_site(app):
    login(app, "a@t.vn").post("/admin/he-thong/cau-hinh", data={
        "store_name": "Quán Ăn Vặt X", "store_slogan": "abc", "store_address": "HN", "store_phone": "0900",
        "store_email": "x@y.vn"})
    html = app.test_client().get("/").get_data(as_text=True)
    assert "Quán Ăn Vặt X" in html


def test_backup_and_restore_roundtrip(tmp_path):
    db_file = tmp_path / "live.db"

    class Cfg(TestConfig):
        SQLALCHEMY_DATABASE_URI = f"sqlite:///{db_file}"
        BACKUP_FOLDER = str(tmp_path / "backups")
        SYSTEM_UPLOAD_FOLDER = str(tmp_path / "sys")
    app = create_app(Cfg)
    app.test_client_class = FreshUserClient
    with app.app_context():
        a = User(full_name="Admin", email="a@t.vn", role="admin")
        a.set_password("pw123456")
        db.session.add(a)
        db.session.commit()
    c = login(app, "a@t.vn")
    c.post("/admin/he-thong/sao-luu/tao")
    from utils.backup import list_backups
    with app.app_context():
        name = list_backups()[0]["name"]
        db.session.add(User(full_name="Sau Backup", email="later@t.vn", password_hash="x", role="customer"))
        db.session.commit()
    # sai xác nhận -> không khôi phục
    c.post("/admin/he-thong/sao-luu/khoi-phuc", data={"name": name, "confirm": "no"})
    with app.app_context():
        assert User.query.filter_by(email="later@t.vn").count() == 1
    c.post("/admin/he-thong/sao-luu/khoi-phuc", data={"name": name, "confirm": "khoi phuc"})
    with app.app_context():
        assert User.query.filter_by(email="later@t.vn").count() == 0
        assert User.query.filter_by(email="a@t.vn").count() == 1
        assert any(b["name"].startswith("truoc-khoi-phuc") for b in list_backups())
        assert NhatKyHeThong.query.filter_by(action="backup_restore").count() == 1
    # chống path traversal
    assert c.get("/admin/he-thong/sao-luu/tai/..%2Flive.db").status_code in (302, 404)


def test_old_database_is_migrated(tmp_path):
    """CSDL phiên bản cũ (is_admin/is_staff) được chuyển sang role."""
    path = tmp_path / "old.db"
    con = sqlite3.connect(path)
    con.executescript("""
    CREATE TABLE users (id INTEGER PRIMARY KEY, full_name VARCHAR(120) NOT NULL, email VARCHAR(120) NOT NULL UNIQUE,
        phone VARCHAR(20), address VARCHAR(255), password_hash VARCHAR(255) NOT NULL,
        is_admin BOOLEAN NOT NULL DEFAULT 0, is_staff BOOLEAN NOT NULL DEFAULT 0, created_at DATETIME);
    INSERT INTO users (full_name,email,password_hash,is_admin,is_staff) VALUES
        ('A','a@x.vn','h',1,0),('S','s@x.vn','h',0,1),('C','c@x.vn','h',0,0);
    CREATE TABLE orders (id INTEGER PRIMARY KEY, user_id INTEGER, code VARCHAR(20), receiver_name VARCHAR(120),
        receiver_phone VARCHAR(20), shipping_address VARCHAR(255), subtotal_amount INTEGER, discount_amount INTEGER,
        total_amount INTEGER, status VARCHAR(20), is_paid BOOLEAN, created_at DATETIME);
    """)
    con.commit()
    con.close()

    class Cfg(TestConfig):
        SQLALCHEMY_DATABASE_URI = f"sqlite:///{path}"
        BACKUP_FOLDER = str(tmp_path / "b")
    app = create_app(Cfg)
    with app.app_context():
        roles = {u.email: u.role for u in User.query.all()}
        assert roles == {"a@x.vn": "admin", "s@x.vn": "staff", "c@x.vn": "customer"}
        cols = [r[1] for r in db.session.execute(db.text("PRAGMA table_info(users)"))]
        assert "is_admin" not in cols and "role" in cols
