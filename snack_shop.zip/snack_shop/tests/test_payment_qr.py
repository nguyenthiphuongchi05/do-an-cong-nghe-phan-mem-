"""Kiểm thử bộ tạo mã QR và khối thanh toán chuyển khoản (QR + nội dung = mã đơn, chế độ mô phỏng)."""
import random

import pytest

from extensions import db
from utils import qr
from tests.test_roles import app, login, make_order  # noqa: F401  (fixture dùng chung)


# ---------- Bộ tạo QR: đối chiếu giá trị chuẩn ISO/IEC 18004 ----------

def test_reed_solomon_matches_iso_example():
    data = [16, 32, 12, 86, 97, 128, 236, 17, 236, 17, 236, 17, 236, 17, 236, 17]
    assert qr.rs_remainder(data, 10) == [165, 36, 212, 193, 237, 54, 199, 135, 44, 85]


def test_format_and_version_bits_match_standard():
    expected = ["101010000010010", "101000100100101", "101111001111100", "101101101001011",
                "100010111111001", "100000011001110", "100111110010111", "100101010100000"]
    for mask, bits in enumerate(expected):
        assert format(qr.format_bits(mask), "015b") == bits
    assert qr.version_bits(7) == 0x07C94 and qr.version_bits(8) == 0x085BC and qr.version_bits(10) == 0x0A4D3


def test_block_tables_are_consistent():
    totals = {1: 26, 2: 44, 3: 70, 4: 100, 5: 134, 6: 172, 7: 196, 8: 242, 9: 292, 10: 346}
    for v, total in totals.items():
        ec, groups = qr._EC_M[v]
        assert qr.data_capacity(v) + ec * sum(n for n, _ in groups) == total


def decode(grid):
    n=len(grid); v=(n-17)//4
    mx=qr._Matrix(v)
    # đọc format bits copy 1
    b=0
    def g(x,y): return grid[y][x]
    bits=[0]*15
    for i in range(6): bits[i]=g(8,i)
    bits[6]=g(8,7); bits[7]=g(8,8); bits[8]=g(7,8)
    for i in range(9,15): bits[i]=g(14-i,8)
    val=sum(bit<<i for i,bit in enumerate(bits))
    mask=[m for m in range(8) if qr.format_bits(m)==val]; assert mask, "format"
    mask=mask[0]
    # copy 2 phải giống copy 1
    bits2=[0]*15
    for i in range(8): bits2[i]=g(n-1-i,8)
    for i in range(8,15): bits2[i]=g(8,n-15+i)
    assert bits2==bits
    # lấy bit dữ liệu theo zigzag
    out=[]
    right=n-1
    while right>=1:
        if right==6: right=5
        for vert in range(n):
            for j in range(2):
                x=right-j; up=((right+1)&2)==0; y=n-1-vert if up else vert
                if not mx.func[y][x]:
                    out.append(grid[y][x]^(1 if mx.mask_hit(mask,y,x) else 0))
        right-=2
    words=[int("".join(map(str,out[i:i+8])),2) for i in range(0,len(out)//8*8,8)]
    ec,groups=qr._EC_M[v]; sizes=[d for nb,d in groups for _ in range(nb)]
    nblocks=len(sizes); total_data=sum(sizes)
    blocks=[[] for _ in sizes]; pos=0
    for i in range(max(sizes)):
        for k,s in enumerate(sizes):
            if i<s: blocks[k].append(words[pos]); pos+=1
    ecs=[[] for _ in sizes]
    for i in range(ec):
        for k in range(nblocks): ecs[k].append(words[pos]); pos+=1
    for k in range(nblocks): assert qr.rs_remainder(blocks[k],ec)==ecs[k],"RS"
    flat=[w for b in blocks for w in b]
    bs="".join(f"{w:08b}" for w in flat)
    assert bs[:4]=="0100"
    cb=8 if v<=9 else 16
    ln=int(bs[4:4+cb],2)
    raw=bytes(int(bs[4+cb+8*i:4+cb+8*i+8],2) for i in range(ln))
    return v,mask,raw.decode()


@pytest.mark.parametrize("length", [5, 20, 60, 100, 140, 200, 213])
def test_qr_roundtrip_decodes_to_original_text(length):
    rnd = random.Random(length)
    text = "".join(rnd.choice("ABCDEFabcdef0123456789 |-\n.") for _ in range(length))
    assert decode(qr.build_matrix(text))[2] == text


def test_qr_rejects_too_long_text():
    with pytest.raises(ValueError):
        qr.build_matrix("x" * 214)


# ---------- Khối thanh toán chuyển khoản ----------

def _bank_order(app, **fields):
    o = make_order(app)
    o.payment_method = "bank_transfer"
    o.bank_code = "vcb"
    for k, v in fields.items():
        setattr(o, k, v)
    db.session.commit()
    return o


def test_success_page_shows_qr_transfer_content_and_demo_notice(app):
    o = _bank_order(app)
    html = login(app, "c@t.vn").get(f"/don-hang/thanh-cong/{o.code}").get_data(as_text=True)
    assert "<svg" in html and "pay-qr" in html
    assert "MÔ PHỎNG" in html
    assert f'<strong class="pay-code">{o.code}</strong>' in html          # nội dung CK = mã đơn
    assert "0011002233445" in html and "Chờ chuyển khoản" in html


def test_detail_page_shows_same_payment_block(app):
    o = _bank_order(app)
    html = login(app, "c@t.vn").get(f"/don-hang/chi-tiet/{o.code}").get_data(as_text=True)
    assert "pay-card" in html and o.code in html and "<svg" in html


def test_paid_or_cancelled_order_hides_qr(app):
    o = _bank_order(app, is_paid=True)
    html = login(app, "c@t.vn").get(f"/don-hang/chi-tiet/{o.code}").get_data(as_text=True)
    assert "Đã nhận được tiền" in html and "pay-qr" not in html
    o.is_paid, o.status = False, "cancelled"
    db.session.commit()
    html = login(app, "c@t.vn").get(f"/don-hang/chi-tiet/{o.code}").get_data(as_text=True)
    assert "Đơn đã hủy" in html and "pay-qr" not in html


def test_cod_order_has_no_payment_block(app):
    o = make_order(app)
    html = login(app, "c@t.vn").get(f"/don-hang/chi-tiet/{o.code}").get_data(as_text=True)
    assert "pay-card" not in html


def test_qr_payload_is_not_a_real_bank_qr_in_demo_mode(app):
    from utils.banks import qr_payload, get_bank, DEMO_PAYMENT
    o = _bank_order(app)
    payload = qr_payload(o, get_bank("vcb"))
    assert DEMO_PAYMENT and "KHONG PHAI GIAO DICH THAT" in payload
    assert payload.startswith("SNACKSHOP") and f"Noi dung: {o.code}" in payload   # không bắt đầu bằng "000201" (VietQR)


def test_staff_sees_reconciliation_hint(app):
    o = _bank_order(app)
    html = login(app, "s@t.vn").get(f"/admin/don-hang/chi-tiet/{o.code}").get_data(as_text=True)
    assert "Đối chiếu sao kê" in html and o.code in html
