"""Kiểm thử bảo mật: CSRF, đăng xuất bằng POST, chống dò mật khẩu, header, cookie."""
import re

import pytest

from app import create_app
from config import Config
from extensions import db
from models import User


class SecCfg(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = True  # bật thật để kiểm tra
    LOGIN_MAX_FAILURES = 3


@pytest.fixture
def app(tmp_path):
    class Cfg(SecCfg):
        BACKUP_FOLDER = str(tmp_path / "b")
        SYSTEM_UPLOAD_FOLDER = str(tmp_path / "s")
    app = create_app(Cfg)
    with app.app_context():
        u = User(full_name="Khách", email="k@t.vn", role="customer", phone="0912345678")
        u.set_password("pw123456")
        db.session.add(u)
        db.session.commit()
    return app


def token(client, url="/tai-khoan/dang-nhap"):
    html = client.get(url).get_data(as_text=True)
    return re.search(r'name="csrf_token"[^>]*value="([^"]+)"', html).group(1)


def test_post_without_csrf_token_is_rejected(app):
    c = app.test_client()
    r = c.post("/tai-khoan/dang-nhap", data={"email": "k@t.vn", "password": "pw123456"})
    assert r.status_code == 302  # bị chặn bởi CSRF, chuyển về trang trước
    assert c.get("/tai-khoan/thong-tin").status_code == 302  # chưa đăng nhập


def test_login_with_csrf_token_works_and_logout_requires_post(app):
    c = app.test_client()
    r = c.post("/tai-khoan/dang-nhap", data={"email": "k@t.vn", "password": "pw123456", "csrf_token": token(c)})
    assert r.status_code == 302 and "/dang-nhap" not in r.headers["Location"]
    assert c.get("/tai-khoan/dang-xuat").status_code == 405  # GET không đăng xuất được
    assert c.get("/tai-khoan/thong-tin").status_code == 200
    page = c.get("/").get_data(as_text=True)
    tok = re.search(r'name="csrf-token" content="([^"]+)"', page).group(1)
    assert c.post("/tai-khoan/dang-xuat", data={"csrf_token": tok}).status_code == 302
    assert c.get("/tai-khoan/thong-tin").status_code == 302


def test_ajax_post_without_token_gets_json_400(app):
    c = app.test_client()
    r = c.post("/gio-hang/them/1", headers={"X-Requested-With": "XMLHttpRequest"})
    assert r.status_code == 400 and r.get_json()["ok"] is False


def test_every_post_form_in_templates_carries_a_token():
    import glob
    for f in glob.glob("templates/**/*.html", recursive=True):
        s = open(f, encoding="utf-8").read()
        for m in re.finditer(r"<form\b[^>]*method=[\"']post[\"'][^>]*>", s, flags=re.I):
            body = s[m.end(): s.find("</form>", m.end())]
            assert "csrf_token" in body or "hidden_tag" in body, f"{f}: form POST thiếu CSRF token"


def test_bruteforce_lockout_after_repeated_failures(app):
    c = app.test_client()
    for _ in range(3):
        c.post("/tai-khoan/dang-nhap", data={"email": "k@t.vn", "password": "sai", "csrf_token": token(c)})
    # đã sai 3 lần: ngay cả mật khẩu đúng cũng bị chặn tạm thời
    r = c.post("/tai-khoan/dang-nhap", data={"email": "K@T.vn", "password": "pw123456", "csrf_token": token(c)})
    assert r.status_code == 429
    assert c.get("/tai-khoan/thong-tin").status_code == 302


def test_security_headers_and_cookie_flags(app):
    c = app.test_client()
    r = c.get("/")
    assert r.headers["X-Content-Type-Options"] == "nosniff"
    assert r.headers["X-Frame-Options"] == "SAMEORIGIN"
    assert "Referrer-Policy" in r.headers
    cookie = "; ".join(r.headers.getlist("Set-Cookie"))
    assert "HttpOnly" in cookie and "SameSite=Lax" in cookie


# ---------------- Chính sách mật khẩu ----------------

from utils.password_policy import password_error, is_default_or_weak


@pytest.mark.parametrize("pw,ok", [("abcdef", False), ("abcdefgh", False), ("12345678", False), ("admin123", False),
                                   ("Matkhau123", False), ("Tr0ngDuong9", True), ("abcdef12", True)])
def test_password_policy_rules(pw, ok):
    assert (password_error(pw) is None) == ok


def test_password_not_equal_to_email_local_part():
    assert password_error("nguyenvan1", "nguyenvan1@t.vn") is not None


def _register(c, pw):
    return c.post("/tai-khoan/dang-ky", data={"full_name": "Moi", "email": "n@t.vn", "phone": "0912345678",
                                              "password": pw, "confirm_password": pw, "csrf_token": token(c, "/tai-khoan/dang-ky")})


def test_register_rejects_weak_password_accepts_strong(app):
    c = app.test_client()
    assert _register(c, "abc123").status_code == 200  # form báo lỗi, ở lại trang
    with app.app_context():
        assert User.query.filter_by(email="n@t.vn").first() is None
    assert _register(c, "Tr0ngDuong9").status_code == 302
    with app.app_context():
        assert User.query.filter_by(email="n@t.vn").first() is not None


def test_default_password_flagged_on_backoffice_login(app):
    with app.app_context():
        u = User(full_name="QL", email="ql@t.vn", role="manager", phone="0912345678")
        u.set_password("quanly123")
        db.session.add(u)
        db.session.commit()
    assert is_default_or_weak("quanly123") and not is_default_or_weak("Tr0ngDuong9")
    c = app.test_client()
    c.post("/tai-khoan/dang-nhap", data={"email": "ql@t.vn", "password": "quanly123", "csrf_token": token(c)})
    assert "Đổi mật khẩu ngay" in c.get("/admin/").get_data(as_text=True)


# ---------------- Xác thực hai lớp (TOTP), CSP, giới hạn theo IP ----------------

from utils import totp


def test_totp_matches_rfc6238_vectors():
    import base64
    secret = base64.b32encode(b"12345678901234567890").decode().rstrip("=")  # khóa thử của RFC 6238 (SHA-1)
    assert totp.totp_now(secret, at=59) == "287082"
    assert totp.totp_now(secret, at=1111111109) == "081804"
    assert totp.verify(secret, "287082", at=59) and not totp.verify(secret, "000000", at=59)
    assert totp.verify(secret, "287082", at=59 + 30)  # lệch một khoảng vẫn nhận
    assert not totp.verify(secret, "287082", at=59 + 120)


def _login(c, email="k@t.vn", pw="pw123456"):
    return c.post("/tai-khoan/dang-nhap", data={"email": email, "password": pw, "csrf_token": token(c)})


def _enable_2fa(app, c):
    _login(c)
    c.get("/tai-khoan/bao-mat-2-lop")
    with c.session_transaction() as s:
        secret = s["2fa_setup_secret"]
    r = c.post("/tai-khoan/bao-mat-2-lop", data={"code": totp.totp_now(secret), "csrf_token": token(c, "/tai-khoan/bao-mat-2-lop")})
    assert r.status_code == 302
    return secret


def test_enable_2fa_then_login_needs_code(app):
    secret = _enable_2fa(app, app.test_client())
    c = app.test_client()
    r = _login(c)
    assert r.status_code == 302 and r.headers["Location"].endswith("/tai-khoan/xac-thuc-2-lop")
    assert c.get("/tai-khoan/thong-tin").status_code == 302  # chưa đăng nhập hẳn
    r = c.post("/tai-khoan/xac-thuc-2-lop", data={"code": "000000", "csrf_token": token(c, "/tai-khoan/xac-thuc-2-lop")})
    assert r.status_code == 200 and c.get("/tai-khoan/thong-tin").status_code == 302  # mã sai
    r = c.post("/tai-khoan/xac-thuc-2-lop", data={"code": totp.totp_now(secret), "csrf_token": token(c, "/tai-khoan/xac-thuc-2-lop")})
    assert r.status_code == 302
    assert c.get("/tai-khoan/thong-tin").status_code == 200


def test_2fa_step_unreachable_without_password_step(app):
    _enable_2fa(app, app.test_client())
    c = app.test_client()
    assert c.get("/tai-khoan/xac-thuc-2-lop").status_code == 302  # chưa qua bước mật khẩu
    assert c.post("/tai-khoan/xac-thuc-2-lop", data={"code": "123456", "csrf_token": token(c)}).status_code == 302


def test_2fa_wrong_codes_lock_out(app):
    secret = _enable_2fa(app, app.test_client())
    c = app.test_client()
    _login(c)
    for _ in range(3):
        c.post("/tai-khoan/xac-thuc-2-lop", data={"code": "000000", "csrf_token": token(c, "/tai-khoan/xac-thuc-2-lop")})
    r = c.post("/tai-khoan/xac-thuc-2-lop", data={"code": totp.totp_now(secret), "csrf_token": token(c, "/tai-khoan/xac-thuc-2-lop")})
    assert c.get("/tai-khoan/thong-tin").status_code == 302  # đúng mã nhưng đã bị khóa tạm


def test_admin_can_reset_two_factor(app):
    with app.app_context():
        a = User(full_name="Ad", email="ad@t.vn", role="admin")
        a.set_password("Adm1nStrong9")
        db.session.add(a)
        db.session.commit()
    _enable_2fa(app, app.test_client())
    ac = app.test_client()
    _login(ac, "ad@t.vn", "Adm1nStrong9")
    with app.app_context():
        uid = User.query.filter_by(email="k@t.vn").one().id
    tok = re.search(r'name="csrf-token" content="([^"]+)"', ac.get("/").get_data(as_text=True)).group(1)
    assert ac.post(f"/admin/he-thong/tai-khoan/{uid}/tat-2-lop", data={"csrf_token": tok}).status_code == 302
    with app.app_context():
        assert User.query.get(uid).totp_enabled is False


def test_content_security_policy_present(app):
    csp = app.test_client().get("/").headers["Content-Security-Policy"]
    assert "frame-ancestors 'self'" in csp and "object-src 'none'" in csp and "form-action 'self'" in csp


def test_ip_throttle_blocks_many_accounts_from_one_ip(app):
    app.config["LOGIN_MAX_FAILURES_PER_IP"] = 4
    c = app.test_client()
    for i in range(4):  # mỗi lần một email khác nhau nên không dính khóa theo email
        c.post("/tai-khoan/dang-nhap", data={"email": f"x{i}@t.vn", "password": "sai", "csrf_token": token(c)})
    r = _login(c)  # mật khẩu đúng nhưng IP này đã sai quá nhiều
    assert r.status_code == 429
