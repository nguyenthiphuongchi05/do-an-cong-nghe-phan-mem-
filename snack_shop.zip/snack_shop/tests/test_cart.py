import pytest
from app import create_app
from config import Config
from extensions import db
from models import Category, Product, User


class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False


@pytest.fixture
def app():
    app = create_app(TestConfig)
    with app.app_context():
        yield app


@pytest.fixture
def client(app):
    return app.test_client()


def _create_user_and_product(app):
    cat = Category(name="Test", slug="test")
    db.session.add(cat)
    db.session.flush()

    product = Product(name="Test snack", slug="test-snack", price=20000, stock=10, category_id=cat.id)
    db.session.add(product)

    user = User(full_name="Nguyen Van A", email="a@test.com", phone="0900000000")
    user.set_password("123456")
    db.session.add(user)
    db.session.commit()
    return user, product


def test_add_to_cart_requires_login(client):
    response = client.post("/gio-hang/them/1", follow_redirects=True)
    # Chưa đăng nhập -> bị chuyển hướng về trang login
    assert b"ang nh\xe1\xba\xadp" in response.data or response.status_code == 200


def test_login_and_add_to_cart(app, client):
    with app.app_context():
        user, product = _create_user_and_product(app)
        product_id = product.id

    client.post("/tai-khoan/dang-nhap", data={"email": "a@test.com", "password": "123456"}, follow_redirects=True)
    response = client.post(f"/gio-hang/them/{product_id}", data={"quantity": 2}, follow_redirects=True)
    assert response.status_code == 200
