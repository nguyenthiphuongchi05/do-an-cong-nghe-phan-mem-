"""Kiểm thử bộ sinh dữ liệu lịch sử: số liệu hợp lý và sổ kho đối soát khớp."""
import pytest

from app import create_app
from config import Config
from extensions import db
from models import User, Category, Product, Supplier, ChiNhanh, Order, PhieuNhap, ChuyenKho
import seed_history


class Cfg(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False


@pytest.fixture
def app(tmp_path):
    class C(Cfg):
        BACKUP_FOLDER = str(tmp_path / "b")
        SYSTEM_UPLOAD_FOLDER = str(tmp_path / "s")
    app = create_app(C)
    with app.app_context():
        b1 = ChiNhanh.query.first()
        b1.code = "CN01"
        b2, b3 = ChiNhanh(code="CN02", name="CN 2"), ChiNhanh(code="CN03", name="CN 3")
        db.session.add_all([b2, b3])
        db.session.flush()
        for i, b in enumerate((b1, b2, b3), 1):
            for role in ("manager", "staff"):
                u = User(full_name=f"{role}{i}", email=f"{role}{i}@t.vn", role=role, phone="0912345678", branch_id=b.id)
                u.set_password("pw123456")
                db.session.add(u)
        cat, sup = Category(name="Snack", slug="snack"), Supplier(name="NCC")
        db.session.add_all([cat, sup])
        db.session.flush()
        for i in range(12):
            p = Product(name=f"SP{i}", slug=f"sp{i}", price=10000 + i * 1000, category_id=cat.id, supplier_id=sup.id,
                        cost_price=6000 + i * 500)
            for b, q in ((b1, 40), (b2, 25), (b3, 0)):  # chi nhánh 3 hết sạch hàng: vẫn phải đối soát được
                p.set_stock(b.id, q)
            db.session.add(p)
        db.session.commit()
    return app


def test_history_generates_and_stock_ledger_reconciles(app):
    res = seed_history.run(app, orders=600, seed=3, n_customers=30, verbose=False)
    assert res["orders"] == 600 and res["receipts"] > 0
    rc = res["reconcile"]
    assert rc["bad"] == [] and rc["ok"] == rc["total"] == 36
    with app.app_context():
        assert Order.query.count() == 600
        assert {o.branch.code for o in Order.query.all()} == {"CN01", "CN02", "CN03"}
        assert PhieuNhap.query.filter_by(status="completed").count() == res["receipts"]
        # đơn hủy không tính vào bán; đơn nào cũng có chi nhánh
        assert Order.query.filter(Order.branch_id.is_(None)).count() == 0


def test_history_refuses_second_run_without_force(app):
    seed_history.run(app, orders=50, seed=1, n_customers=5, verbose=False)
    with pytest.raises(SystemExit):
        seed_history.run(app, orders=50, seed=1, n_customers=5, verbose=False)


def test_reconcile_accounts_for_transfers(app):
    seed_history.run(app, orders=100, seed=2, n_customers=5, verbose=False)
    with app.app_context():
        from utils.inventory import deduct_stock, add_stock
        p = Product.query.first()
        b1, b2 = ChiNhanh.query.filter_by(code="CN01").one(), ChiNhanh.query.filter_by(code="CN02").one()
        assert deduct_stock(p.id, b1.id, 5)
        add_stock(p.id, b2.id, 5)
        db.session.add(ChuyenKho(code="CK1", product_id=p.id, from_branch_id=b1.id, to_branch_id=b2.id, quantity=5,
                                 status="received"))
        db.session.commit()
        assert seed_history.reconcile_stock()["bad"] == []


def test_reconcile_accounts_for_approved_adjustments(app):
    seed_history.run(app, orders=100, seed=4, n_customers=5, verbose=False)
    with app.app_context():
        from models import PhieuDieuChinh
        from utils.inventory import add_stock
        p = Product.query.first()
        b1 = ChiNhanh.query.filter_by(code="CN01").one()
        mgr = User.query.filter_by(email="manager1@t.vn").one()
        add_stock(p.id, b1.id, 7)  # kiểm kê thấy dư 7
        db.session.add(PhieuDieuChinh(code="DC1", branch_id=b1.id, product_id=p.id, system_qty=0, actual_qty=7, diff=7,
                                      reason="count", status="approved", created_by_id=mgr.id))
        db.session.commit()
        assert seed_history.reconcile_stock()["bad"] == []
        add_stock(p.id, b1.id, 1)  # lệch 1 không có phiếu: phải bị phát hiện
        db.session.commit()
        assert len(seed_history.reconcile_stock()["bad"]) == 1


def test_history_spans_only_three_months(app):
    from datetime import datetime, timedelta
    seed_history.run(app, orders=200, seed=5, n_customers=5, verbose=False)
    with app.app_context():
        first = db.session.query(db.func.min(Order.created_at)).filter(Order.code.like("LS%")).scalar()
        last = db.session.query(db.func.max(Order.created_at)).filter(Order.code.like("LS%")).scalar()
        assert first >= datetime.utcnow() - timedelta(days=92)
        assert last <= datetime.utcnow()


def test_stats_page_has_two_revenue_charts(app):
    seed_history.run(app, orders=200, seed=6, n_customers=5, verbose=False)
    c = app.test_client()
    from werkzeug.security import generate_password_hash
    with app.app_context():
        u = User(full_name="CM", email="cm@t.vn", role="chain_manager", phone="0912345678",
                 password_hash=generate_password_hash("pw123456"))
        db.session.add(u)
        db.session.commit()
    c.post("/tai-khoan/dang-nhap", data={"email": "cm@t.vn", "password": "pw123456"})
    html = c.get("/admin/bao-cao/thong-ke?days=90").get_data(as_text=True)
    assert 'id="revenueChart"' in html and 'id="chart2"' in html and "Doanh thu theo chi nhánh" in html
