import pytest
from app import create_app
from config import Config
from extensions import db
from models import Category, Product


class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False


@pytest.fixture
def app():
    app = create_app(TestConfig)
    with app.app_context():
        yield app


@pytest.fixture
def client(app):
    return app.test_client()


def test_homepage_status_ok(client):
    response = client.get("/")
    assert response.status_code == 200


def test_product_final_price_uses_sale_price(app):
    with app.app_context():
        cat = Category(name="Test", slug="test")
        db.session.add(cat)
        db.session.flush()

        product = Product(name="Test snack", slug="test-snack", price=20000, sale_price=15000, stock=10, category_id=cat.id)
        assert product.final_price == 15000
        assert product.is_on_sale is True


def test_product_list_page_status_ok(client):
    response = client.get("/san-pham/")
    assert response.status_code == 200
