"""Kiểm thử mô hình vai trò mới: Quản lý chuỗi / Quản lý chi nhánh / Nhân viên, phiếu điều chỉnh kho, quản lý nhân sự."""
import pytest
from flask import g, has_app_context
from flask.testing import FlaskClient

from app import create_app
from config import Config
from extensions import db
from models import User, Category, Product, Supplier, ChiNhanh, PhieuDieuChinh, NhatKyHeThong


class FreshUserClient(FlaskClient):
    def open(self, *args, **kwargs):
        if has_app_context():
            g.pop("_login_user", None)
        return super().open(*args, **kwargs)


class Cfg(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False


@pytest.fixture
def app(tmp_path):
    class C(Cfg):
        BACKUP_FOLDER = str(tmp_path / "b")
        SYSTEM_UPLOAD_FOLDER = str(tmp_path / "s")
    app = create_app(C)
    app.test_client_class = FreshUserClient
    with app.app_context():
        b1 = ChiNhanh.query.first()
        b1.code = "CN01"
        b2 = ChiNhanh(code="CN02", name="Chi nhánh 2")
        db.session.add(b2)
        db.session.flush()
        for name, email, role, branch in [
            ("Admin", "a@t.vn", "admin", None), ("Chain", "cm@t.vn", "chain_manager", None),
            ("M1", "m1@t.vn", "manager", b1.id), ("M2", "m2@t.vn", "manager", b2.id),
            ("S1", "s1@t.vn", "staff", b1.id), ("S2", "s2@t.vn", "staff", b2.id),
            ("Cust", "c@t.vn", "customer", None),
        ]:
            u = User(full_name=name, email=email, role=role, phone="0912345678", branch_id=branch)
            u.set_password("pw123456")
            db.session.add(u)
        cat, sup = Category(name="Snack", slug="snack"), Supplier(name="NCC")
        db.session.add_all([cat, sup])
        db.session.flush()
        p = Product(name="Oreo", slug="oreo", price=10000, category_id=cat.id, supplier_id=sup.id, cost_price=6000)
        p.set_stock(b1.id, 50)
        p.set_stock(b2.id, 30)
        db.session.add(p)
        db.session.commit()
        yield app


def login(app, email):
    c = app.test_client()
    assert c.post("/tai-khoan/dang-nhap", data={"email": email, "password": "pw123456"}).status_code == 302
    return c


def stock(code):
    db.session.expire_all()
    return Product.query.first().stock_at(ChiNhanh.query.filter_by(code=code).one().id)


def uid(email):
    return User.query.filter_by(email=email).one().id


def make_ticket(client, actual, reason="count", note=""):
    return client.post("/admin/dieu-chinh-kho/tao", data={
        "product_id": Product.query.first().id, "actual_qty": actual, "reason": reason, "note": note})


# ====================== Phiếu điều chỉnh kho ======================

def test_staff_creates_adjustment_stock_unchanged_until_approved(app):
    r = make_ticket(login(app, "s1@t.vn"), 45, "damaged")
    assert r.status_code == 302
    t = PhieuDieuChinh.query.one()
    assert (t.system_qty, t.actual_qty, t.diff, t.status) == (50, 45, -5, "pending")
    assert t.code.startswith("DC") and t.branch.code == "CN01" and t.created_by.email == "s1@t.vn"
    assert stock("CN01") == 50  # chưa duyệt thì chưa đổi


def test_branch_manager_approves_staff_ticket_and_stock_changes(app):
    make_ticket(login(app, "s1@t.vn"), 45, "damaged")
    t = PhieuDieuChinh.query.one()
    assert login(app, "s1@t.vn").post(f"/admin/dieu-chinh-kho/{t.id}/duyet").status_code == 403  # nhân viên không duyệt
    assert login(app, "m1@t.vn").post(f"/admin/dieu-chinh-kho/{t.id}/duyet").status_code == 302
    db.session.expire_all()
    t = PhieuDieuChinh.query.one()
    assert t.status == "approved" and t.reviewed_by.email == "m1@t.vn" and stock("CN01") == 45
    login(app, "m1@t.vn").post(f"/admin/dieu-chinh-kho/{t.id}/duyet")  # duyệt lần 2 không trừ thêm
    assert stock("CN01") == 45
    assert NhatKyHeThong.query.filter_by(action="stock_adjust_approve").count() == 1


def test_positive_adjustment_adds_stock(app):
    make_ticket(login(app, "s2@t.vn"), 35, "mistake")  # CN02 có 30, đếm được 35
    t = PhieuDieuChinh.query.one()
    login(app, "m2@t.vn").post(f"/admin/dieu-chinh-kho/{t.id}/duyet")
    assert stock("CN02") == 35 and stock("CN01") == 50


def test_other_branch_manager_cannot_see_or_approve(app):
    make_ticket(login(app, "s1@t.vn"), 40)
    t = PhieuDieuChinh.query.one()
    assert login(app, "m2@t.vn").post(f"/admin/dieu-chinh-kho/{t.id}/duyet").status_code == 404
    assert t.code not in login(app, "m2@t.vn").get("/admin/dieu-chinh-kho").get_data(as_text=True)
    assert stock("CN01") == 50


def test_manager_ticket_needs_chain_manager_not_self_or_peer(app):
    make_ticket(login(app, "m1@t.vn"), 48, "lost")
    t = PhieuDieuChinh.query.one()
    assert login(app, "m1@t.vn").post(f"/admin/dieu-chinh-kho/{t.id}/duyet").status_code == 403  # tự duyệt
    assert login(app, "m2@t.vn").post(f"/admin/dieu-chinh-kho/{t.id}/duyet").status_code in (403, 404)
    assert login(app, "s1@t.vn").post(f"/admin/dieu-chinh-kho/{t.id}/duyet").status_code == 403
    assert stock("CN01") == 50
    assert login(app, "cm@t.vn").post(f"/admin/dieu-chinh-kho/{t.id}/duyet").status_code == 302
    assert stock("CN01") == 48


def test_chain_manager_cannot_create_but_can_review_any_branch(app):
    cm = login(app, "cm@t.vn")
    assert cm.get("/admin/dieu-chinh-kho/tao").status_code == 403
    make_ticket(login(app, "s2@t.vn"), 20)
    assert PhieuDieuChinh.query.one().code in cm.get("/admin/dieu-chinh-kho").get_data(as_text=True)


def test_admin_has_no_access_to_adjustments(app):
    assert login(app, "a@t.vn").get("/admin/dieu-chinh-kho").status_code == 403


def test_reject_requires_reason_and_keeps_stock(app):
    make_ticket(login(app, "s1@t.vn"), 40)
    t = PhieuDieuChinh.query.one()
    m = login(app, "m1@t.vn")
    m.post(f"/admin/dieu-chinh-kho/{t.id}/tu-choi", data={"note": ""})
    db.session.expire_all()
    assert PhieuDieuChinh.query.one().status == "pending"
    m.post(f"/admin/dieu-chinh-kho/{t.id}/tu-choi", data={"note": "Đếm lại đi"})
    db.session.expire_all()
    t = PhieuDieuChinh.query.one()
    assert t.status == "rejected" and t.review_note == "Đếm lại đi" and stock("CN01") == 50
    assert m.post(f"/admin/dieu-chinh-kho/{t.id}/duyet").status_code == 403  # đã xử lý rồi


def test_adjustment_validation(app):
    c = login(app, "s1@t.vn")
    assert make_ticket(c, 50).status_code == 200  # bằng tồn: không có chênh lệch
    assert make_ticket(c, -1).status_code == 200
    assert make_ticket(c, 40, reason="other", note="").status_code == 200  # lý do khác phải ghi rõ
    assert make_ticket(c, 40, reason="bogus").status_code == 200
    assert PhieuDieuChinh.query.count() == 0
    assert make_ticket(c, 40, reason="other", note="Chuột cắn").status_code == 302


def test_approval_fails_if_stock_sold_meanwhile(app):
    make_ticket(login(app, "s1@t.vn"), 10, "lost")  # 50 -> 10: cần trừ 40
    t = PhieuDieuChinh.query.one()
    from utils.inventory import deduct_stock
    assert deduct_stock(Product.query.first().id, ChiNhanh.query.filter_by(code="CN01").one().id, 20)  # bán bớt 20, còn 30
    db.session.commit()
    login(app, "m1@t.vn").post(f"/admin/dieu-chinh-kho/{t.id}/duyet")
    db.session.expire_all()
    assert PhieuDieuChinh.query.one().status == "pending" and stock("CN01") == 30  # phiếu vẫn chờ, không âm kho


def test_unassigned_backoffice_user_cannot_create_ticket(app):
    with app.app_context():
        u = User(full_name="Free", email="free@t.vn", role="staff", phone="0912345678")
        u.set_password("pw123456")
        db.session.add(u)
        db.session.commit()
    assert login(app, "free@t.vn").get("/admin/dieu-chinh-kho/tao").status_code == 403


def test_product_edit_cannot_change_stock_any_more(app):
    p = Product.query.first()
    cm = login(app, "cm@t.vn")
    page = cm.get(f"/admin/san-pham/sua/{p.id}").get_data(as_text=True)
    assert 'name="stock"' not in page
    cm.post(f"/admin/san-pham/sua/{p.id}", data={"name": "Oreo", "category_id": p.category_id, "price": 12000,
                                                   "stock": 999, "description": ""})
    db.session.expire_all()
    assert stock("CN01") == 50 and stock("CN02") == 30 and Product.query.first().price == 12000


# ====================== Quản lý nhân sự ======================

def add(client, **kw):
    data = {"full_name": "NV Mới", "email": "moi@t.vn", "phone": "0912345678", "role": "staff",
            "branch_id": ChiNhanh.query.filter_by(code="CN01").one().id, "password": "Moi12345x"}
    data.update(kw)
    return client.post("/admin/nhan-su/them", data=data)


def test_branch_manager_creates_staff_in_own_branch_only(app):
    b2 = ChiNhanh.query.filter_by(code="CN02").one()
    m1 = login(app, "m1@t.vn")
    assert add(m1, branch_id=b2.id).status_code == 302  # cố tình gửi chi nhánh 2 -> bị ép về chi nhánh 1
    u = User.query.filter_by(email="moi@t.vn").one()
    assert u.role == "staff" and u.branch.code == "CN01" and u.check_password("Moi12345x")


@pytest.mark.parametrize("role", ["manager", "chain_manager", "admin", "customer", "bogus"])
def test_branch_manager_cannot_create_other_roles(app, role):
    assert add(login(app, "m1@t.vn"), role=role).status_code in (403, 200)
    assert User.query.filter_by(email="moi@t.vn").first() is None


@pytest.mark.parametrize("role", ["chain_manager", "admin", "customer"])
def test_chain_manager_cannot_create_admin_or_chain_manager(app, role):
    assert add(login(app, "cm@t.vn"), role=role).status_code in (403, 200)
    assert User.query.filter_by(email="moi@t.vn").first() is None


def test_chain_manager_creates_branch_manager_in_any_branch(app):
    b2 = ChiNhanh.query.filter_by(code="CN02").one()
    cm = login(app, "cm@t.vn")
    assert add(cm, role="manager", branch_id=b2.id).status_code == 302
    u = User.query.filter_by(email="moi@t.vn").one()
    assert u.role == "manager" and u.branch.code == "CN02"


def test_weak_password_and_duplicate_email_rejected(app):
    m1 = login(app, "m1@t.vn")
    assert add(m1, password="abc").status_code == 200
    assert add(m1, password="Moi12345x", email="s1@t.vn").status_code == 200  # email đã có
    assert User.query.filter_by(email="moi@t.vn").first() is None


def test_blank_password_generates_temporary_one(app):
    c = login(app, "m1@t.vn")
    r = add(c, password="")
    assert r.status_code == 302
    page = c.get("/admin/nhan-su/").get_data(as_text=True)
    assert "Mật khẩu tạm" in page
    assert User.query.filter_by(email="moi@t.vn").one().role == "staff"


def test_branch_manager_cannot_manage_other_branch_or_other_roles_or_self(app):
    m1 = login(app, "m1@t.vn")
    for email in ("s2@t.vn", "m2@t.vn", "cm@t.vn", "a@t.vn", "m1@t.vn", "c@t.vn"):
        i = uid(email)
        assert m1.get(f"/admin/nhan-su/{i}/sua").status_code == 403, email
        assert m1.post(f"/admin/nhan-su/{i}/khoa").status_code == 403, email
        assert m1.post(f"/admin/nhan-su/{i}/dat-lai-mat-khau").status_code == 403, email
    db.session.expire_all()
    assert not User.query.filter_by(email="s2@t.vn").one().is_locked


def test_branch_manager_locks_unlocks_resets_own_staff(app):
    m1 = login(app, "m1@t.vn")
    i = uid("s1@t.vn")
    m1.post(f"/admin/nhan-su/{i}/khoa")
    db.session.expire_all()
    assert User.query.get(i).is_locked
    r = app.test_client().post("/tai-khoan/dang-nhap", data={"email": "s1@t.vn", "password": "pw123456"})
    assert r.status_code == 200  # bị khóa không đăng nhập được
    m1.post(f"/admin/nhan-su/{i}/khoa")
    m1.post(f"/admin/nhan-su/{i}/dat-lai-mat-khau", data={"new_password": "Doimoi9999"})
    db.session.expire_all()
    u = User.query.get(i)
    assert not u.is_locked and u.check_password("Doimoi9999")
    m1.post(f"/admin/nhan-su/{i}/dat-lai-mat-khau", data={"new_password": "yeu"})  # yếu: giữ nguyên
    db.session.expire_all()
    assert User.query.get(i).check_password("Doimoi9999")


def test_edit_cannot_change_role_email_and_branch_manager_cannot_move_branch(app):
    m1 = login(app, "m1@t.vn")
    i = uid("s1@t.vn")
    b2 = ChiNhanh.query.filter_by(code="CN02").one()
    assert m1.get(f"/admin/nhan-su/{i}/sua").status_code == 200
    # giao diện không gửi email / vai trò khi sửa; kể cả cố tình gửi lên cũng bị bỏ qua
    m1.post(f"/admin/nhan-su/{i}/sua", data={"full_name": "Tên Mới", "email": "hack@t.vn", "phone": "0987654321",
                                             "role": "admin", "branch_id": b2.id})
    db.session.expire_all()
    u = User.query.get(i)
    assert (u.full_name, u.phone, u.role, u.email, u.branch.code) == ("Tên Mới", "0987654321", "staff", "s1@t.vn", "CN01")
    cm = login(app, "cm@t.vn")  # quản lý chuỗi được chuyển nhân viên sang chi nhánh khác
    cm.post(f"/admin/nhan-su/{i}/sua", data={"full_name": "Tên Mới", "phone": "0987654321", "branch_id": b2.id})
    db.session.expire_all()
    assert User.query.get(i).branch.code == "CN02"


def test_chain_manager_manages_managers_but_not_admin(app):
    cm = login(app, "cm@t.vn")
    assert cm.get(f"/admin/nhan-su/{uid('m1@t.vn')}/sua").status_code == 200
    assert cm.post(f"/admin/nhan-su/{uid('a@t.vn')}/khoa").status_code == 403
    assert cm.post(f"/admin/nhan-su/{uid('cm@t.vn')}/khoa").status_code == 403


def test_team_pages_forbidden_for_staff_admin_customer(app):
    for email in ("s1@t.vn", "a@t.vn", "c@t.vn"):
        assert login(app, email).get("/admin/nhan-su/").status_code == 403, email
    assert app.test_client().get("/admin/nhan-su/").status_code == 302


def test_team_list_is_scoped(app):
    page = login(app, "m1@t.vn").get("/admin/nhan-su/").get_data(as_text=True)
    assert "s1@t.vn" in page and "s2@t.vn" not in page and "m2@t.vn" not in page
    page = login(app, "cm@t.vn").get("/admin/nhan-su/").get_data(as_text=True)
    assert all(e in page for e in ("s1@t.vn", "s2@t.vn", "m1@t.vn", "m2@t.vn")) and "a@t.vn" not in page.replace("cm@t.vn", "")


# ====================== Phạm vi dữ liệu của quản lý chuỗi ======================

def test_chain_manager_sees_all_branches_in_reports_and_branch_manager_only_own(app):
    from models import Order
    cust = User.query.filter_by(email="c@t.vn").one()
    for code, bc in (("A", "CN01"), ("B", "CN02")):
        db.session.add(Order(user_id=cust.id, code=f"DH-{code}", receiver_name="x", receiver_phone="0912345678",
                             shipping_address="x", subtotal_amount=1, total_amount=100000, status="completed",
                             branch_id=ChiNhanh.query.filter_by(code=bc).one().id))
    db.session.commit()
    cm = login(app, "cm@t.vn")
    assert "200.000" in cm.get("/admin/bao-cao/thong-ke").get_data(as_text=True)  # cả hai chi nhánh
    dash = cm.get("/admin/").get_data(as_text=True)
    assert "theo chi nhánh" in dash and "CN01" in dash and "CN02" in dash
    m1 = login(app, "m1@t.vn").get("/admin/bao-cao/thong-ke").get_data(as_text=True)
    assert "200.000" not in m1 and "100.000" in m1
