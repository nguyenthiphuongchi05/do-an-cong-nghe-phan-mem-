"""Đăng nhập bằng tên đăng nhập, voucher mẫu, liên hệ theo chi nhánh."""
import pytest
from app import create_app
from config import Config
from extensions import db
from models import User, ChiNhanh, Voucher


@pytest.fixture
def app(tmp_path):
    class C(Config):
        TESTING = True
        SQLALCHEMY_DATABASE_URI = "sqlite://"
        WTF_CSRF_ENABLED = False
        BACKUP_FOLDER = str(tmp_path / "b")
        SYSTEM_UPLOAD_FOLDER = str(tmp_path / "s")
    app = create_app(C)
    with app.app_context():
        b = ChiNhanh.query.first()
        b.address, b.phone = "1 Phố Cổ, Hà Nội", "02400000000"
        u = User(full_name="QL", email="quanlychuoi@snackshop.vn", role="chain_manager", phone="0912345678")
        u.set_password("pw123456")
        db.session.add(u)
        db.session.commit()
        yield app


def test_login_with_username_only(app):
    c = app.test_client()
    r = c.post("/tai-khoan/dang-nhap", data={"email": "quanlychuoi", "password": "pw123456"})
    assert r.status_code == 302


def test_login_with_full_email_and_wrong_password(app):
    r = app.test_client().post("/tai-khoan/dang-nhap", data={"email": "quanlychuoi", "password": "sai"})
    assert r.status_code == 200 and "không đúng" in r.get_data(as_text=True)


def test_login_shows_field_errors(app):
    r = app.test_client().post("/tai-khoan/dang-nhap", data={"email": "quanlychuoi", "password": ""})
    assert "Vui lòng nhập mật khẩu" in r.get_data(as_text=True)


def test_footer_shows_selected_branch_contact(app):
    c = app.test_client()
    with app.app_context():
        bid = ChiNhanh.query.first().id
    html = c.get("/").get_data(as_text=True)
    assert "1 Phố Cổ, Hà Nội" in html or "Hotline" in html
    with c.session_transaction() as s:
        s["branch_id"] = bid
    html = c.get("/").get_data(as_text=True)
    assert "1 Phố Cổ, Hà Nội" in html and "02400000000" in html
