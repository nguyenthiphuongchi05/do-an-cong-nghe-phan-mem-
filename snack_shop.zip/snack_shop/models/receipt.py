from datetime import datetime
from extensions import db

RECEIPT_STATUSES = ["pending", "completed", "cancelled"]

RECEIPT_STATUS_META = {
    "pending": {"label": "Chờ nhập hàng", "class": "bg-warning text-dark"},
    "completed": {"label": "Đã nhập kho", "class": "bg-success"},
    "cancelled": {"label": "Đã hủy", "class": "bg-secondary"},
}


class PhieuNhap(db.Model):
    """Phiếu nhập hàng: quản lý lập phiếu + phân công nhân viên, nhân viên ghi nhận số lượng
    thực nhận -> khi hoàn tất, tồn kho sản phẩm được cộng tương ứng."""
    __tablename__ = "phieu_nhap"

    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False)  # ví dụ PN20261015001
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=False)

    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)  # quản lý lập phiếu
    assigned_to_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)  # nhân viên được phân công
    received_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)  # người ghi nhận nhập thực tế

    branch_id = db.Column(db.Integer, db.ForeignKey("chi_nhanh.id"), nullable=True, index=True)  # chi nhánh nhận hàng
    status = db.Column(db.String(20), nullable=False, default="pending")
    note = db.Column(db.String(500))
    total_amount = db.Column(db.Integer, nullable=False, default=0)  # tổng giá trị thực nhập (tính khi hoàn tất)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    received_at = db.Column(db.DateTime, nullable=True)

    supplier = db.relationship("Supplier")
    branch = db.relationship("ChiNhanh", foreign_keys=[branch_id])
    created_by = db.relationship("User", foreign_keys=[created_by_id])
    assigned_to = db.relationship("User", foreign_keys=[assigned_to_id])
    received_by = db.relationship("User", foreign_keys=[received_by_id])
    items = db.relationship(
        "ChiTietPhieuNhap", backref="receipt", lazy=True, cascade="all, delete-orphan",
        order_by="ChiTietPhieuNhap.id",
    )

    @property
    def status_label(self):
        return RECEIPT_STATUS_META.get(self.status, {}).get("label", self.status)

    @property
    def status_class(self):
        return RECEIPT_STATUS_META.get(self.status, {}).get("class", "bg-secondary")

    @property
    def expected_amount(self):
        """Giá trị dự kiến theo số lượng đặt."""
        return sum(i.quantity * i.import_price for i in self.items)

    def __repr__(self):
        return f"<PhieuNhap {self.code}>"


class ChiTietPhieuNhap(db.Model):
    """Từng dòng hàng trong phiếu nhập."""
    __tablename__ = "chi_tiet_phieu_nhap"

    id = db.Column(db.Integer, primary_key=True)
    receipt_id = db.Column(db.Integer, db.ForeignKey("phieu_nhap.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)

    quantity = db.Column(db.Integer, nullable=False)  # số lượng dự kiến nhập
    received_quantity = db.Column(db.Integer, nullable=True)  # số lượng thực nhận (nhân viên ghi nhận)
    import_price = db.Column(db.Integer, nullable=False, default=0)  # giá nhập / đơn vị (VNĐ)
    expiry_date = db.Column(db.Date, nullable=True)  # hạn sử dụng của lô hàng

    product = db.relationship("Product")

    @property
    def subtotal(self):
        """Thành tiền: theo số lượng thực nhận nếu đã ghi nhận, ngược lại theo số lượng dự kiến."""
        qty = self.received_quantity if self.received_quantity is not None else self.quantity
        return qty * self.import_price
