from extensions import db

# Giá trị mặc định cho cấu hình hệ thống / thông tin cửa hàng
DEFAULT_SETTINGS = {
    "store_name": "SnackShop",
    "store_slogan": "Chuyên cung cấp đồ ăn vặt và nước giải khát chất lượng, ngon miệng, an toàn.",
    "store_address": "Quận Cầu Giấy, Hà Nội, Việt Nam",
    "store_phone": "0123.456.789",
    "store_email": "contact@snackshop.vn",
    "logo_filename": "",
    "maintenance_mode": "0",
    "maintenance_message": "Hệ thống đang được bảo trì, vui lòng quay lại sau ít phút.",
}


class CauHinhHeThong(db.Model):
    """Cấu hình dạng key-value (tên cửa hàng, logo, chế độ bảo trì...)."""
    __tablename__ = "cau_hinh_he_thong"

    key = db.Column(db.String(60), primary_key=True)
    value = db.Column(db.Text, nullable=False, default="")


def get_setting(key, default=None):
    row = db.session.get(CauHinhHeThong, key)
    if row is not None:
        return row.value
    return DEFAULT_SETTINGS.get(key, default) if default is None else default


def get_all_settings():
    data = dict(DEFAULT_SETTINGS)
    for row in CauHinhHeThong.query.all():
        data[row.key] = row.value
    return data


def set_setting(key, value):
    """Ghi 1 cấu hình (chưa commit — caller tự commit)."""
    row = db.session.get(CauHinhHeThong, key)
    if row is None:
        db.session.add(CauHinhHeThong(key=key, value=value or ""))
    else:
        row.value = value or ""
