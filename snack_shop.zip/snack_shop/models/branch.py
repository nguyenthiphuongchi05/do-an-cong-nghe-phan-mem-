"""Chi nhánh và tồn kho theo từng chi nhánh."""
from datetime import datetime

from extensions import db


class ChiNhanh(db.Model):
    """Một chi nhánh (cửa hàng). Mỗi chi nhánh có tồn kho, đơn hàng, phiếu nhập và nhân sự riêng."""
    __tablename__ = "chi_nhanh"

    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(10), unique=True, nullable=False)  # CN01, CN02...
    name = db.Column(db.String(120), nullable=False)
    address = db.Column(db.String(255))
    phone = db.Column(db.String(20))
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<ChiNhanh {self.code}>"


class TonKho(db.Model):
    """Số lượng tồn của một sản phẩm tại một chi nhánh (mỗi cặp sản phẩm - chi nhánh một dòng)."""
    __tablename__ = "ton_kho"
    __table_args__ = (db.UniqueConstraint("product_id", "branch_id", name="uq_ton_kho_product_branch"),)

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False, index=True)
    branch_id = db.Column(db.Integer, db.ForeignKey("chi_nhanh.id"), nullable=False, index=True)
    quantity = db.Column(db.Integer, nullable=False, default=0)

    branch = db.relationship("ChiNhanh")


class ChuyenKho(db.Model):
    """Một lần điều chuyển hàng giữa hai chi nhánh.
    in_transit: đã trừ kho chi nhánh gửi, hàng đang đi · received: chi nhánh nhận đã xác nhận (cộng kho nhận)
    cancelled: chi nhánh gửi thu hồi hoặc chi nhánh nhận từ chối (hoàn lại kho chi nhánh gửi)."""
    __tablename__ = "chuyen_kho"

    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False)  # CK20261022-001
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False, index=True)
    from_branch_id = db.Column(db.Integer, db.ForeignKey("chi_nhanh.id"), nullable=False, index=True)
    to_branch_id = db.Column(db.Integer, db.ForeignKey("chi_nhanh.id"), nullable=False, index=True)
    quantity = db.Column(db.Integer, nullable=False)
    note = db.Column(db.String(255))
    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    status = db.Column(db.String(20), nullable=False, default="in_transit", index=True)
    handled_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)  # người xác nhận nhận / hủy
    handled_at = db.Column(db.DateTime, nullable=True)
    response_note = db.Column(db.String(255), nullable=True)  # lý do hủy / từ chối

    STATUS_LABELS = {"in_transit": "Đang chuyển", "received": "Đã nhận", "cancelled": "Đã hủy"}
    STATUS_CLASSES = {"in_transit": "bg-warning text-dark", "received": "bg-success", "cancelled": "bg-secondary"}

    @property
    def status_label(self):
        return self.STATUS_LABELS.get(self.status, self.status)

    @property
    def status_class(self):
        return self.STATUS_CLASSES.get(self.status, "bg-secondary")

    product = db.relationship("Product")
    from_branch = db.relationship("ChiNhanh", foreign_keys=[from_branch_id])
    to_branch = db.relationship("ChiNhanh", foreign_keys=[to_branch_id])
    created_by = db.relationship("User", foreign_keys=[created_by_id])
    handled_by = db.relationship("User", foreign_keys=[handled_by_id])


ADJUST_REASONS = {
    "damaged": "Hàng hỏng / hết hạn",
    "lost": "Thất thoát / mất hàng",
    "count": "Kiểm kê chênh lệch",
    "mistake": "Nhập sai số lượng",
    "other": "Lý do khác (ghi rõ)",
}


class PhieuDieuChinh(db.Model):
    """Phiếu điều chỉnh tồn kho của một sản phẩm tại một chi nhánh (kiểm kê chênh lệch, hàng hỏng, thất thoát).

    system_qty: tồn trên hệ thống lúc lập phiếu · actual_qty: số đếm thực tế · diff = actual - system.
    Tồn kho chỉ đổi khi phiếu được DUYỆT: áp dụng đúng phần chênh lệch (diff) vào tồn hiện tại.
    Người lập không được tự duyệt phiếu của mình."""
    __tablename__ = "phieu_dieu_chinh"

    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False)  # DC20261022-001
    branch_id = db.Column(db.Integer, db.ForeignKey("chi_nhanh.id"), nullable=False, index=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False, index=True)
    system_qty = db.Column(db.Integer, nullable=False)
    actual_qty = db.Column(db.Integer, nullable=False)
    diff = db.Column(db.Integer, nullable=False)
    reason = db.Column(db.String(20), nullable=False)
    note = db.Column(db.String(255))
    status = db.Column(db.String(20), nullable=False, default="pending", index=True)  # pending | approved | rejected
    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    reviewed_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    reviewed_at = db.Column(db.DateTime, nullable=True)
    review_note = db.Column(db.String(255))

    STATUS_LABELS = {"pending": "Chờ duyệt", "approved": "Đã duyệt", "rejected": "Từ chối"}
    STATUS_CLASSES = {"pending": "bg-warning text-dark", "approved": "bg-success", "rejected": "bg-secondary"}

    branch = db.relationship("ChiNhanh")
    product = db.relationship("Product")
    created_by = db.relationship("User", foreign_keys=[created_by_id])
    reviewed_by = db.relationship("User", foreign_keys=[reviewed_by_id])

    @property
    def status_label(self):
        return self.STATUS_LABELS.get(self.status, self.status)

    @property
    def status_class(self):
        return self.STATUS_CLASSES.get(self.status, "bg-secondary")

    @property
    def reason_label(self):
        return ADJUST_REASONS.get(self.reason, self.reason)
