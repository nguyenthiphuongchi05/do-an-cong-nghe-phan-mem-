from extensions import db


class CartItem(db.Model):
    """
    Giỏ hàng lưu theo user_id trong DB (áp dụng cho user đã đăng nhập).
    Với khách chưa đăng nhập, nên xử lý giỏ hàng tạm bằng session ở routes/cart.py
    và chỉ ghi vào bảng này khi họ đăng nhập/checkout.
    """
    __tablename__ = "cart_items"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    quantity = db.Column(db.Integer, default=1, nullable=False)

    product = db.relationship("Product")

    __table_args__ = (db.UniqueConstraint("user_id", "product_id", name="uq_user_product"),)

    @property
    def subtotal(self):
        return self.product.final_price * self.quantity
