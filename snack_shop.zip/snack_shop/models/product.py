from datetime import datetime

from sqlalchemy import select, func
from sqlalchemy.ext.hybrid import hybrid_property

from extensions import db


class Product(db.Model):
    __tablename__ = "products"

    LOW_STOCK_THRESHOLD = 10  # tồn kho <= ngưỡng này sẽ hiện cảnh báo "sắp hết hàng"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(180), nullable=False)
    slug = db.Column(db.String(200), nullable=False, unique=True)
    description = db.Column(db.Text)
    price = db.Column(db.Integer, nullable=False)  # đơn vị: VNĐ
    sale_price = db.Column(db.Integer, nullable=True)  # giá khuyến mãi, có thể null
    cost_price = db.Column(db.Integer, nullable=True)  # giá vốn / giá nhập gần nhất (VNĐ), cập nhật khi nhập hàng

    # Ảnh: image_source phân biệt ảnh mặc định (static/) hay ảnh admin upload (uploads/)
    image_filename = db.Column(db.String(255))
    image_source = db.Column(db.String(10), default="default")  # 'default' | 'upload'

    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False)
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    stocks = db.relationship("TonKho", backref="product", lazy=True, cascade="all, delete-orphan")

    # ----- Tồn kho theo chi nhánh -----
    # `stock` là tồn của chi nhánh đang chọn (khách: chi nhánh đã chọn; nhân viên/quản lý: chi nhánh của mình).
    # Khi không chọn chi nhánh nào (Admin xem tất cả, hoặc chạy ngoài request) thì là tổng các chi nhánh.
    @hybrid_property
    def stock(self):
        from utils.branch import current_branch_id
        bid = current_branch_id()
        return sum(s.quantity for s in self.stocks if bid is None or s.branch_id == bid)

    @stock.setter
    def stock(self, value):
        """Đặt tồn kho của chi nhánh đang ghi (chi nhánh đang chọn, hoặc chi nhánh mặc định)."""
        from utils.branch import write_branch_id
        self.set_stock(write_branch_id(), value)

    @stock.expression
    def stock(cls):  # noqa: N805
        from models.branch import TonKho
        from utils.branch import current_branch_id
        bid = current_branch_id()
        q = select(func.coalesce(func.sum(TonKho.quantity), 0)).where(TonKho.product_id == cls.id)
        if bid is not None:
            q = q.where(TonKho.branch_id == bid)
        return q.correlate(cls).scalar_subquery()

    def stock_at(self, branch_id):
        return sum(s.quantity for s in self.stocks if s.branch_id == branch_id)

    def set_stock(self, branch_id, quantity):
        from models.branch import TonKho
        for s in self.stocks:
            if s.branch_id == branch_id:
                s.quantity = quantity
                return
        self.stocks.append(TonKho(branch_id=branch_id, quantity=quantity))

    @property
    def stock_by_branch(self):
        return {s.branch_id: s.quantity for s in self.stocks}

    @property
    def image_url(self):
        """Trả về URL ảnh đúng, tự phân biệt nguồn ảnh mặc định hay upload."""
        if not self.image_filename:
            return "/static/images/products/no-image.png"
        if self.image_filename.startswith("http://") or self.image_filename.startswith("https://"):
            return self.image_filename
        if self.image_source == "upload":
            return f"/uploads/products/{self.image_filename}"
        return f"/static/images/products/{self.image_filename}"

    @property
    def final_price(self):
        return self.sale_price if self.sale_price else self.price

    @property
    def is_on_sale(self):
        return bool(self.sale_price and self.sale_price < self.price)

    @property
    def is_out_of_stock(self):
        return self.stock <= 0

    @property
    def is_low_stock(self):
        """Còn hàng nhưng số lượng thấp -> hiện cảnh báo 'Sắp hết hàng'."""
        return 0 < self.stock <= self.LOW_STOCK_THRESHOLD

    @property
    def average_rating(self):
        if not self.reviews:
            return None
        return round(sum(r.rating for r in self.reviews) / len(self.reviews), 1)

    @property
    def review_count(self):
        return len(self.reviews)

    def __repr__(self):
        return f"<Product {self.name}>"
