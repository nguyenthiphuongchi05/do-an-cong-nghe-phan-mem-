from datetime import datetime
from extensions import db

# Nhóm sự kiện (cột category) và nhãn hiển thị
LOG_CATEGORIES = {
    "auth": "Đăng nhập / đăng xuất",
    "account": "Tài khoản & phân quyền",
    "config": "Cấu hình hệ thống",
    "backup": "Sao lưu / khôi phục",
    "maintenance": "Bảo trì",
    "product": "Sản phẩm & giá",
    "order": "Đơn hàng",
    "inventory": "Nhập hàng & tồn kho",
    "security": "Bảo mật (truy cập bị từ chối)",
    "error": "Lỗi hệ thống",
}

LOG_LEVELS = {
    "info": {"label": "Thông tin", "class": "bg-info text-dark"},
    "warning": {"label": "Cảnh báo", "class": "bg-warning text-dark"},
    "error": {"label": "Lỗi", "class": "bg-danger"},
}


class NhatKyHeThong(db.Model):
    """Nhật ký hệ thống: ghi nhận hoạt động của người dùng và các sự kiện bảo trì / lỗi.
    Lưu snapshot email + vai trò để vẫn đọc được lịch sử dù tài khoản sau này bị xóa/đổi quyền."""
    __tablename__ = "nhat_ky_he_thong"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    user_email = db.Column(db.String(120), nullable=True)
    user_role = db.Column(db.String(20), nullable=True)

    category = db.Column(db.String(20), nullable=False, default="auth", index=True)
    action = db.Column(db.String(60), nullable=False)  # mã hành động, ví dụ login, order_status, backup_create
    level = db.Column(db.String(10), nullable=False, default="info", index=True)
    description = db.Column(db.String(500), nullable=False)
    ip_address = db.Column(db.String(45), nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    user = db.relationship("User")

    @property
    def category_label(self):
        return LOG_CATEGORIES.get(self.category, self.category)

    @property
    def level_label(self):
        return LOG_LEVELS.get(self.level, {}).get("label", self.level)

    @property
    def level_class(self):
        return LOG_LEVELS.get(self.level, {}).get("class", "bg-secondary")
