from datetime import datetime
from extensions import db


class Review(db.Model):
    __tablename__ = "reviews"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    rating = db.Column(db.Integer, nullable=False)  # 1-5 sao
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    product = db.relationship("Product", backref=db.backref("reviews", cascade="all, delete-orphan"))
    user = db.relationship("User")

    # Mỗi khách chỉ được đánh giá 1 sản phẩm 1 lần (gửi lại thì cập nhật, không tạo bản ghi mới)
    __table_args__ = (db.UniqueConstraint("product_id", "user_id", name="uq_product_user_review"),)
