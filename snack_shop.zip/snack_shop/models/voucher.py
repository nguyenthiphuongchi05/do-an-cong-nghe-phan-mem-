from datetime import datetime
from utils.timeutil import vn_now
from extensions import db


class Voucher(db.Model):
    __tablename__ = "vouchers"

    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(30), unique=True, nullable=False)
    description = db.Column(db.String(255))

    discount_type = db.Column(db.String(10), nullable=False, default="percent")  # 'percent' | 'fixed'
    discount_value = db.Column(db.Integer, nullable=False)  # % (0-100) nếu percent, hoặc số tiền VNĐ nếu fixed
    max_discount_amount = db.Column(db.Integer, nullable=True)  # trần giảm giá, áp dụng cho loại percent
    min_order_amount = db.Column(db.Integer, nullable=False, default=0)  # đơn tối thiểu để dùng mã

    usage_limit = db.Column(db.Integer, nullable=True)  # tổng số lượt dùng tối đa, None = không giới hạn
    used_count = db.Column(db.Integer, nullable=False, default=0)

    expires_at = db.Column(db.DateTime, nullable=True)  # None = không hết hạn
    active = db.Column(db.Boolean, nullable=False, default=True)

    # None = áp dụng toàn hệ thống; có giá trị = chỉ dùng được ở chi nhánh đó
    branch_id = db.Column(db.Integer, db.ForeignKey("chi_nhanh.id"), nullable=True, index=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    branch = db.relationship("ChiNhanh")
    saved_by = db.relationship("SavedVoucher", back_populates="voucher", lazy=True, cascade="all, delete-orphan")

    @classmethod
    def for_branch(cls, query, branch_id):
        """Giới hạn truy vấn voucher ở những mã dùng được tại chi nhánh này (mã toàn hệ thống + mã riêng chi nhánh)."""
        if not branch_id:
            return query
        return query.filter(db.or_(cls.branch_id.is_(None), cls.branch_id == branch_id))

    def applies_to_branch(self, branch_id):
        return not self.branch_id or not branch_id or self.branch_id == branch_id

    @property
    def scope_label(self):
        return self.branch.name if self.branch_id and self.branch else "Toàn hệ thống"

    @property
    def is_expired(self):
        return bool(self.expires_at and self.expires_at < vn_now())

    @property
    def is_used_up(self):
        return bool(self.usage_limit and self.used_count >= self.usage_limit)

    @property
    def is_valid_now(self):
        """Voucher còn dùng được nói chung (chưa xét đơn hàng cụ thể)."""
        return self.active and not self.is_expired and not self.is_used_up

    @property
    def days_left(self):
        """Số ngày còn lại trước khi hết hạn. None = không có hạn dùng. 0 = đã hết hạn."""
        if not self.expires_at:
            return None
        delta = self.expires_at - vn_now()
        if delta.total_seconds() <= 0:
            return 0
        # làm tròn lên để "còn vài giờ" vẫn hiện ít nhất 1 ngày thay vì 0
        return delta.days + 1

    def is_used_by(self, user_id):
        """Kiểm tra user này đã từng đặt đơn dùng voucher này chưa (giới hạn 1 lần/người)."""
        from models.order import Order, OrderVoucher
        return (
            db.session.query(OrderVoucher.id)
            .join(Order, Order.id == OrderVoucher.order_id)
            .filter(Order.user_id == user_id, OrderVoucher.voucher_code == self.code)
            .first()
            is not None
        )

    def compute_discount(self, subtotal, user_id=None, branch_id=None):
        """
        Kiểm tra voucher có áp dụng được cho đơn có tổng tiền `subtotal` không.
        Trả về (ok: bool, message: str, discount_amount: int).
        Không tự thay đổi used_count ở đây — chỉ tính toán, việc trừ lượt dùng
        thực hiện ở routes khi đơn hàng được tạo thành công.
        """
        if branch_id is None:  # mặc định: chi nhánh khách đang chọn / đang mua
            from utils.branch import current_branch_id
            branch_id = current_branch_id()
        if not self.active:
            return False, "Mã giảm giá này hiện không khả dụng.", 0
        if not self.applies_to_branch(branch_id):
            return False, f"Mã này chỉ áp dụng tại {self.scope_label}.", 0
        if self.is_expired:
            return False, "Mã giảm giá đã hết hạn.", 0
        if self.is_used_up:
            return False, "Mã giảm giá đã hết lượt sử dụng.", 0
        if user_id is not None and self.is_used_by(user_id):
            return False, "Bạn đã sử dụng mã này rồi. Mỗi mã chỉ được dùng 1 lần trên mỗi khách hàng.", 0
        if subtotal < self.min_order_amount:
            return False, f"Đơn hàng cần tối thiểu {self.min_order_amount:,.0f}đ để dùng mã này.".replace(",", "."), 0

        if self.discount_type == "percent":
            discount = subtotal * self.discount_value // 100
            if self.max_discount_amount:
                discount = min(discount, self.max_discount_amount)
        else:  # fixed
            discount = self.discount_value

        discount = min(discount, subtotal)  # không giảm quá tổng tiền đơn hàng
        return True, "Áp dụng mã giảm giá thành công!", discount

    def __repr__(self):
        return f"<Voucher {self.code}>"


class SavedVoucher(db.Model):
    """Voucher mà user đã bấm 'Lưu mã' để dùng sau, hiện trong trang Voucher của tôi."""
    __tablename__ = "saved_vouchers"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    voucher_id = db.Column(db.Integer, db.ForeignKey("vouchers.id"), nullable=False)
    saved_at = db.Column(db.DateTime, default=datetime.utcnow)

    voucher = db.relationship("Voucher", back_populates="saved_by")
    user = db.relationship("User")

    __table_args__ = (db.UniqueConstraint("user_id", "voucher_id", name="uq_user_voucher"),)
