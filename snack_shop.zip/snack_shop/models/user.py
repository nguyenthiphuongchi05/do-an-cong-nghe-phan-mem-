from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from extensions import db, login_manager

# ---------- 5 vai trò của hệ thống ----------
ROLE_ADMIN = "admin"                  # quản trị hệ thống: tài khoản, phân quyền, cấu hình, sao lưu, nhật ký (KHÔNG xem số liệu bán hàng)
ROLE_CHAIN_MANAGER = "chain_manager"  # quản lý chuỗi: sản phẩm, giá chung, nhà cung cấp, voucher, báo cáo toàn chuỗi, duyệt điều chỉnh kho,
                                      # quản lý các quản lý chi nhánh (không gán chi nhánh, không bán hàng / xử lý đơn)
ROLE_MANAGER = "manager"              # quản lý chi nhánh: điều hành MỘT chi nhánh (đơn, nhập hàng, chuyển kho, nhân viên, báo cáo chi nhánh)
ROLE_STAFF = "staff"                  # nhân viên chi nhánh: bán hàng, xử lý đơn, nhập hàng theo phân công, lập phiếu điều chỉnh kho
ROLE_CUSTOMER = "customer"            # khách hàng: mua sắm trực tuyến

ROLES = [ROLE_ADMIN, ROLE_CHAIN_MANAGER, ROLE_MANAGER, ROLE_STAFF, ROLE_CUSTOMER]
BACKOFFICE_ROLES = [ROLE_ADMIN, ROLE_CHAIN_MANAGER, ROLE_MANAGER, ROLE_STAFF]
BRANCH_ROLES = [ROLE_MANAGER, ROLE_STAFF]  # vai trò bắt buộc thuộc đúng một chi nhánh

ROLE_LABELS = {
    ROLE_ADMIN: "Admin",
    ROLE_CHAIN_MANAGER: "Quản lý chuỗi",
    ROLE_MANAGER: "Quản lý chi nhánh",
    ROLE_STAFF: "Nhân viên",
    ROLE_CUSTOMER: "Khách hàng",
}

ROLE_BADGE_CLASSES = {
    ROLE_ADMIN: "bg-danger",
    ROLE_CHAIN_MANAGER: "bg-dark",
    ROLE_MANAGER: "bg-primary",
    ROLE_STAFF: "bg-warning text-dark",
    ROLE_CUSTOMER: "bg-secondary",
}

# Email của tài khoản hệ thống dùng cho đơn bán tại quầy (khách vãng lai), không đăng nhập được
WALKIN_EMAIL = "khachle@snackshop.local"


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    phone = db.Column(db.String(20))
    address = db.Column(db.String(255))
    password_hash = db.Column(db.String(255), nullable=False)

    role = db.Column(db.String(20), nullable=False, default=ROLE_CUSTOMER, index=True)
    is_locked = db.Column(db.Boolean, nullable=False, default=False)  # tài khoản bị khóa -> không đăng nhập được
    last_login_at = db.Column(db.DateTime, nullable=True)
    # Chi nhánh làm việc của quản lý / nhân viên (để trống = không bị giới hạn theo chi nhánh)
    branch_id = db.Column(db.Integer, db.ForeignKey("chi_nhanh.id"), nullable=True, index=True)
    # Xác thực hai lớp (TOTP): khóa bí mật và cờ đã bật
    totp_secret = db.Column(db.String(64), nullable=True)
    totp_enabled = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    branch = db.relationship("ChiNhanh", foreign_keys=[branch_id])
    orders = db.relationship("Order", backref="user", lazy=True, foreign_keys="Order.user_id")
    cart_items = db.relationship("CartItem", backref="user", lazy=True, cascade="all, delete-orphan")

    # ----- mật khẩu -----
    def set_password(self, raw_password):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password):
        return check_password_hash(self.password_hash, raw_password)

    # ----- Flask-Login: tài khoản bị khóa thì không được coi là "active" -----
    @property
    def is_active(self):
        return not self.is_locked

    # ----- vai trò -----
    @property
    def is_admin(self):
        return self.role == ROLE_ADMIN

    @property
    def is_manager(self):
        """Quản lý chi nhánh."""
        return self.role == ROLE_MANAGER

    @property
    def is_chain_manager(self):
        return self.role == ROLE_CHAIN_MANAGER

    @property
    def is_any_manager(self):
        """Quản lý chi nhánh hoặc quản lý chuỗi (xem số liệu kinh doanh)."""
        return self.role in (ROLE_MANAGER, ROLE_CHAIN_MANAGER)

    @property
    def is_staff(self):
        return self.role == ROLE_STAFF

    @property
    def is_customer(self):
        return self.role == ROLE_CUSTOMER

    @property
    def is_backoffice(self):
        """Admin / quản lý / nhân viên: được vào khu vực /admin."""
        return self.role in BACKOFFICE_ROLES

    @property
    def role_label(self):
        return ROLE_LABELS.get(self.role, self.role)

    @property
    def role_badge_class(self):
        return ROLE_BADGE_CLASSES.get(self.role, "bg-secondary")

    def has_permission(self, permission):
        from utils.permissions import role_has_permission
        return role_has_permission(self.role, permission)

    def __repr__(self):
        return f"<User {self.email} ({self.role})>"


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))
