from datetime import datetime
from extensions import db

ORDER_STATUSES = ["pending", "confirmed", "shipping", "completed", "cancelled"]


class Order(db.Model):
    __tablename__ = "orders"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    code = db.Column(db.String(20), unique=True, nullable=False)  # mã đơn hàng, ví dụ DH20260822001

    receiver_name = db.Column(db.String(120), nullable=False)
    receiver_phone = db.Column(db.String(20), nullable=False)
    shipping_address = db.Column(db.String(255), nullable=False)
    note = db.Column(db.String(255))

    subtotal_amount = db.Column(db.Integer, nullable=False, default=0)  # tổng tiền trước khi giảm giá
    discount_amount = db.Column(db.Integer, nullable=False, default=0)  # tổng số tiền được giảm (cộng dồn các mã)
    voucher_codes = db.Column(db.String(255), nullable=True)  # các mã đã áp dụng, cách nhau bởi dấu phẩy

    total_amount = db.Column(db.Integer, nullable=False, default=0)  # số tiền cuối cùng phải trả
    status = db.Column(db.String(20), default="pending", nullable=False, index=True)
    payment_method = db.Column(db.String(20), default="cod")  # cod | bank_transfer
    bank_code = db.Column(db.String(20), nullable=True)  # ngân hàng khách chọn để chuyển khoản (nếu payment_method=bank_transfer)

    is_paid = db.Column(db.Boolean, nullable=False, default=False)  # đã xác nhận nhận được tiền chưa

    channel = db.Column(db.String(20), nullable=False, default="online")  # online | counter (bán tại quầy)
    branch_id = db.Column(db.Integer, db.ForeignKey("chi_nhanh.id"), nullable=True, index=True)  # chi nhánh bán / giao đơn này

    # Nhân viên xử lý đơn (dùng để thống kê hiệu suất)
    handled_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    handled_at = db.Column(db.DateTime, nullable=True)
    completed_at = db.Column(db.DateTime, nullable=True)

    # Yêu cầu đổi / hủy đơn từ khách hàng (mỗi đơn tối đa 1 yêu cầu đang xử lý)
    request_type = db.Column(db.String(20), nullable=True)  # cancel | exchange
    request_reason = db.Column(db.String(255), nullable=True)
    request_status = db.Column(db.String(20), nullable=True)  # pending | approved | rejected
    request_at = db.Column(db.DateTime, nullable=True)
    request_note = db.Column(db.String(255), nullable=True)  # phản hồi của nhân viên
    request_handled_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    branch = db.relationship("ChiNhanh", foreign_keys=[branch_id])
    handled_by = db.relationship("User", foreign_keys=[handled_by_id])
    request_handled_by = db.relationship("User", foreign_keys=[request_handled_by_id])

    items = db.relationship("OrderItem", backref="order", lazy=True, cascade="all, delete-orphan")
    applied_vouchers = db.relationship("OrderVoucher", backref="order", lazy=True, cascade="all, delete-orphan")

    @property
    def has_pending_request(self):
        return self.request_status == "pending"

    @property
    def profit(self):
        """Lợi nhuận gộp ước tính (chỉ tính các dòng đã có giá vốn)."""
        return sum((i.price - i.cost_price) * i.quantity for i in self.items if i.cost_price is not None)

    @property
    def voucher_code_list(self):
        return [c for c in (self.voucher_codes or "").split(",") if c]


class OrderItem(db.Model):
    __tablename__ = "order_items"

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)

    product_name = db.Column(db.String(180), nullable=False)  # lưu lại tên tại thời điểm mua
    price = db.Column(db.Integer, nullable=False)  # giá tại thời điểm mua
    quantity = db.Column(db.Integer, nullable=False, default=1)
    cost_price = db.Column(db.Integer, nullable=True)  # giá vốn tại thời điểm bán (để tính lợi nhuận)

    product = db.relationship("Product")

    @property
    def subtotal(self):
        return self.price * self.quantity


class OrderVoucher(db.Model):
    """Chi tiết từng mã voucher đã áp dụng cho 1 đơn hàng (hỗ trợ nhiều mã/đơn)."""
    __tablename__ = "order_vouchers"

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False)
    voucher_code = db.Column(db.String(30), nullable=False)  # lưu snapshot mã, không FK để giữ lịch sử dù voucher bị xóa
    discount_amount = db.Column(db.Integer, nullable=False, default=0)
