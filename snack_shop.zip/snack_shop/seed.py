"""
Script tạo dữ liệu mẫu: 1 tài khoản admin, 4 danh mục (kèm icon), 4 nhà cung cấp, và ~30 sản phẩm.
Ảnh sản phẩm lấy từ static/images/products/ (mọi sản phẩm trong danh sách đều có ảnh thật;
có thể upload ảnh ở trang quản trị).

Chạy: python seed.py
"""
from app import create_app
from extensions import db
from models import (User, Category, Supplier, Product, Voucher, Review, PhieuNhap, ChiTietPhieuNhap,
                    Order, OrderItem, ChiNhanh)
from utils.helpers import slugify
from datetime import datetime, timedelta

app = create_app()


def placeholder_image(slug):
    return f"https://picsum.photos/seed/{slug}/400/400"


OLD_BRANCH_NAMES = {"Chi nhánh 1", "Chi nhánh Quận 1", "Chi nhánh Thủ Đức", "Chi nhánh Bình Thạnh"}

with app.app_context():
    db.create_all()

    # --- 3 chi nhánh ---
    branch_defs = [
        ("CN01", "Chi nhánh Hà Nội", "25 Tràng Tiền, Hoàn Kiếm, Hà Nội", "02438881111"),
        ("CN02", "Chi nhánh TP.HCM", "12 Nguyễn Huệ, Quận 1, TP.HCM", "02838882222"),
        ("CN03", "Chi nhánh Nam Định", "88 Trần Hưng Đạo, TP. Nam Định, Nam Định", "02283883333"),
    ]
    branches = {}
    for code, bname, addr, bphone in branch_defs:
        b = ChiNhanh.query.filter_by(code=code).first()
        if not b:
            b = ChiNhanh(code=code, name=bname, address=addr, phone=bphone, is_active=True)
            db.session.add(b)
            db.session.flush()
        elif b.name in OLD_BRANCH_NAMES:  # CSDL cũ dùng tên mẫu cũ -> đổi sang tên mới (không đè tên người dùng tự đặt)
            b.name, b.address, b.phone = bname, addr, bphone
        branches[code] = b
    b1, b2, b3 = branches["CN01"], branches["CN02"], branches["CN03"]

    # --- Tài khoản admin ---
    if not User.query.filter_by(email="admin@gmail.com").first():
        admin = User(
            full_name="Quản trị viên",
            email="admin@gmail.com",
            phone="0900000000",
            role="admin",
        )
        admin.set_password("admin123")
        db.session.add(admin)
        print("Đã tạo tài khoản admin: admin@gmail.com / admin123")

    # --- Quản lý chuỗi + quản lý chi nhánh + nhân viên mẫu ---
    for name, email, phone, role, pw, branch in [
        ("Trần Quản Lý Chuỗi", "quanlychuoi@snackshop.vn", "0900000001", "chain_manager", "quanly123", None),
        ("Nguyễn Quản Lý", "quanly@snackshop.vn", "0901111111", "manager", "quanly123", b1),
        ("Trần Nhân Viên", "nhanvien@snackshop.vn", "0902222222", "staff", "nhanvien123", b1),
        ("Lê Nhân Viên 2", "nhanvien2@snackshop.vn", "0903333333", "staff", "nhanvien123", b1),
        ("Phạm Quản Lý Thủ Đức", "quanly2@snackshop.vn", "0904444444", "manager", "quanly123", b2),
        ("Hoàng Nhân Viên 3", "nhanvien3@snackshop.vn", "0905555555", "staff", "nhanvien123", b2),
        ("Vũ Nhân Viên 4", "nhanvien4@snackshop.vn", "0906666666", "staff", "nhanvien123", b2),
        ("Đặng Quản Lý Bình Thạnh", "quanly3@snackshop.vn", "0907777777", "manager", "quanly123", b3),
        ("Bùi Nhân Viên 5", "nhanvien5@snackshop.vn", "0908888888", "staff", "nhanvien123", b3),
        ("Ngô Nhân Viên 6", "nhanvien6@snackshop.vn", "0909999999", "staff", "nhanvien123", b3),
    ]:
        if not User.query.filter_by(email=email).first():
            u = User(full_name=name, email=email, phone=phone, role=role, branch_id=branch.id if branch else None)
            u.set_password(pw)
            db.session.add(u)
            print(f"Đã tạo tài khoản {role}: {email} / {pw}")

    # --- Danh mục (kèm icon emoji) ---
    category_defs = [
        ("Snack", "🍿"),
        ("Nước Giải Khát", "🥤"),
        ("Bánh Tráng", "🫓"),
        ("Đồ Khô", "🍖"),
    ]
    categories = {}
    for name, icon in category_defs:
        cat = Category.query.filter_by(name=name).first()
        if not cat:
            cat = Category(name=name, slug=slugify(name), icon=icon)
            db.session.add(cat)
            db.session.flush()
        else:
            cat.icon = icon
        categories[name] = cat

    # --- Nhà cung cấp ---
    supplier_defs = [
        dict(
            name="Công ty TNHH Thực Phẩm Sài Gòn",
            contact_name="Nguyễn Văn An",
            phone="0901234567",
            email="contact@tpsaigon.vn",
            address="123 Nguyễn Trãi, Quận 5, TP.HCM",
            note="Chuyên khô gà, khô bò, khô mực - nhập hàng tuần",
        ),
        dict(
            name="Vinamit Organic",
            contact_name="Trần Thị Bích",
            phone="0912345678",
            email="sales@vinamit.com.vn",
            address="45 Lý Thường Kiệt, Bình Dương",
            note="Nhà cung cấp trái cây sấy organic, mít sấy, mãng cầu sấy",
        ),
        dict(
            name="Cơ Sở Bánh Tráng Tây Ninh",
            contact_name="Lê Văn Cường",
            phone="0923456789",
            email="banhtrangtayninh@gmail.com",
            address="Xã Trảng Bàng, Tây Ninh",
            note="Chuyên bánh tráng phơi sương, bánh tráng muối các loại",
        ),
        dict(
            name="Đại Lý Nước Giải Khát Miền Nam",
            contact_name="Phạm Thị Dung",
            phone="0934567890",
            email="daily.miennam@gmail.com",
            address="78 Cách Mạng Tháng 8, Quận 3, TP.HCM",
            note="Cung cấp trà, nước ép, nguyên liệu pha chế đồ uống",
        ),
    ]
    suppliers = {}
    for s in supplier_defs:
        supplier = Supplier.query.filter_by(name=s["name"]).first()
        if not supplier:
            supplier = Supplier(**s)
            db.session.add(supplier)
            db.session.flush()
        suppliers[s["name"]] = supplier

    # --- Sản phẩm mẫu: (tên, danh mục, giá gốc, giá sale hoặc None, tồn kho, mô tả, nhà cung cấp hoặc None) ---
    sample_products = [
        ('Bánh Tráng Cuốn Bơ Me', 'Bánh Tráng', 25000, None, 40, 'Bánh tráng cuộn nhân bơ me chua ngọt hấp dẫn.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh-trang-cuon-bo-me.jpg'),
        ('Bánh Tráng Phơi Sương Hành Phi Muối Tép Combo 4', 'Bánh Tráng', 60000, 55000, 30, 'Combo 4 gói bánh tráng phơi sương hành phi muối tép.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh-trang-phoi-suong-hanh-phi-muoi-tep-combo-4.png'),
        ('Bánh Tráng Tây Ninh Muối Nhuyễn', 'Bánh Tráng', 15000, None, 60, 'Bánh tráng muối nhuyễn đặc sản Tây Ninh, cay mặn vừa ăn.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh-trang-tay-ninh-muoi-nhuyen.jpg'),
        ('Bánh Tráng Trộn Hành Phi', 'Bánh Tráng', 20000, None, 55, 'Bánh tráng trộn đậm vị, hành phi giòn thơm.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh-trang-tron-hanh-phi.jpg'),
        ('Bánh Tráng Trộn Vị Sa Tế Bò', 'Bánh Tráng', 22000, None, 50, 'Bánh tráng trộn sa tế bò cay thơm.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh-trang_tron_vi_sa_te_bo.jpg'),
        ('Bánh Tráng Trộn Vị Chanh Sả', 'Bánh Tráng', 22000, None, 50, 'Bánh tráng trộn vị chanh sả thanh mát, cay nhẹ.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh_trang-tron_vi_chanh_sa.jpg'),
        ('Bánh Tráng Cuộn Tôm Hành', 'Bánh Tráng', 25000, None, 40, 'Bánh tráng cuộn tôm hành giòn thơm.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh_trang_cuon_tom_hanh.jpg'),
        ('Bánh Tráng Trộn Vị Gà Quay', 'Bánh Tráng', 22000, None, 45, 'Bánh tráng trộn vị gà quay đậm đà.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh_trang_tron-vi_ga_quay.jpg'),
        ('Bánh Tráng Trộn Vị Rong Biển', 'Bánh Tráng', 22000, None, 45, 'Bánh tráng trộn rong biển giòn, thơm.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh_trang_tron-vi_rong_bien.jpg'),
        ('Bánh Tráng Trộn Gói Ớt Xanh', 'Bánh Tráng', 20000, None, 45, 'Bánh tráng trộn ớt xanh cay nồng.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh_trang_tron_goi_ot_xanh.jpg'),
        ('Bánh Tráng Trộn Ớt Đỏ', 'Bánh Tráng', 20000, None, 45, 'Bánh tráng trộn ớt đỏ cay xé lưỡi.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh_trang_tron_ot_do.jpg'),
        ('Bánh Tráng Trộn Phô Mai', 'Bánh Tráng', 24000, None, 40, 'Bánh tráng trộn phô mai béo ngậy.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh_trang_tron_pho_mai.jpg'),
        ('Bánh Tráng Trộn Vị Cua Rang Me', 'Bánh Tráng', 24000, None, 40, 'Bánh tráng trộn vị cua rang me chua cay.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh_trang_tron_vi_cua_rang_me.jpg'),
        ('Bánh Tráng Trộn Vị Sa Tế Mực', 'Bánh Tráng', 24000, None, 40, 'Bánh tráng trộn sa tế mực thơm cay.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh_trang_tron_vi_sa_te_muc.jpg'),
        ('Bánh Tráng Trộn Vị Sa Tế Tôm', 'Bánh Tráng', 24000, None, 40, 'Bánh tráng trộn sa tế tôm đậm vị.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh_trang_tron_vi_sa_te_tom.jpg'),
        ('Bánh Tráng Trộn Vị Trâu Gác Bếp', 'Bánh Tráng', 28000, None, 35, 'Bánh tráng trộn thịt trâu gác bếp thơm lừng.', 'Cơ Sở Bánh Tráng Tây Ninh', 'banh_trang_tron_vi_trau_gac_bep.jpg'),
        ('7Up Chai', 'Nước Giải Khát', 12000, None, 80, 'Nước giải khát có ga 7Up vị chanh mát lạnh.', 'Đại Lý Nước Giải Khát Miền Nam', '7up.jpg'),
        ('C2 Chanh Tuyết Bạc Hà', 'Nước Giải Khát', 12000, None, 60, 'Trà C2 chanh tuyết bạc hà the mát.', 'Đại Lý Nước Giải Khát Miền Nam', 'c2_chanh_tuyet_bac_ha.jpg'),
        ('C2 Khế Mật Ong Trà Xanh', 'Nước Giải Khát', 12000, None, 60, 'Trà xanh C2 khế mật ong thanh nhẹ.', 'Đại Lý Nước Giải Khát Miền Nam', 'c2_khe_mat_ong_tra_xanh.jpg'),
        ('C2 Trà Chanh', 'Nước Giải Khát', 12000, None, 60, 'Trà C2 vị chanh giải khát.', 'Đại Lý Nước Giải Khát Miền Nam', 'c2_tra_chanh.jpg'),
        ('C2 Trà Đào', 'Nước Giải Khát', 12000, None, 60, 'Trà C2 vị đào thơm ngọt.', 'Đại Lý Nước Giải Khát Miền Nam', 'c2_tra_dao.png'),
        ('C2 Trà Táo', 'Nước Giải Khát', 12000, None, 60, 'Trà C2 vị táo dịu mát.', 'Đại Lý Nước Giải Khát Miền Nam', 'c2_tra_tao.jpg'),
        ('Coca Cola', 'Nước Giải Khát', 12000, None, 80, 'Nước ngọt có ga Coca Cola.', 'Đại Lý Nước Giải Khát Miền Nam', 'coca_cola.jpg'),
        ('Nước Cam Ép Teppy', 'Nước Giải Khát', 14000, None, 60, 'Nước cam ép Teppy có tép cam.', 'Đại Lý Nước Giải Khát Miền Nam', 'nuoc_cam_ep_teppy.jpg'),
        ('Nước Ép Táo Nguyên Chất', 'Nước Giải Khát', 30000, None, 30, 'Nước ép táo tươi nguyên chất, không chất bảo quản.', 'Đại Lý Nước Giải Khát Miền Nam', 'nuoc_ep_tao.jpg'),
        ('Sprite Chai', 'Nước Giải Khát', 12000, None, 80, 'Nước giải khát có ga Sprite vị chanh.', 'Đại Lý Nước Giải Khát Miền Nam', 'nuoc_giai_khat_co_ga_sprite.jpg'),
        ('Nước Giải Khát Ice+ Dưa Lưới', 'Nước Giải Khát', 12000, None, 50, 'Nước giải khát Ice+ vị dưa lưới.', 'Đại Lý Nước Giải Khát Miền Nam', 'nuoc_giai_khat_ice_dua_luoi.jpg'),
        ('Pepsi Không Đường Hương Vị Kem Dâu', 'Nước Giải Khát', 13000, None, 50, 'Pepsi không đường hương vị kem dâu.', 'Đại Lý Nước Giải Khát Miền Nam', 'pepsi_khong_duong_huong_vi_kem_dau.jpg'),
        ('Pepsi Không Đường Hương Vị Phúc Bồn Tử', 'Nước Giải Khát', 13000, None, 50, 'Pepsi không đường hương vị phúc bồn tử.', 'Đại Lý Nước Giải Khát Miền Nam', 'pepsi_khong_duong_huong_vi_phuc_bon_tu.jpg'),
        ('Pepsi Vị Chanh Không Calo', 'Nước Giải Khát', 13000, None, 50, 'Pepsi vị chanh không calo.', 'Đại Lý Nước Giải Khát Miền Nam', 'pepsi_vi_chanh_khong_calo.jpg'),
        ('Sting Hương Dâu', 'Nước Giải Khát', 12000, None, 70, 'Nước tăng lực Sting hương dâu.', 'Đại Lý Nước Giải Khát Miền Nam', 'sting_huong_dau.jpg'),
        ('Trà Đào Cam Sả Thơm Mát', 'Nước Giải Khát', 30000, None, 45, 'Trà đào kết hợp cam và sả tươi, giải khát cực đã.', 'Đại Lý Nước Giải Khát Miền Nam', 'tra-dao-cam-sa-thom-mat.jpg'),
        ('Trà Sữa Trân Châu Đường Đen', 'Nước Giải Khát', 35000, None, 30, 'Trà sữa béo thơm với trân châu đường đen dẻo dai.', 'Đại Lý Nước Giải Khát Miền Nam', 'tra-sua-chan-chau-duong-den.jpg'),
        ('Trà Chanh', 'Nước Giải Khát', 15000, None, 60, 'Trà chanh mát lạnh, chua thanh sảng khoái.', 'Đại Lý Nước Giải Khát Miền Nam', 'tra_chanh.jpg'),
        ('Trà Chanh Mật Ong', 'Nước Giải Khát', 22000, None, 40, 'Trà chanh kết hợp mật ong nguyên chất, thanh mát.', 'Đại Lý Nước Giải Khát Miền Nam', 'tra_chanh_mat_ong.jpg'),
        ('Trà Xanh Không Độ', 'Nước Giải Khát', 12000, None, 60, 'Trà xanh không độ thanh mát.', 'Đại Lý Nước Giải Khát Miền Nam', 'tra_xanh_khong_do.jpg'),
        ('Bò Khô Nguyên Miếng Cao Cấp', 'Đồ Khô', 75000, None, 20, 'Bò khô nguyên miếng, thịt dai ngon, tẩm ướp đậm đà.', 'Công ty TNHH Thực Phẩm Sài Gòn', 'bo-kho-nguyen-mieng-cao-cap.png'),
        ('Cá Chỉ Vàng Khô Rim Xốt Chua Ngọt', 'Đồ Khô', 55000, None, 30, 'Cá chỉ vàng rim xốt chua ngọt đậm vị.', 'Công ty TNHH Thực Phẩm Sài Gòn', 'ca_chi_vang_kho_rim_xot_chua_ngot.jpg'),
        ('Cá Cơm Khô Sấy Giòn', 'Đồ Khô', 45000, None, 30, 'Cá cơm sấy giòn rụm, ăn vặt hoặc ăn cơm.', 'Công ty TNHH Thực Phẩm Sài Gòn', 'ca_com_kho_say_gion.jpg'),
        ('Ghẹ Sữa Rim Mắm Tỏi', 'Đồ Khô', 65000, None, 20, 'Ghẹ sữa rim mắm tỏi thơm lừng.', 'Công ty TNHH Thực Phẩm Sài Gòn', 'ghe_sua-rim_mam_toi.jpg'),
        ('Khô Gà Lá Chanh Xé Sợi', 'Đồ Khô', 35000, None, 40, 'Khô gà xé sợi trộn lá chanh thơm, cay nhẹ vừa ăn.', 'Công ty TNHH Thực Phẩm Sài Gòn', 'kho-ga-la-chanh.jpg'),
        ('Khô Heo Cháy Tỏi', 'Đồ Khô', 85000, None, 6, 'Khô heo chiên giòn phủ tỏi phi vàng ươm, thơm nức mũi.', 'Công ty TNHH Thực Phẩm Sài Gòn', 'kho-heo-chay-toi.jpg'),
        ('Khô Cá Bống Que Tẩm Gia Vị', 'Đồ Khô', 60000, None, 25, 'Khô cá bống que tẩm gia vị đậm đà.', 'Công ty TNHH Thực Phẩm Sài Gòn', 'kho_ca_bong_que_tam_gia_vi.jpg'),
        ('Khô Cá Bống Tẩm Gia Vị Miếng', 'Đồ Khô', 60000, None, 25, 'Khô cá bống tẩm gia vị cắt miếng ăn liền.', 'Công ty TNHH Thực Phẩm Sài Gòn', 'kho_ca_bong_tam_gia_vi_mieng.jpg'),
        ('Khô Cá Kèo Rim Me', 'Đồ Khô', 65000, None, 22, 'Khô cá kèo rim me chua ngọt.', 'Công ty TNHH Thực Phẩm Sài Gòn', 'kho_ca_keo_rim_me.jpg'),
        ('Khô Cá Khoai Rim Me', 'Đồ Khô', 65000, None, 22, 'Khô cá khoai rim me chua ngọt đậm vị.', 'Công ty TNHH Thực Phẩm Sài Gòn', 'kho_ca_khoai_rim_me.jpg'),
        ('Mực Khô Rim Me', 'Đồ Khô', 65000, None, 25, 'Mực khô rim sốt me chua cay đậm vị, ăn là ghiền.', 'Công ty TNHH Thực Phẩm Sài Gòn', 'muc-kho-rim-me.jpg'),
        ('Mực Cán Tẩm Gia Vị Nguyên Miếng', 'Đồ Khô', 95000, None, 18, 'Mực cán tẩm gia vị nguyên miếng, thịt dày ngọt.', 'Công ty TNHH Thực Phẩm Sài Gòn', 'muc_can_tam_gia_vi_nguyen_mieng.jpg'),
        ('Mực Xé Sợi Hấp Nước Dừa', 'Đồ Khô', 78000, None, 20, 'Mực xé sợi hấp nước dừa ngọt tự nhiên.', 'Công ty TNHH Thực Phẩm Sài Gòn', 'muc_xe_soi_hap-nuoc_dua.jpg'),
        ('Chuối Sấy Giòn Tan Vị Tự Nhiên', 'Đồ Khô', 20000, None, 45, 'Chuối sấy giòn tan, ngọt dịu, không chiên dầu.', 'Vinamit Organic', 'chuoi_say_gion.jpg'),
        ('Mít Sấy Giòn', 'Đồ Khô', 45000, None, 25, 'Mít sấy giòn tan, giữ trọn vị ngọt tự nhiên, không chiên dầu.', 'Vinamit Organic', 'mit_say_gion.jpg'),
        ('Măng Cụt Sấy Thăng Hoa', 'Đồ Khô', 75000, None, 3, 'Măng cụt sấy thăng hoa giữ nguyên hương vị và dinh dưỡng.', 'Vinamit Organic', 'mang_cut_say_thang_hoa.jpg'),
        ('Bắp Rang Bơ Caramel Thơm Ngậy', 'Snack', 22000, None, 45, 'Bắp rang phủ caramel bơ ngọt ngào, giòn tan.', None, 'bap-rang-bo-vi-caramel-thom-ngay.jpg'),
        ('Cơm Cháy Chà Bông Sài Gòn', 'Snack', 45000, None, 35, 'Cơm cháy giòn rụm phủ chà bông heo béo ngậy.', None, 'com-chay-cha-bong-sai-gon.jpg'),
        ('Đậu Phộng Cốt Dừa Giòn Rụm', 'Snack', 20000, None, 40, 'Đậu phộng phủ cốt dừa giòn rụm, béo thơm.', None, 'dau_phong.jpg'),
        ('Hạt Hướng Dương Vị Dừa Thơm', 'Snack', 15000, None, 55, 'Hạt hướng dương tẩm vị dừa thơm béo, giòn tan.', None, 'huong_duong_vi_dua.jpg'),
        ('Rong Biển Sấy Giòn', 'Snack', 32000, None, 35, 'Rong biển sấy giòn tan, thơm nhẹ.', None, 'rong_bien_say_gion.jpg'),
        ('Snack Bắp Ngọt', 'Snack', 18000, None, 50, 'Snack bắp ngọt thơm bùi, thích hợp ăn vặt mọi lúc.', None, 'snack-bap-ngot.jpg'),
        ('Snack Bí Đỏ', 'Snack', 25000, 22000, 40, 'Snack bí đỏ sấy giòn tự nhiên, ít dầu.', None, 'snack-bi-do.jpg'),
        ('Snack Khoai Tây Vị Phô Mai', 'Snack', 22000, None, 60, 'Snack khoai tây chiên giòn phủ bột phô mai thơm béo.', None, 'snack-khoai-tay-vi-pho-mai.jpg'),
        ('Snack Bắp Vị Sô Cô La', 'Snack', 20000, None, 40, 'Snack bắp phủ socola ngọt ngào, lạ miệng.', None, 'snack_bap_vi_socola.jpg'),
        ('Snack Bí Đỏ Bò Nướng', 'Snack', 20000, None, 40, 'Snack bí đỏ vị bò nướng đậm đà.', None, 'snack_bi_do_bo_nuong.jpg'),
        ('Snack Bò Lúc Lắc', 'Snack', 18000, None, 45, 'Snack vị bò lúc lắc thơm ngon.', None, 'snack_bo_luc_lac.jpg'),
        ('Snack Cà Chua', 'Snack', 18000, None, 45, 'Snack vị cà chua chua ngọt.', None, 'snack_ca_chua.jpg'),
        ('Snack Cháy Vị Da Heo Quay', 'Snack', 20000, None, 40, 'Snack cháy vị da heo quay giòn rụm.', None, 'snack_chay_vi_da_heo_quay.jpg'),
        ('Snack Đậu Xanh Nước Dừa', 'Snack', 20000, None, 40, 'Snack đậu xanh vị nước dừa béo nhẹ.', None, 'snack_dau_xanh_nuoc_dua.jpg'),
        ('Snack Hành', 'Snack', 16000, None, 50, 'Snack vị hành giòn thơm.', None, 'snack_hanh.jpg'),
        ('Snack Mực Lăn Muối Ớt', 'Snack', 20000, None, 40, 'Snack mực lăn muối ớt cay mặn.', None, 'snack_muc_lan_muoi_ot.jpg'),
        ('Snack Tôm Cay', 'Snack', 18000, None, 50, 'Snack vị tôm cay nồng, giòn tan trong miệng.', None, 'snack_tom_cay.jpg'),
        ('Snack Vị Mực Cay Đặc Biệt', 'Snack', 20000, None, 40, 'Snack vị mực cay đặc biệt.', None, 'snack_vi_muc_cay_dac_biet.jpg'),
        ('Snack Vị Phô Mai Miếng', 'Snack', 20000, None, 45, 'Snack phô mai dạng miếng giòn béo.', None, 'snack_vi_pho_mai_mieng.jpg'),
        ('Snack Vị Thăn Bò Nướng Texas', 'Snack', 22000, None, 40, 'Snack vị thăn bò nướng Texas đậm đà.', None, 'snack_vi_than_bo_nuong_texas.jpg'),
    ]

    for name, cat_name, price, sale_price, stock, desc, supplier_name, image_file in sample_products:
        slug = slugify(name)
        existing = Product.query.filter_by(slug=slug).first()
        if not existing:
            product = Product(
                name=name,
                slug=slug,
                description=desc,
                price=price,
                sale_price=sale_price,
                category_id=categories[cat_name].id,
                supplier_id=suppliers[supplier_name].id if supplier_name else None,
                image_filename=image_file,  # ảnh nằm ở static/images/products/ (None -> ảnh mặc định no-image.png)
                image_source="default",
                cost_price=int(price * 0.65 / 500) * 500,  # giá vốn mẫu ~65% giá bán
            )
            # Tồn kho riêng từng chi nhánh: Quận 1 là chi nhánh lớn nhất, Thủ Đức và Bình Thạnh ít hơn một chút
            product.set_stock(b1.id, stock)
            product.set_stock(b2.id, max(1, int(stock * 0.8)))
            product.set_stock(b3.id, max(1, int(stock * 0.7)))
            db.session.add(product)

    # --- Voucher mẫu ---
    voucher_defs = [
        dict(
            code="SALE10",
            description="Giảm 10% cho đơn hàng",
            discount_type="percent",
            discount_value=10,
            max_discount_amount=20000,
            min_order_amount=100000,
            usage_limit=100,
            expires_at=datetime.utcnow() + timedelta(days=30),
        ),
        dict(
            code="FREESHIP",
            description="Giảm phí vận chuyển toàn quốc",
            discount_type="fixed",
            discount_value=20000,
            max_discount_amount=None,
            min_order_amount=150000,
            usage_limit=None,
            expires_at=datetime.utcnow() + timedelta(days=30),
        ),
        dict(
            code="GIAM20K",
            description="Giảm ngay 20.000đ cho đơn từ 200K",
            discount_type="fixed",
            discount_value=20000,
            max_discount_amount=None,
            min_order_amount=200000,
            usage_limit=200,
            expires_at=datetime.utcnow() + timedelta(days=30),
        ),
        dict(code="WELCOME5", description="Chào thành viên mới: giảm 5% mọi đơn", discount_type="percent",
             discount_value=5, max_discount_amount=15000, min_order_amount=0, usage_limit=None,
             expires_at=datetime.utcnow() + timedelta(days=90)),
        dict(code="SNACK15", description="Giảm 15% cho đơn từ 300K (tối đa 50K)", discount_type="percent",
             discount_value=15, max_discount_amount=50000, min_order_amount=300000, usage_limit=150,
             expires_at=datetime.utcnow() + timedelta(days=45)),
        dict(code="COMBO50K", description="Giảm 50.000đ cho đơn từ 500K", discount_type="fixed",
             discount_value=50000, max_discount_amount=None, min_order_amount=500000, usage_limit=100,
             expires_at=datetime.utcnow() + timedelta(days=60)),
        dict(code="CUOITUAN", description="Cuối tuần vui vẻ: giảm 12% (tối đa 25K)", discount_type="percent",
             discount_value=12, max_discount_amount=25000, min_order_amount=100000, usage_limit=300,
             expires_at=datetime.utcnow() + timedelta(days=30)),
        dict(code="TET2027", description="Quà Tết: giảm 10.000đ mọi đơn từ 50K", discount_type="fixed",
             discount_value=10000, max_discount_amount=None, min_order_amount=50000, usage_limit=500,
             expires_at=datetime.utcnow() + timedelta(days=120)),
    ]
    for v in voucher_defs:
        if not Voucher.query.filter_by(code=v["code"]).first():
            db.session.add(Voucher(active=True, **v))
    # Voucher riêng từng chi nhánh
    exp = lambda d: datetime.utcnow() + timedelta(days=d)
    branch_vouchers = [
        ("HANOI15", "Giảm 15% riêng cho chi nhánh Hà Nội (tối đa 30K)", "percent", 15, 30000, 80000, None, 45, b1),
        ("HANOI30K", "Chi nhánh Hà Nội giảm 30.000đ cho đơn từ 250K", "fixed", 30000, None, 250000, 100, 30, b1),
        ("HCM15", "Giảm 15% riêng cho chi nhánh TP.HCM (tối đa 30K)", "percent", 15, 30000, 80000, None, 45, b2),
        ("SAIGON25K", "Chi nhánh TP.HCM giảm 25.000đ cho đơn từ 200K", "fixed", 25000, None, 200000, 100, 30, b2),
        ("NAMDINH15", "Giảm 15% riêng cho chi nhánh Nam Định (tối đa 25K)", "percent", 15, 25000, 60000, None, 45, b3),
        ("NAMDINH20K", "Chi nhánh Nam Định giảm 20.000đ cho đơn từ 150K", "fixed", 20000, None, 150000, 100, 30, b3),
    ]
    for code, desc, typ, val, cap, minimum, limit, days, br in branch_vouchers:
        if not Voucher.query.filter_by(code=code).first():
            db.session.add(Voucher(code=code, description=desc, discount_type=typ, discount_value=val,
                                   max_discount_amount=cap, min_order_amount=minimum, usage_limit=limit,
                                   expires_at=exp(days), active=True, branch_id=br.id))
    # THUDUC15 (bản cũ) -> chuyển thành mã TP.HCM nếu CSDL cũ còn
    old = Voucher.query.filter_by(code="THUDUC15").first()
    if old:
        old.description = "Giảm 15% cho chi nhánh TP.HCM (tối đa 30K)"
        old.branch_id = b2.id

    db.session.commit()

    # --- Tài khoản khách demo + vài đánh giá mẫu (để xem giao diện review ngay) ---
    demo = User.query.filter_by(email="khach@demo.vn").first()
    if not demo:
        demo = User(full_name="Khách Demo", email="khach@demo.vn", phone="0912345678")
        demo.set_password("demo123")
        db.session.add(demo)
        db.session.flush()
        print("Đã tạo tài khoản khách demo: khach@demo.vn / demo123")

    sample_reviews = [
        ("kho-ga-la-chanh-xe-soi", 5, "Ăn cực đã, cay vừa phải, giao hàng nhanh!"),
        ("banh-trang-tron-hanh-phi", 4, "Ngon nhưng hơi mặn so với khẩu vị mình."),
        ("tra-dao-cam-sa-thom-mat", 5, "Uống mát, thơm mùi sả tự nhiên, sẽ mua lại."),
    ]
    for slug, rating, comment in sample_reviews:
        product = Product.query.filter_by(slug=slug).first()
        if product and not Review.query.filter_by(product_id=product.id, user_id=demo.id).first():
            db.session.add(Review(product_id=product.id, user_id=demo.id, rating=rating, comment=comment))

    db.session.commit()

    # --- Phiếu nhập + đơn hàng mẫu (để xem báo cáo, hiệu suất nhân viên, hạn dùng) ---
    manager = User.query.filter_by(email="quanly@snackshop.vn").first()
    staff = User.query.filter_by(email="nhanvien@snackshop.vn").first()
    if manager and staff and PhieuNhap.query.count() == 0:
        sup = Supplier.query.filter_by(name="Vinamit Organic").first()
        r1 = PhieuNhap(code="PN" + datetime.utcnow().strftime("%Y%m%d") + "001", supplier_id=sup.id,
                       created_by_id=manager.id, assigned_to_id=staff.id, branch_id=b1.id, note="Nhập trái cây sấy đợt 1")
        for slug, qty, price, days in [("mit-say-gion", 30, 29000, 20), ("mang-cut-say-thang-hoa", 12, 48000, 200)]:
            p = Product.query.filter_by(slug=slug).first()
            if p:
                r1.items.append(ChiTietPhieuNhap(product_id=p.id, quantity=qty, import_price=price,
                                                 expiry_date=(datetime.utcnow() + timedelta(days=days)).date()))
        db.session.add(r1)  # phiếu đang chờ nhân viên ghi nhận

        r2 = PhieuNhap(code="PN" + (datetime.utcnow() - timedelta(days=3)).strftime("%Y%m%d") + "001", supplier_id=sup.id,
                       created_by_id=manager.id, assigned_to_id=staff.id, branch_id=b1.id, status="completed",
                       received_by_id=staff.id, received_at=datetime.utcnow() - timedelta(days=3), note="Phiếu mẫu đã nhập kho")
        p = Product.query.filter_by(slug="chuoi-say-gion-tan-vi-tu-nhien").first()
        if p:
            r2.items.append(ChiTietPhieuNhap(product_id=p.id, quantity=20, received_quantity=20, import_price=13000,
                                             expiry_date=(datetime.utcnow() + timedelta(days=10)).date()))
            r2.total_amount = 20 * 13000
        db.session.add(r2)

    if demo and staff and Order.query.count() == 0:
        samples = [("kho-ga-la-chanh-xe-soi", 2), ("tra-chanh", 3), ("snack-tom-cay", 4)]
        for i, (slug, qty) in enumerate(samples):
            p = Product.query.filter_by(slug=slug).first()
            if not p:
                continue
            when = datetime.utcnow() - timedelta(days=i * 2)
            o = Order(user_id=demo.id, branch_id=b1.id, code=f"DH{when.strftime('%Y%m%d')}0{i}", receiver_name=demo.full_name,
                      receiver_phone="0912345678", shipping_address="12 Nguyễn Huệ, Quận 1, TP.HCM",
                      payment_method="cod", subtotal_amount=p.final_price * qty, total_amount=p.final_price * qty,
                      status="completed", is_paid=True, handled_by_id=staff.id, handled_at=when,
                      completed_at=when, created_at=when)
            o.items.append(OrderItem(product_id=p.id, product_name=p.name, price=p.final_price, quantity=qty,
                                     cost_price=p.cost_price))
            db.session.add(o)
    db.session.commit()
    print(
        f"Đã tạo xong dữ liệu mẫu! ({len(sample_products)} sản phẩm, {len(category_defs)} danh mục, "
        f"{len(supplier_defs)} nhà cung cấp, {len(voucher_defs)} voucher)"
    )
