"""
Gán 1 ảnh đã có sẵn trong static/images/products/ cho 1 sản phẩm trong database,
không cần vào trang admin để upload qua form.

Dùng khi bạn copy ảnh trực tiếp vào thư mục (qua VS Code, File Explorer...) và muốn
gán nhanh nó cho đúng sản phẩm bằng dòng lệnh.

Cách dùng:
    python link_image.py "<slug-san-pham>" "<ten-file-anh>"

Ví dụ:
    python link_image.py "mang-cut-say-thang-hoa" "mang-cut-say-thang-hoa.jpg"

Nếu chưa biết slug của sản phẩm, chạy không kèm tham số để xem danh sách gợi ý:
    python link_image.py
"""
import sys
import os
from app import create_app
from extensions import db
from models import Product

app = create_app()


def list_products():
    with app.app_context():
        products = Product.query.order_by(Product.name).all()
        print("Danh sách sản phẩm hiện có (tên -> slug):\n")
        for p in products:
            print(f"  {p.name}  ->  {p.slug}")


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        list_products()
        sys.exit(0)

    slug, filename = sys.argv[1].strip(), sys.argv[2].strip()

    with app.app_context():
        product = Product.query.filter_by(slug=slug).first()
        if not product:
            print(f"❌ Không tìm thấy sản phẩm có slug '{slug}'.")
            list_products()
            sys.exit(1)

        image_path = os.path.join("static", "images", "products", filename)
        if not os.path.exists(image_path):
            print(f"❌ Không tìm thấy file ảnh tại: {image_path}")
            print("   Kiểm tra lại tên file (phân biệt hoa/thường) và đường dẫn.")
            sys.exit(1)

        product.image_filename = filename
        product.image_source = "default"
        db.session.commit()
        print(f"✅ Đã gán ảnh '{filename}' cho sản phẩm '{product.name}'.")


if __name__ == "__main__":
    main()
