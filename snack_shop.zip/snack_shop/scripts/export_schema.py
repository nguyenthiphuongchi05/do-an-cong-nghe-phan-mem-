"""Sinh script tạo bảng (DDL) SQLite từ các model, để xem cấu trúc CSDL hoặc đính kèm báo cáo.

Chạy từ thư mục gốc dự án:  python scripts/export_schema.py
Kết quả: database/snack_shop_sqlite.sql (khớp với code vì sinh trực tiếp từ models/, không viết tay).
Không bắt buộc phải chạy file này: ứng dụng tự tạo bảng khi chạy `python seed.py` hoặc `python app.py`.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy.dialects import sqlite  # noqa: E402
from sqlalchemy.schema import CreateTable, CreateIndex  # noqa: E402

from app import create_app  # noqa: E402
from extensions import db  # noqa: E402
import models  # noqa: E402,F401

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "database")
HEADER = ("-- Schema SQLite cho SnackShop (sinh tự động bằng scripts/export_schema.py)\n"
          "-- Mở bằng DB Browser for SQLite hoặc chạy:  sqlite3 snack_shop.db < database/snack_shop_sqlite.sql\n\n")


def export():
    parts = [HEADER]
    for table in db.metadata.sorted_tables:
        parts.append(str(CreateTable(table).compile(dialect=sqlite.dialect())).strip() + ";\n")
        for index in sorted(table.indexes, key=lambda i: i.name or ""):
            parts.append(str(CreateIndex(index).compile(dialect=sqlite.dialect())).strip() + ";\n")
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, "snack_shop_sqlite.sql")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(parts))
    print("Đã ghi", path)


if __name__ == "__main__":
    with create_app().app_context():
        export()
