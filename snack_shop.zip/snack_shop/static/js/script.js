// Tự động ẩn các thông báo flash message sau 4 giây
document.addEventListener("DOMContentLoaded", function () {
    const alerts = document.querySelectorAll(".alert");
    alerts.forEach(function (alert) {
        setTimeout(function () {
            alert.classList.remove("show");
            alert.classList.add("fade");
            // gỡ hẳn khỏi bố cục sau khi mờ xong để không để lại khoảng trống
            setTimeout(function () {
                const wrap = alert.closest(".flash-wrap");
                alert.remove();
                if (wrap && !wrap.querySelector(".alert")) wrap.remove();
            }, 400);
        }, 4000);
    });
});

// ---------- Toast notification dùng chung ----------
function showToast(message, isError) {
    if (!message) return;
    let stack = document.querySelector(".toast-stack");
    if (!stack) {
        stack = document.createElement("div");
        stack.className = "toast-stack";
        document.body.appendChild(stack);
    }
    const item = document.createElement("div");
    item.className = "toast-item" + (isError ? " error" : "");
    item.textContent = message;
    stack.appendChild(item);
    setTimeout(function () {
        item.style.opacity = "0";
        item.style.transition = "opacity 0.3s";
        setTimeout(function () { item.remove(); }, 300);
    }, 2200);
}

// ---------- Thêm vào giỏ hàng qua AJAX (không reload trang, hiện toast ngay) ----------
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".js-add-to-cart-form").forEach(function (form) {
        form.addEventListener("submit", function (e) {
            e.preventDefault();
            const submitBtn = form.querySelector("button[type=submit]");
            const originalText = submitBtn ? submitBtn.innerHTML : null;
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = "Đang thêm...";
            }

            fetch(form.action, {
                method: "POST",
                headers: { "X-Requested-With": "XMLHttpRequest", "X-CSRFToken": (document.querySelector('meta[name="csrf-token"]') || {}).content || "" },
                body: new FormData(form),
            })
                .then(function (res) { return res.json().then(function (data) { return { status: res.status, data: data }; }); })
                .then(function (result) {
                    showToast(result.data.message, !result.data.ok);
                    const countEl = document.getElementById("navCartCount");
                    if (countEl && typeof result.data.cart_count !== "undefined") {
                        countEl.textContent = result.data.cart_count;
                        countEl.classList.toggle("d-none", !result.data.cart_count);
                    }
                })
                .catch(function () {
                    showToast("Có lỗi xảy ra, vui lòng thử lại.", true);
                })
                .finally(function () {
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = originalText;
                    }
                });
        });
    });
});

// ---------- Tìm kiếm gợi ý (autocomplete) ----------
document.addEventListener("DOMContentLoaded", function () {
    const inputs = document.querySelectorAll(".js-autocomplete");
    if (!inputs.length) return;

    inputs.forEach(function (input) {
        const wrap = input.closest(".autocomplete-wrap");
        const dropdown = wrap ? wrap.querySelector(".autocomplete-dropdown") : null;
        if (!dropdown) return;

        let debounceTimer = null;
        let lastQuery = "";

        function hideDropdown() {
            dropdown.classList.remove("show");
            dropdown.innerHTML = "";
        }

        function renderResults(items, query) {
            if (!items.length) {
                hideDropdown();
                return;
            }
            dropdown.innerHTML = items.map(function (p) {
                return (
                    '<a class="autocomplete-item" href="/san-pham/' + encodeURIComponent(p.slug) + '">' +
                    '<img src="' + p.image + '" alt="">' +
                    '<span class="name">' + p.name + '</span>' +
                    '<span class="price">' + p.price.toLocaleString('vi-VN') + 'đ</span>' +
                    '</a>'
                );
            }).join("");
            dropdown.classList.add("show");
        }

        input.addEventListener("input", function () {
            const query = input.value.trim();
            clearTimeout(debounceTimer);

            if (query.length < 2) {
                hideDropdown();
                return;
            }

            debounceTimer = setTimeout(function () {
                lastQuery = query;
                fetch("/san-pham/goi-y?q=" + encodeURIComponent(query))
                    .then(function (res) { return res.json(); })
                    .then(function (data) {
                        // Chỉ hiển thị nếu người dùng chưa gõ thêm gì khác trong lúc chờ phản hồi
                        if (query === lastQuery) {
                            renderResults(data, query);
                        }
                    })
                    .catch(function () { hideDropdown(); });
            }, 250);
        });

        document.addEventListener("click", function (e) {
            if (!wrap.contains(e.target)) hideDropdown();
        });

        input.addEventListener("keydown", function (e) {
            if (e.key === "Escape") hideDropdown();
        });
    });
});

// ---------- Nút "Sao chép" (số tài khoản, số tiền, nội dung chuyển khoản) ----------
document.addEventListener("click", function (e) {
    const btn = e.target.closest("[data-copy]");
    if (!btn) return;
    const text = btn.getAttribute("data-copy");
    const done = function () {
        const old = btn.textContent;
        btn.textContent = "Đã chép ✓";
        btn.classList.add("copied");
        setTimeout(function () { btn.textContent = old; btn.classList.remove("copied"); }, 1500);
    };
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done, function () {});
    } else {
        const ta = document.createElement("textarea");
        ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
        document.body.appendChild(ta); ta.select();
        try { document.execCommand("copy"); done(); } catch (err) {}
        document.body.removeChild(ta);
    }
});
