"""
Sinh dữ liệu lịch sử 3 tháng (90 ngày) cho 3 chi nhánh (mặc định 1.500 đơn hàng) để thử báo cáo.

Chạy SAU `python seed.py` (cần có chi nhánh, sản phẩm, tài khoản nhân viên):
    python seed_history.py                # 1.500 đơn trong 90 ngày gần nhất
    python seed_history.py --orders 3000 --days 120 --seed 7

Dữ liệu sinh ra: khách hàng mẫu, đơn hàng (online + tại quầy) trải đều trong khoảng ngày gần nhất, có hệ số theo tháng và cuối tuần, tăng dần theo
thời gian, phiếu nhập hàng đã hoàn tất mỗi tháng mỗi chi nhánh, vài yêu cầu hủy/đổi. Không đụng tới tồn kho hiện tại.
Chạy lại lần 2 sẽ không sinh thêm (bỏ qua nếu đã có đơn lịch sử); thêm --force để sinh thêm.
"""
import argparse
import random
from datetime import datetime, timedelta

from werkzeug.security import generate_password_hash

from app import create_app
from extensions import db
from models import (User, Product, Supplier, Order, OrderItem, PhieuNhap, ChiTietPhieuNhap, ChiNhanh, TonKho)
from models.user import WALKIN_EMAIL

HISTORY_DAYS = 90  # 3 tháng
HISTORY_TAG = "LS"  # tiền tố mã đơn lịch sử: LS20240315-000123
BRANCH_WEIGHTS = {"CN01": 0.45, "CN02": 0.30, "CN03": 0.25}
FIRST = ["An", "Bình", "Chi", "Dũng", "Giang", "Hà", "Hải", "Hoa", "Hùng", "Khánh", "Lan", "Linh", "Long", "Mai",
         "Minh", "Nam", "Ngọc", "Phong", "Phúc", "Quân", "Quỳnh", "Sơn", "Thảo", "Thu", "Trang", "Tuấn", "Vy", "Yến"]
LAST = ["Nguyễn", "Trần", "Lê", "Phạm", "Hoàng", "Huỳnh", "Phan", "Vũ", "Võ", "Đặng", "Bùi", "Đỗ", "Ngô", "Dương"]
STREETS = ["Lê Lợi", "Nguyễn Trãi", "Võ Văn Ngân", "Điện Biên Phủ", "Phan Xích Long", "Hai Bà Trưng", "Cách Mạng Tháng 8",
           "Xô Viết Nghệ Tĩnh", "Lý Thường Kiệt", "Nguyễn Văn Linh"]


def season_weight(day):
    """Hệ số bán theo tháng: cao điểm quanh Tết (tháng 1-2) và mùa hè, thấp hơn tháng 3-4."""
    return {1: 1.35, 2: 1.4, 3: 0.85, 4: 0.9, 5: 1.0, 6: 1.15, 7: 1.2, 8: 1.1, 9: 0.95, 10: 1.0, 11: 1.05, 12: 1.25}[day.month]


def day_weight(day, start, end):
    growth = 0.7 + 0.6 * ((day - start).days / max(1, (end - start).days))  # đầu kỳ bán ít hơn cuối kỳ
    weekend = 1.25 if day.weekday() >= 5 else 1.0
    return season_weight(day) * growth * weekend


def run(app, orders=1500, seed=2026, force=False, n_customers=30, verbose=True, days=HISTORY_DAYS):
    """Sinh dữ liệu lịch sử vào CSDL của `app`. Trả về dict thống kê và kết quả đối soát tồn kho."""
    args = argparse.Namespace(orders=orders, seed=seed, force=force)
    rnd = random.Random(args.seed)

    with app.app_context():
        branches = {b.code: b for b in ChiNhanh.query.all()}
        products = Product.query.all()
        if len(branches) < 3 or not products:
            raise SystemExit("Cần chạy `python seed.py` trước (3 chi nhánh + sản phẩm).")
        if not args.force and Order.query.filter(Order.code.like(f"{HISTORY_TAG}%")).first():
            raise SystemExit("Đã có dữ liệu lịch sử. Thêm --force nếu vẫn muốn sinh thêm.")

        end = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        start = end - timedelta(days=days)

        # ---- nhân sự theo chi nhánh ----
        staff = {code: [u for u in User.query.filter(User.branch_id == b.id, User.role.in_(["staff", "manager"])).all()]
                 for code, b in branches.items()}
        managers = {code: next((u for u in users if u.role == "manager"), users[0]) for code, users in staff.items()}
        walkin = User.query.filter_by(email=WALKIN_EMAIL).first()
        if not walkin:
            walkin = User(full_name="Khách lẻ (tại quầy)", email=WALKIN_EMAIL, role="customer", is_locked=True,
                          password_hash=generate_password_hash("khong-dang-nhap"))
            db.session.add(walkin)
            db.session.flush()

        # ---- khách hàng mẫu (cùng 1 mật khẩu băm cho nhanh): khach001@demo.vn ... / demo123 ----
        existing_customers = User.query.filter(User.email.like("khach___@demo.vn")).count()
        pw_hash = generate_password_hash("demo123")
        customers = []
        for i in range(existing_customers + 1, existing_customers + n_customers + 1):
            name = f"{rnd.choice(LAST)} {rnd.choice(FIRST)}"
            joined = start + timedelta(days=rnd.randint(0, days - 1))
            customers.append(User(full_name=name, email=f"khach{i:03d}@demo.vn", role="customer",
                                  phone="09" + "".join(rnd.choice("0123456789") for _ in range(8)),
                                  address=f"{rnd.randint(1, 300)} {rnd.choice(STREETS)}, TP.HCM",
                                  password_hash=pw_hash, created_at=joined))
        db.session.add_all(customers)
        db.session.flush()
        customers = User.query.filter(User.email.like("khach___@demo.vn")).all()

        # ---- phân bổ số đơn theo ngày và chi nhánh ----
        day_list = [start + timedelta(days=i) for i in range(days)]
        weights = [day_weight(d, start, end) for d in day_list]
        day_counts = {}
        for d in rnd.choices(day_list, weights=weights, k=args.orders):
            day_counts[d] = day_counts.get(d, 0) + 1

        by_price = sorted(products, key=lambda p: p.price)
        pop = [1 / (1 + i * 0.08) for i in range(len(by_price))]  # sản phẩm rẻ bán chạy hơn

        next_order_id = (db.session.query(db.func.coalesce(db.func.max(Order.id), 0)).scalar() or 0) + 1
        next_item_id = (db.session.query(db.func.coalesce(db.func.max(OrderItem.id), 0)).scalar() or 0) + 1
        order_rows, item_rows = [], []
        seq = 0
        for day in sorted(day_counts):
            for _ in range(day_counts[day]):
                seq += 1
                code_b = rnd.choices(list(BRANCH_WEIGHTS), weights=list(BRANCH_WEIGHTS.values()))[0]
                branch = branches[code_b]
                staff_user = rnd.choice(staff[code_b])
                counter = rnd.random() < 0.35
                when = day + timedelta(hours=rnd.choice([8, 9, 10, 11, 12, 13, 15, 16, 17, 18, 19, 20, 21]),
                                       minutes=rnd.randint(0, 59), seconds=rnd.randint(0, 59))
                age_days = (end - day).days
                if counter:
                    status = "completed"
                else:
                    r = rnd.random()
                    if age_days <= 2:
                        status = rnd.choice(["pending", "confirmed", "shipping", "completed"])
                    else:
                        status = "completed" if r < 0.92 else "cancelled"
                lines = {}
                for p in rnd.choices(by_price, weights=pop, k=rnd.choices([1, 2, 3, 4, 5], weights=[30, 33, 22, 10, 5])[0]):
                    lines[p.id] = (p, lines.get(p.id, (p, 0))[1] + rnd.choice([1, 1, 1, 2, 2, 3, 4]))
                subtotal = sum(p.final_price * q for p, q in lines.values())
                discount = 0
                if not counter and subtotal >= 100000 and rnd.random() < 0.18:
                    discount = min(20000, subtotal // 10)
                total = subtotal - discount
                customer = walkin if counter else rnd.choice(customers)
                bank = (not counter) and rnd.random() < 0.4
                handled = status in ("completed", "cancelled", "shipping", "confirmed")
                oid = next_order_id
                next_order_id += 1
                order_rows.append(dict(
                    id=oid, user_id=customer.id, branch_id=branch.id, code=f"{HISTORY_TAG}{day:%Y%m%d}-{seq:06d}",
                    receiver_name=customer.full_name if not counter else "Khách lẻ",
                    receiver_phone=customer.phone or "", shipping_address="Mua tại quầy" if counter else (customer.address or "TP.HCM"),
                    note=None, subtotal_amount=subtotal, discount_amount=discount, voucher_codes="SALE10" if discount else None,
                    total_amount=total, status=status, payment_method="bank_transfer" if bank else "cod",
                    bank_code="VCB" if bank else None, is_paid=(status == "completed" or (bank and status == "shipping")),  # CK phải thu tiền mới được giao
                    channel="counter" if counter else "online",
                    handled_by_id=staff_user.id if handled else None, handled_at=when + timedelta(hours=2) if handled else None,
                    completed_at=when + timedelta(hours=rnd.randint(2, 48)) if status == "completed" else None,
                    request_type=None, request_reason=None, request_status=None, request_at=None, request_note=None,
                    request_handled_by_id=None, created_at=when))
                for p, q in lines.values():
                    item_rows.append(dict(id=next_item_id, order_id=oid, product_id=p.id, product_name=p.name,
                                          price=p.final_price, quantity=q, cost_price=p.cost_price))
                    next_item_id += 1

        # vài yêu cầu hủy / đổi đã xử lý
        eligible = [o for o in order_rows if o["channel"] == "online" and o["status"] in ("completed", "cancelled")]
        for o in rnd.sample(eligible, min(len(eligible), max(10, args.orders // 120))):
            kind = "cancel" if o["status"] == "cancelled" else "exchange"
            o.update(request_type=kind, request_reason="Khách đổi ý" if kind == "cancel" else "Sản phẩm bị móp",
                     request_status="approved", request_at=o["created_at"] + timedelta(hours=1),
                     request_note="Đã xử lý", request_handled_by_id=o["handled_by_id"])

        # ---- phiếu nhập: mỗi tháng mỗi chi nhánh 2 phiếu đã hoàn tất, số lượng tính để ĐỐI SOÁT ĐƯỢC TỒN KHO ----
        # Với mỗi (chi nhánh, sản phẩm): tổng nhập - tổng bán (đơn chưa hủy) = tồn kho hiện tại (kho bắt đầu từ 0).
        # Phần nhập còn thiếu so với (bán + tồn hiện tại - đã nhập sẵn trong dữ liệu mẫu) được chia đều cho các phiếu nhập.
        sold = {}
        item_branch = {o["id"]: o["branch_id"] for o in order_rows}
        order_status = {o["id"]: o["status"] for o in order_rows}
        for it in item_rows:
            if order_status[it["order_id"]] != "cancelled":
                key = (item_branch[it["order_id"]], it["product_id"])
                sold[key] = sold.get(key, 0) + it["quantity"]
        # đã có sẵn trong CSDL (đơn mẫu của seed.py, phiếu nhập mẫu)
        for bid, pid, qty in (db.session.query(Order.branch_id, OrderItem.product_id, db.func.sum(OrderItem.quantity))
                              .join(Order, Order.id == OrderItem.order_id).filter(Order.status != "cancelled")
                              .group_by(Order.branch_id, OrderItem.product_id).all()):
            sold[(bid, pid)] = sold.get((bid, pid), 0) + int(qty)
        received = {}
        for bid, pid, qty in (db.session.query(PhieuNhap.branch_id, ChiTietPhieuNhap.product_id,
                                               db.func.sum(ChiTietPhieuNhap.received_quantity))
                              .join(PhieuNhap, PhieuNhap.id == ChiTietPhieuNhap.receipt_id)
                              .filter(PhieuNhap.status == "completed")
                              .group_by(PhieuNhap.branch_id, ChiTietPhieuNhap.product_id).all()):
            received[(bid, pid)] = int(qty or 0)
        stock_now = {(t.branch_id, t.product_id): t.quantity for t in TonKho.query.all()}

        suppliers = Supplier.query.all()
        next_receipt_id = (db.session.query(db.func.coalesce(db.func.max(PhieuNhap.id), 0)).scalar() or 0) + 1
        next_line_id = (db.session.query(db.func.coalesce(db.func.max(ChiTietPhieuNhap.id), 0)).scalar() or 0) + 1
        receipt_rows, line_rows = [], []
        n_receipt = 0
        for code_b, branch in branches.items():
            slots = []  # các thời điểm nhập của chi nhánh này
            month = start.replace(day=1)
            while month < end:
                for part in (1, 17):
                    when = month.replace(day=part) + timedelta(hours=6 if part == 1 else 9)
                    if start <= when < end:
                        slots.append(when)
                month = (month + timedelta(days=32)).replace(day=1)
            mgr = managers[code_b]
            slot_lines = [[] for _ in slots]
            for p in products:
                need = sold.get((branch.id, p.id), 0) + stock_now.get((branch.id, p.id), 0) - received.get((branch.id, p.id), 0)
                if need <= 0:
                    continue
                m = max(1, min(len(slots), need // 25))
                idxs = sorted({round(i * (len(slots) - 1) / (m - 1)) if m > 1 else 0 for i in range(m)})
                base, extra = divmod(need, len(idxs))
                for k, si in enumerate(idxs):
                    slot_lines[si].append((p, base + (1 if k < extra else 0)))
            for si, when in enumerate(slots):
                if not slot_lines[si]:
                    continue
                n_receipt += 1
                rid = next_receipt_id
                next_receipt_id += 1
                stf = rnd.choice(staff[code_b])
                total = 0
                for p, qty in slot_lines[si]:
                    price = int((p.cost_price or p.price * 0.65) // 100 * 100)
                    total += qty * price
                    line_rows.append(dict(id=next_line_id, receipt_id=rid, product_id=p.id, quantity=qty,
                                          received_quantity=qty, import_price=price,
                                          expiry_date=(when + timedelta(days=rnd.randint(120, 400))).date()))
                    next_line_id += 1
                receipt_rows.append(dict(
                    id=rid, code=f"PN{when:%Y%m%d}{code_b[-2:]}{n_receipt:04d}", supplier_id=rnd.choice(suppliers).id,
                    branch_id=branch.id, created_by_id=mgr.id, assigned_to_id=stf.id, received_by_id=stf.id,
                    status="completed", note="Phiếu nhập lịch sử (dữ liệu mẫu)", total_amount=total, created_at=when,
                    received_at=when + timedelta(hours=4)))

        # ---- ghi vào CSDL theo lô ----
        def bulk(table, rows, size=2000):
            for i in range(0, len(rows), size):
                db.session.execute(table.insert(), rows[i:i + size])
        bulk(PhieuNhap.__table__, receipt_rows)
        bulk(ChiTietPhieuNhap.__table__, line_rows)
        bulk(Order.__table__, order_rows)
        bulk(OrderItem.__table__, item_rows)
        db.session.commit()

        revenue = sum(o["total_amount"] for o in order_rows if o["status"] != "cancelled")
        result = dict(orders=len(order_rows), items=len(item_rows), receipts=len(receipt_rows), customers=len(customers),
                      revenue=revenue, per_branch={b.code: sum(1 for o in order_rows if o["branch_id"] == b.id)
                                                   for b in branches.values()})
        result["reconcile"] = reconcile_stock()
        if verbose:
            print(f"Đã sinh {result['orders']} đơn hàng ({result['items']} dòng), {result['receipts']} phiếu nhập, "
                  f"{result['customers']} khách hàng mẫu trong {days} ngày.")
            print(f"Tổng doanh thu mẫu (không tính đơn hủy): {revenue:,}đ")
            for code_b, b in branches.items():
                print(f"  {b.code} {b.name}: {result['per_branch'][code_b]} đơn")
            rc = result["reconcile"]
            print(f"Đối soát tồn kho (nhập - bán + chuyển = tồn): khớp {rc['ok']}/{rc['total']} cặp sản phẩm-chi nhánh"
                  + ("" if not rc["bad"] else f"; lệch {len(rc['bad'])} cặp"))
        return result


def reconcile_stock():
    """Kiểm tra sổ kho: với mỗi (chi nhánh, sản phẩm) phải có
    tổng nhập (phiếu hoàn tất) - tổng bán (đơn chưa hủy) + chuyển đến (đã nhận) - chuyển đi (chưa hủy) + điều chỉnh (đã duyệt) = tồn kho.
    Trả về {'total', 'ok', 'bad': [(branch_id, product_id, ledger, stock)]}."""
    from models import ChuyenKho, TonKho, PhieuDieuChinh
    led = {}

    def add(key, qty):
        led[key] = led.get(key, 0) + int(qty or 0)
    for bid, pid, q in (db.session.query(PhieuNhap.branch_id, ChiTietPhieuNhap.product_id, db.func.sum(ChiTietPhieuNhap.received_quantity))
                        .join(PhieuNhap, PhieuNhap.id == ChiTietPhieuNhap.receipt_id).filter(PhieuNhap.status == "completed")
                        .group_by(PhieuNhap.branch_id, ChiTietPhieuNhap.product_id)):
        add((bid, pid), q)
    for bid, pid, q in (db.session.query(Order.branch_id, OrderItem.product_id, db.func.sum(OrderItem.quantity))
                        .join(Order, Order.id == OrderItem.order_id).filter(Order.status != "cancelled")
                        .group_by(Order.branch_id, OrderItem.product_id)):
        add((bid, pid), -q)
    for t in ChuyenKho.query.filter(ChuyenKho.status != "cancelled").all():
        add((t.from_branch_id, t.product_id), -t.quantity)
        if t.status == "received":
            add((t.to_branch_id, t.product_id), t.quantity)
    for a in PhieuDieuChinh.query.filter_by(status="approved").all():
        add((a.branch_id, a.product_id), a.diff)
    stock = {(t.branch_id, t.product_id): t.quantity for t in TonKho.query.all()}
    keys = set(led) | set(stock)
    bad = [(b, p, led.get((b, p), 0), stock.get((b, p), 0)) for (b, p) in keys if led.get((b, p), 0) != stock.get((b, p), 0)]
    return {"total": len(keys), "ok": len(keys) - len(bad), "bad": bad}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--orders", type=int, default=1500)
    ap.add_argument("--days", type=int, default=HISTORY_DAYS, help="số ngày lịch sử (mặc định 90 = 3 tháng)")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()
    run(create_app(), orders=args.orders, seed=args.seed, force=args.force, days=args.days)


if __name__ == "__main__":
    main()
