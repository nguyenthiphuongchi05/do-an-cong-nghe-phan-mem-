from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, TextAreaField, IntegerField, SelectField, SubmitField
from wtforms.validators import DataRequired, InputRequired, NumberRange, Optional


class ProductForm(FlaskForm):
    name = StringField("Tên sản phẩm", validators=[DataRequired(), ])
    category_id = SelectField("Danh mục", coerce=int, validators=[DataRequired()])
    supplier_id = SelectField("Nhà cung cấp", coerce=int, validators=[Optional()])
    price = IntegerField("Giá gốc (VNĐ)", validators=[DataRequired(), NumberRange(min=0)])
    sale_price = IntegerField("Giá khuyến mãi (VNĐ, để trống nếu không có)", validators=[Optional(), NumberRange(min=0)])
    cost_price = IntegerField("Giá vốn / giá nhập (VNĐ, tự cập nhật khi nhập hàng)", validators=[Optional(), NumberRange(min=0)])
    description = TextAreaField("Mô tả")
    image = FileField("Ảnh sản phẩm", validators=[FileAllowed(["jpg", "jpeg", "png", "webp"], "Chỉ chấp nhận ảnh!")])
    submit = SubmitField("Lưu sản phẩm")


class CategoryForm(FlaskForm):
    name = StringField("Tên danh mục", validators=[DataRequired()])
    icon = StringField("Icon (emoji, vd: 🍿)", validators=[Optional()])
    submit = SubmitField("Lưu danh mục")
