from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo, Length, Regexp, Optional
from utils.password_policy import strong_password, POLICY_TEXT

# Số điện thoại di động VN: bắt đầu bằng 0, đầu số hợp lệ 03/05/07/08/09, tổng 10 chữ số
VN_PHONE_REGEX = r"^0(3[2-9]|5[2-9]|7[0-9]|8[1-9]|9[0-9])[0-9]{7}$"
VN_PHONE_MESSAGE = "Số điện thoại không đúng định dạng VN (vd: 0912345678)."


class LoginForm(FlaskForm):
    # Cho phép nhập đầy đủ email hoặc chỉ tên đăng nhập (vd: quanlychuoi)
    email = StringField("Email hoặc tên đăng nhập", validators=[DataRequired(message="Vui lòng nhập email hoặc tên đăng nhập."), Length(max=120)])
    password = PasswordField("Mật khẩu", validators=[DataRequired(message="Vui lòng nhập mật khẩu.")])
    submit = SubmitField("Đăng nhập")


class RegisterForm(FlaskForm):
    full_name = StringField("Họ và tên", validators=[DataRequired(), Length(min=2, max=120)])
    email = StringField("Email", validators=[DataRequired(), Email()])
    phone = StringField("Số điện thoại", validators=[DataRequired(), Regexp(VN_PHONE_REGEX, message=VN_PHONE_MESSAGE)])
    password = PasswordField("Mật khẩu", validators=[DataRequired(), strong_password], description=POLICY_TEXT)
    confirm_password = PasswordField(
        "Xác nhận mật khẩu",
        validators=[DataRequired(), EqualTo("password", message="Mật khẩu xác nhận không khớp")],
    )
    submit = SubmitField("Đăng ký")


class ProfileForm(FlaskForm):
    full_name = StringField("Họ và tên", validators=[DataRequired(), Length(min=2, max=120)])
    phone = StringField("Số điện thoại", validators=[Optional(), Regexp(VN_PHONE_REGEX, message=VN_PHONE_MESSAGE)])
    address = StringField("Địa chỉ nhận hàng mặc định", validators=[Optional(), Length(max=255)])
    submit = SubmitField("Lưu thông tin")


class ChangePasswordForm(FlaskForm):
    current_password = PasswordField("Mật khẩu hiện tại", validators=[DataRequired()])
    new_password = PasswordField("Mật khẩu mới", validators=[DataRequired(), strong_password], description=POLICY_TEXT)
    confirm_password = PasswordField(
        "Xác nhận mật khẩu mới",
        validators=[DataRequired(), EqualTo("new_password", message="Mật khẩu xác nhận không khớp")],
    )
    submit = SubmitField("Đổi mật khẩu")
