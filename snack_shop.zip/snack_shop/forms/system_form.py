from flask_wtf import FlaskForm
from utils.password_policy import strong_password
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, PasswordField, SelectField, TextAreaField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Email, Length, Optional, Regexp

from forms.auth_form import VN_PHONE_REGEX, VN_PHONE_MESSAGE
from models.user import ROLE_LABELS

ROLE_CHOICES = [(r, ROLE_LABELS[r]) for r in ("admin", "chain_manager", "manager", "staff", "customer")]


class UserForm(FlaskForm):
    full_name = StringField("Họ và tên", validators=[DataRequired(), Length(min=2, max=120)])
    email = StringField("Email", validators=[DataRequired(), Email(), Length(max=120)])
    phone = StringField("Số điện thoại", validators=[Optional(), Regexp(VN_PHONE_REGEX, message=VN_PHONE_MESSAGE)])
    role = SelectField("Vai trò", choices=ROLE_CHOICES, validators=[DataRequired()])
    branch_id = SelectField("Chi nhánh làm việc (bắt buộc với quản lý chi nhánh / nhân viên)", coerce=int, choices=[(0, "-- Chọn chi nhánh --")], validate_choice=False)
    password = PasswordField("Mật khẩu (bỏ trống để giữ nguyên / tự tạo)", validators=[Optional(), strong_password])
    submit = SubmitField("Lưu tài khoản")


class SettingsForm(FlaskForm):
    store_name = StringField("Tên cửa hàng", validators=[DataRequired(), Length(max=80)])
    store_slogan = TextAreaField("Giới thiệu ngắn (hiện ở chân trang)", validators=[Optional(), Length(max=300)])
    store_address = StringField("Địa chỉ", validators=[Optional(), Length(max=200)])
    store_phone = StringField("Hotline", validators=[Optional(), Length(max=30)])
    store_email = StringField("Email liên hệ", validators=[Optional(), Email(), Length(max=120)])
    logo = FileField("Logo (png/jpg/webp)", validators=[FileAllowed(["jpg", "jpeg", "png", "webp"], "Chỉ chấp nhận ảnh!")])
    remove_logo = BooleanField("Xóa logo hiện tại")
    submit = SubmitField("Lưu cấu hình")
