from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SelectField, SubmitField
from wtforms.validators import DataRequired, Email, Length, Optional, Regexp

from forms.auth_form import VN_PHONE_REGEX, VN_PHONE_MESSAGE
from utils.password_policy import strong_password


class TeamForm(FlaskForm):
    """Tạo / sửa nhân sự do quản lý chi nhánh hoặc quản lý chuỗi thực hiện.
    Lựa chọn vai trò / chi nhánh chỉ để hiển thị; server luôn kiểm tra lại theo quyền của người đang thao tác."""
    full_name = StringField("Họ và tên", validators=[DataRequired(), Length(min=2, max=120)])
    email = StringField("Email đăng nhập", validators=[DataRequired(), Email(), Length(max=120)])
    phone = StringField("Số điện thoại", validators=[Optional(), Regexp(VN_PHONE_REGEX, message=VN_PHONE_MESSAGE)])
    role = SelectField("Vai trò", choices=[], validate_choice=False)
    branch_id = SelectField("Chi nhánh", coerce=int, choices=[], validate_choice=False)
    password = PasswordField("Mật khẩu (bỏ trống để hệ thống tự tạo mật khẩu tạm)", validators=[Optional(), strong_password])
    submit = SubmitField("Lưu")
