from flask_wtf import FlaskForm
from wtforms import StringField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Length, Optional, Regexp

from forms.auth_form import VN_PHONE_REGEX, VN_PHONE_MESSAGE


class BranchForm(FlaskForm):
    code = StringField("Mã chi nhánh", validators=[DataRequired(), Length(max=10)])
    name = StringField("Tên chi nhánh", validators=[DataRequired(), Length(max=120)])
    address = StringField("Địa chỉ", validators=[Optional(), Length(max=255)])
    phone = StringField("Số điện thoại", validators=[Optional(), Regexp(VN_PHONE_REGEX, message=VN_PHONE_MESSAGE)])
    is_active = BooleanField("Đang hoạt động")
    submit = SubmitField("Lưu chi nhánh")
