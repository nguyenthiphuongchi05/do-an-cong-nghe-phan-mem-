from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SelectField, BooleanField, DateTimeField, SubmitField
from wtforms.validators import DataRequired, NumberRange, Optional, Length


class VoucherForm(FlaskForm):
    code = StringField("Mã voucher (vd: SALE10)", validators=[DataRequired(), Length(min=3, max=30)])
    description = StringField("Mô tả ngắn", validators=[Optional(), Length(max=255)])

    discount_type = SelectField(
        "Loại giảm giá",
        choices=[("percent", "Phần trăm (%)"), ("fixed", "Số tiền cố định (VNĐ)")],
        validators=[DataRequired()],
    )
    discount_value = IntegerField("Giá trị giảm", validators=[DataRequired(), NumberRange(min=1)])
    max_discount_amount = IntegerField(
        "Giảm tối đa (VNĐ, chỉ áp dụng cho loại %, để trống nếu không giới hạn)",
        validators=[Optional(), NumberRange(min=0)],
    )
    min_order_amount = IntegerField("Đơn tối thiểu (VNĐ)", validators=[Optional(), NumberRange(min=0)], default=0)

    usage_limit = IntegerField("Tổng lượt dùng tối đa (để trống nếu không giới hạn)", validators=[Optional(), NumberRange(min=1)])
    expires_at = DateTimeField("Hết hạn lúc (yyyy-mm-dd HH:MM, để trống nếu không hết hạn)", format="%Y-%m-%d %H:%M", validators=[Optional()])
    branch_id = SelectField("Phạm vi áp dụng", coerce=int, choices=[(0, "Toàn hệ thống")], validate_choice=False, default=0)
    active = BooleanField("Đang kích hoạt", default=True)

    submit = SubmitField("Lưu voucher")
