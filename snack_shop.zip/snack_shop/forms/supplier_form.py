from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SubmitField
from wtforms.validators import DataRequired, Optional, Email, Length


class SupplierForm(FlaskForm):
    name = StringField("Tên nhà cung cấp", validators=[DataRequired(), Length(max=150)])
    contact_name = StringField("Người liên hệ", validators=[Optional(), Length(max=120)])
    phone = StringField("Số điện thoại", validators=[Optional(), Length(max=20)])
    email = StringField("Email", validators=[Optional(), Email(message="Email không hợp lệ."), Length(max=120)])
    address = StringField("Địa chỉ", validators=[Optional(), Length(max=255)])
    note = TextAreaField("Ghi chú (mặt hàng cung cấp, điều kiện hợp tác...)", validators=[Optional(), Length(max=500)])
    submit = SubmitField("Lưu nhà cung cấp")
