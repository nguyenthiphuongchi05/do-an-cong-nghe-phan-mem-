import os
from dotenv import load_dotenv

# Nạp các biến trong file .env vào os.environ
load_dotenv()

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


def build_database_uri():
    """Chuỗi kết nối CSDL: dùng DATABASE_URL trong .env nếu có, mặc định là file SQLite snack_shop.db cạnh app.py."""
    return os.environ.get("DATABASE_URL") or f"sqlite:///{os.path.join(BASE_DIR, 'snack_shop.db')}"


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "chuoi-bi-mat-mac-dinh-khong-an-toan")

    # Cookie phiên: không cho JavaScript đọc, không gửi kèm khi bị nhúng từ trang khác.
    # Khi chạy HTTPS thật đặt SESSION_COOKIE_SECURE=1 trong .env.
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.environ.get("SESSION_COOKIE_SECURE", "0") == "1"
    REMEMBER_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_SAMESITE = "Lax"
    REMEMBER_COOKIE_SECURE = SESSION_COOKIE_SECURE
    WTF_CSRF_TIME_LIMIT = 8 * 3600  # token CSRF sống 8 giờ

    # Chống dò mật khẩu: sai quá số lần này trong khoảng phút này thì tạm chặn đăng nhập
    LOGIN_MAX_FAILURES = int(os.environ.get("LOGIN_MAX_FAILURES", 5))
    LOGIN_LOCK_MINUTES = int(os.environ.get("LOGIN_LOCK_MINUTES", 15))
    TRUST_PROXY_HEADERS = os.environ.get("TRUST_PROXY_HEADERS", "0") == "1"  # bật khi chạy sau Nginx
    LOGIN_MAX_FAILURES_PER_IP = int(os.environ.get("LOGIN_MAX_FAILURES_PER_IP", 20))  # một IP thử quá nhiều tài khoản

    SQLALCHEMY_DATABASE_URI = build_database_uri()
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    UPLOAD_FOLDER = os.path.join(BASE_DIR, os.environ.get("UPLOAD_FOLDER", "uploads/products"))
    SYSTEM_UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads", "system")  # logo cửa hàng
    BACKUP_FOLDER = os.path.join(BASE_DIR, os.environ.get("BACKUP_FOLDER", "backups"))
    ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}
    MAX_CONTENT_LENGTH = int(os.environ.get("MAX_CONTENT_LENGTH", 2 * 1024 * 1024))  # 2MB

    DEBUG = os.environ.get("FLASK_DEBUG", "0") == "1"

    # ---------- Email (Flask-Mail) ----------
    # Ví dụ dùng Gmail: MAIL_SERVER=smtp.gmail.com, MAIL_PORT=587, MAIL_USE_TLS=1,
    # MAIL_USERNAME=email của bạn, MAIL_PASSWORD=mật khẩu ứng dụng (App Password, không phải mật khẩu Gmail thường).
    # Để trống MAIL_USERNAME nếu chưa muốn cấu hình -> hệ thống tự bỏ qua việc gửi email, không lỗi.
    MAIL_SERVER = os.environ.get("MAIL_SERVER", "smtp.gmail.com")
    MAIL_PORT = int(os.environ.get("MAIL_PORT", 587))
    MAIL_USE_TLS = os.environ.get("MAIL_USE_TLS", "1") == "1"
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME", "")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD", "")
    MAIL_DEFAULT_SENDER = os.environ.get("MAIL_DEFAULT_SENDER", MAIL_USERNAME or "no-reply@snackshop.vn")
