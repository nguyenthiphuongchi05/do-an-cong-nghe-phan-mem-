"""Ghi nhật ký hệ thống (bảng NhatKyHeThong). Không bao giờ được làm hỏng luồng nghiệp vụ chính."""
from flask import request, has_request_context
from flask_login import current_user

from extensions import db
from models.system_log import NhatKyHeThong


def _client_ip():
    if not has_request_context():
        return None
    # Chỉ tin header X-Forwarded-For khi chạy sau reverse proxy đáng tin (TRUST_PROXY_HEADERS=1), nếu không
    # kẻ tấn công tự đặt header để né giới hạn đăng nhập theo IP.
    from flask import current_app
    if current_app.config.get("TRUST_PROXY_HEADERS"):
        forwarded = request.headers.get("X-Forwarded-For", "")
        return (forwarded.split(",")[0].strip() or request.remote_addr or None)
    return request.remote_addr or None


def log_event(action, description, category="auth", level="info", user=None, commit=True, email=None):
    """Ghi 1 dòng nhật ký.

    - user: mặc định lấy current_user (nếu đã đăng nhập); truyền User để ghi cho người khác
      (ví dụ lúc đăng nhập chưa có current_user).
    - commit=True: tự commit. Hãy gọi SAU khi đã commit nghiệp vụ chính để không commit dở dang.
    Lỗi khi ghi log chỉ bị nuốt (rollback), không ném ra ngoài.
    """
    try:
        actor = user
        if actor is None and has_request_context() and current_user and current_user.is_authenticated:
            actor = current_user
        entry = NhatKyHeThong(
            user_id=actor.id if actor is not None else None,
            user_email=getattr(actor, "email", None) or email,
            user_role=getattr(actor, "role", None),
            category=category,
            action=action,
            level=level,
            description=(description or "")[:500],
            ip_address=_client_ip(),
        )
        db.session.add(entry)
        if commit:
            db.session.commit()
    except Exception:  # noqa: BLE001 - log lỗi không được làm hỏng request
        db.session.rollback()
