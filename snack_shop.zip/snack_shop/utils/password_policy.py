"""Chính sách mật khẩu: tối thiểu 8 ký tự, có cả chữ và số, không phải mật khẩu quá phổ biến / mật khẩu mặc định của hệ thống."""
import re

from wtforms.validators import ValidationError

MIN_LENGTH = 8
POLICY_TEXT = "Mật khẩu tối thiểu 8 ký tự, gồm cả chữ và số."

# Mật khẩu mặc định của dữ liệu mẫu + vài mật khẩu quá phổ biến: dùng được lúc seed nhưng không được đặt mới
COMMON_PASSWORDS = {
    "admin123", "quanly123", "nhanvien123", "demo123", "password1", "password123", "12345678", "123456789",
    "1234567890", "qwerty123", "abc12345", "matkhau123", "iloveyou1", "11111111a",
}
# Mật khẩu mặc định của tài khoản mẫu (dùng để nhắc đổi)
DEFAULT_PASSWORDS = {"admin123", "quanly123", "nhanvien123", "demo123"}


def password_error(password, email=None):
    """Trả về thông báo lỗi tiếng Việt nếu mật khẩu chưa đạt, ngược lại None."""
    pw = password or ""
    if len(pw) < MIN_LENGTH:
        return POLICY_TEXT
    if not re.search(r"[A-Za-z]", pw) or not re.search(r"\d", pw):
        return POLICY_TEXT
    if pw.lower() in COMMON_PASSWORDS:
        return "Mật khẩu quá phổ biến, hãy chọn mật khẩu khó đoán hơn."
    if email and pw.lower() == email.lower().split("@")[0]:
        return "Mật khẩu không được trùng với tên đăng nhập (phần trước @ của email)."
    return None


def is_default_or_weak(password):
    """Mật khẩu đang dùng là mặc định hoặc không đạt chính sách (để nhắc người dùng đổi)."""
    return password in DEFAULT_PASSWORDS or password_error(password) is not None


def strong_password(form, field):
    """Validator WTForms."""
    if not field.data:
        return
    err = password_error(field.data, getattr(getattr(form, "email", None), "data", None))
    if err:
        raise ValidationError(err)
