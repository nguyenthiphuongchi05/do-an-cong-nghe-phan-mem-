"""
Ma trận phân quyền theo vai trò (RBAC).

Mỗi quyền là một chuỗi "nhóm.hành_động". Route dùng @permission_required("...") để kiểm tra,
template dùng current_user.has_permission("...") để ẩn/hiện menu. Muốn đổi quyền của một vai trò
chỉ cần sửa file này.

Nguyên tắc theo đặc tả:
- Admin: kỹ thuật + tài khoản, KHÔNG quản lý hoạt động bán hàng hằng ngày.
- Quản lý: kinh doanh + giám sát, KHÔNG bảo trì kỹ thuật / phân quyền hệ thống.
- Nhân viên: nghiệp vụ hằng ngày, KHÔNG phân quyền / cấu hình hệ thống.
- Khách hàng: chỉ mua sắm và xem thông tin của chính mình (không có quyền nào ở khu vực /admin).
"""
from models.user import ROLE_ADMIN, ROLE_CHAIN_MANAGER, ROLE_MANAGER, ROLE_STAFF, ROLE_CUSTOMER

# Nhãn tiếng Việt cho từng quyền (dùng hiển thị bảng phân quyền ở trang quản lý tài khoản)
PERMISSION_LABELS = {
    # --- Quản trị hệ thống (Admin) ---
    "account.manage": "Quản lý mọi tài khoản, khóa/mở khóa, đặt lại mật khẩu",
    "role.assign": "Phân quyền người dùng",
    "system.config": "Cấu hình hệ thống, logo, thông tin cửa hàng",
    "system.backup": "Sao lưu / khôi phục dữ liệu",
    "system.log": "Xem nhật ký hoạt động",
    "system.maintenance": "Kiểm tra lỗi, bảo trì hệ thống",
    "branch.manage": "Quản lý chi nhánh (thêm, sửa, ngừng hoạt động)",
    # --- Điều hành toàn chuỗi (Quản lý chuỗi) ---
    "product.manage": "Quản lý danh mục, sản phẩm & giá bán chung toàn chuỗi",
    "supplier.manage": "Quản lý nhà cung cấp",
    "report.chain": "Xem báo cáo gộp tất cả chi nhánh",
    "staff.manage.chain": "Tạo / quản lý tài khoản quản lý chi nhánh và nhân viên mọi chi nhánh",
    # --- Điều hành chi nhánh (Quản lý chi nhánh) + giám sát (Quản lý chuỗi) ---
    "voucher.manage": "Quản lý khuyến mãi / voucher (chuỗi: mọi mã; chi nhánh: mã của chi nhánh mình)",
    "report.view": "Xem doanh thu, lợi nhuận, báo cáo nhập/xuất/bán hàng",
    "staff.performance": "Theo dõi hiệu suất nhân viên",
    "stock.adjust.approve": "Duyệt phiếu điều chỉnh kho (chi nhánh: phiếu của nhân viên; chuỗi: mọi phiếu)",
    "staff.manage": "Tạo / quản lý tài khoản nhân viên của chi nhánh mình",
    "receipt.manage": "Lập, phân công, hủy phiếu nhập hàng của chi nhánh",
    "stock.transfer": "Chuyển hàng giữa các chi nhánh (gửi / nhận / hủy)",
    # --- Nghiệp vụ hằng ngày tại chi nhánh (Quản lý chi nhánh + Nhân viên) ---
    "product.view": "Tra cứu sản phẩm (chỉ xem)",
    "inventory.view": "Xem tồn kho, hàng sắp hết / gần hết hạn",
    "order.view": "Xem và giám sát đơn hàng",
    "order.process": "Xác nhận, cập nhật trạng thái đơn hàng, cập nhật giao hàng",
    "order.request": "Tiếp nhận yêu cầu đổi / hủy đơn",
    "sale.create": "Bán hàng tại quầy, lập hóa đơn",
    "stock.adjust": "Lập phiếu điều chỉnh kho (kiểm kê chênh lệch, hàng hỏng, thất thoát)",
    "receipt.view": "Xem phiếu nhập hàng",
    "receipt.record": "Ghi nhận nhập hàng theo phân công",
    "customer.view": "Tra cứu thông tin khách hàng phục vụ đơn hàng",
}

# Nguyên tắc: Admin lo kỹ thuật + tài khoản; Quản lý chuỗi lo kinh doanh toàn chuỗi nhưng KHÔNG vận hành cửa hàng;
# Quản lý chi nhánh vận hành một chi nhánh; Nhân viên làm nghiệp vụ hằng ngày. Quyền chồng nhau được giữ ở mức tối thiểu.
ROLE_PERMISSIONS = {
    ROLE_ADMIN: {
        "account.manage", "role.assign", "system.config", "system.backup",
        "system.log", "system.maintenance", "branch.manage",
    },
    ROLE_CHAIN_MANAGER: {
        "product.manage", "product.view", "supplier.manage", "voucher.manage",
        "report.view", "report.chain", "staff.performance", "stock.adjust.approve",
        "staff.manage", "staff.manage.chain",
        "inventory.view", "order.view", "receipt.view", "customer.view",
    },
    ROLE_MANAGER: {
        "product.view", "voucher.manage", "report.view", "staff.performance",
        "stock.adjust", "stock.adjust.approve", "staff.manage", "stock.transfer", "receipt.manage",
        "inventory.view", "order.view", "order.process", "order.request", "sale.create",
        "receipt.view", "receipt.record", "customer.view",
    },
    ROLE_STAFF: {
        "product.view", "inventory.view", "order.view", "order.process", "order.request",
        "sale.create", "stock.adjust", "receipt.view", "receipt.record", "customer.view",
    },
    ROLE_CUSTOMER: set(),
}


def role_has_permission(role, permission):
    return permission in ROLE_PERMISSIONS.get(role, set())


def permission_matrix():
    """Dữ liệu cho bảng phân quyền: [(nhãn quyền, {vai_trò: True/False}), ...]."""
    roles = [ROLE_ADMIN, ROLE_CHAIN_MANAGER, ROLE_MANAGER, ROLE_STAFF]
    return [
        (label, {r: perm in ROLE_PERMISSIONS[r] for r in roles})
        for perm, label in PERMISSION_LABELS.items()
    ]
