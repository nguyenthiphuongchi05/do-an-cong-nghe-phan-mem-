"""Ngữ cảnh chi nhánh của request hiện tại + tự động giới hạn dữ liệu theo chi nhánh.

- Khách hàng: chọn chi nhánh để xem tồn kho và đặt hàng (lưu trong session, mặc định chi nhánh đầu tiên).
- Quản lý / nhân viên được gán chi nhánh: chỉ làm việc trong chi nhánh đó (không đổi được).
- Admin, hoặc quản lý / nhân viên chưa gán chi nhánh: chọn xem 1 chi nhánh hoặc "Tất cả chi nhánh".
- Với nhân sự nội bộ đang xem 1 chi nhánh, mọi truy vấn đơn hàng và phiếu nhập tự lọc theo chi nhánh đó
  (hook `do_orm_execute` bên dưới), nên báo cáo, danh sách, trang chi tiết đều chỉ thấy dữ liệu của chi nhánh.
"""
from flask import g, session, has_request_context
from flask_login import current_user
from sqlalchemy import event
from sqlalchemy.orm import Session, with_loader_criteria

from extensions import db

SESSION_KEY = "branch_id"


def active_branches():
    from models.branch import ChiNhanh
    return ChiNhanh.query.filter_by(is_active=True).order_by(ChiNhanh.id).all()


def default_branch_id():
    from models.branch import ChiNhanh
    row = db.session.query(ChiNhanh.id).filter_by(is_active=True).order_by(ChiNhanh.id).first()
    return row[0] if row else None


def ensure_default_branch():
    """Bảo đảm luôn có ít nhất 1 chi nhánh (CSDL mới hoặc CSDL cũ chưa có chi nhánh)."""
    from models.branch import ChiNhanh
    if db.session.query(ChiNhanh.id).first() is None:
        db.session.add(ChiNhanh(code="CN01", name="Chi nhánh 1", is_active=True))
        db.session.commit()


def _valid_branch_id(value, only_active=True):
    from models.branch import ChiNhanh
    try:
        bid = int(value)
    except (TypeError, ValueError):
        return None
    row = db.session.get(ChiNhanh, bid)
    if row and (row.is_active or not only_active):
        return bid
    return None


def init_request_context():
    """Gọi đầu mỗi request: xác định chi nhánh đang dùng (g.branch_id) và phạm vi lọc dữ liệu (g.scope_branch_id)."""
    g.branch_id = None
    g.scope_branch_id = None
    if current_user.is_authenticated and current_user.is_backoffice:
        if current_user.branch_id:
            bid = current_user.branch_id
            g.branch_locked = True
        else:
            bid = _valid_branch_id(session.get(SESSION_KEY), only_active=False)
            g.branch_locked = False
        g.branch_id = bid
        g.scope_branch_id = bid
        return
    bid = _valid_branch_id(session.get(SESSION_KEY))
    g.branch_id = bid or default_branch_id()
    g.branch_locked = False


def current_branch_id():
    """Chi nhánh đang chọn; None nghĩa là tất cả chi nhánh (hoặc đang ở ngoài request)."""
    if not has_request_context():
        return None
    return g.get("branch_id")


def write_branch_id():
    """Chi nhánh dùng khi GHI dữ liệu (tạo đơn, nhập kho, đặt tồn): chi nhánh đang chọn, nếu không có thì mặc định."""
    return current_branch_id() or default_branch_id()


def current_branch():
    from models.branch import ChiNhanh
    bid = current_branch_id()
    return db.session.get(ChiNhanh, bid) if bid else None


def _scope_id():
    if not has_request_context():
        return None
    return g.get("scope_branch_id")


@event.listens_for(Session, "do_orm_execute")
def _scope_orders_and_receipts(state):
    if not state.is_select or state.is_column_load or state.is_relationship_load:
        return
    if state.execution_options.get("skip_branch_scope"):
        return  # truy vấn toàn hệ thống (vd đếm số phiếu để sinh mã không trùng)
    bid = _scope_id()
    if bid is None:
        return
    from models.order import Order
    from models.receipt import PhieuNhap
    state.statement = state.statement.options(
        with_loader_criteria(Order, Order.branch_id == bid, include_aliases=True),
        with_loader_criteria(PhieuNhap, PhieuNhap.branch_id == bid, include_aliases=True),
    )
