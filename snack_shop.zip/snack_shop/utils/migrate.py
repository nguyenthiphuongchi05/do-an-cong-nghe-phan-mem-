"""
Nâng cấp schema nhẹ cho CSDL đã tạo từ phiên bản cũ (db.create_all() chỉ tạo bảng mới,
không thêm cột vào bảng đã có). Chạy mỗi lần khởi động, bỏ qua nếu cột đã tồn tại.
Khi dự án lớn hơn nên chuyển sang Flask-Migrate/Alembic.
"""
from sqlalchemy import inspect, text

from extensions import db

# (bảng, cột, định nghĩa DDL)
NEW_COLUMNS = [
    ("users", "role", "VARCHAR(20) NOT NULL DEFAULT 'customer'"),
    ("users", "is_locked", "BOOLEAN NOT NULL DEFAULT FALSE"),
    ("users", "last_login_at", "DATETIME"),
    ("products", "cost_price", "INTEGER"),
    ("order_items", "cost_price", "INTEGER"),
    ("orders", "channel", "VARCHAR(20) NOT NULL DEFAULT 'online'"),
    ("orders", "handled_by_id", "INTEGER"),
    ("orders", "handled_at", "DATETIME"),
    ("orders", "completed_at", "DATETIME"),
    ("orders", "request_type", "VARCHAR(20)"),
    ("orders", "request_reason", "VARCHAR(255)"),
    ("orders", "request_status", "VARCHAR(20)"),
    ("orders", "request_at", "DATETIME"),
    ("orders", "request_note", "VARCHAR(255)"),
    ("orders", "request_handled_by_id", "INTEGER"),
    ("users", "branch_id", "INTEGER"),
    ("orders", "branch_id", "INTEGER"),
    ("phieu_nhap", "branch_id", "INTEGER"),
    ("vouchers", "branch_id", "INTEGER"),
    ("users", "totp_secret", "VARCHAR(64)"),
    ("users", "totp_enabled", "BOOLEAN NOT NULL DEFAULT FALSE"),
    ("chuyen_kho", "status", "VARCHAR(20) NOT NULL DEFAULT 'received'"),  # bản cũ chuyển kho tức thì = đã nhận
    ("chuyen_kho", "handled_by_id", "INTEGER"),
    ("chuyen_kho", "handled_at", "DATETIME"),
    ("chuyen_kho", "response_note", "VARCHAR(255)"),
]


def upgrade_schema():
    # Script nâng cấp này viết cho CSDL SQLite (hoặc MySQL) đã có từ bản cũ.
    if db.engine.url.get_backend_name() not in ("sqlite", "mysql"):
        return
    inspector = inspect(db.engine)
    tables = set(inspector.get_table_names())

    with db.engine.begin() as conn:
        for table, column, ddl in NEW_COLUMNS:
            if table not in tables:
                continue
            existing = {c["name"] for c in inspector.get_columns(table)}
            if column not in existing:
                conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}"))

    # Chuyển cờ is_admin / is_staff cũ sang cột role rồi bỏ 2 cột cũ
    if "users" in tables:
        inspector = inspect(db.engine)  # đọc lại sau khi ALTER
        user_cols = {c["name"] for c in inspector.get_columns("users")}
        with db.engine.begin() as conn:
            if "is_admin" in user_cols:
                conn.execute(text("UPDATE users SET role = 'admin' WHERE is_admin = 1 AND role = 'customer'"))
            if "is_staff" in user_cols:
                conn.execute(text("UPDATE users SET role = 'staff' WHERE is_staff = 1 AND role = 'customer'"))
        for legacy in ("is_admin", "is_staff"):
            if legacy in user_cols:
                try:
                    with db.engine.begin() as conn:
                        conn.execute(text(f"ALTER TABLE users DROP COLUMN {legacy}"))
                except Exception:  # noqa: BLE001 - DB quá cũ không hỗ trợ DROP COLUMN: để nguyên cột cũ
                    pass

    _migrate_stock_to_branches()


def _migrate_stock_to_branches():
    """Bản cũ lưu tồn kho ở cột products.stock. Chuyển sang bảng ton_kho của chi nhánh mặc định
    rồi bỏ cột cũ; gán các đơn hàng / phiếu nhập cũ vào chi nhánh mặc định."""
    from models.branch import ChiNhanh
    inspector = inspect(db.engine)
    if "products" not in inspector.get_table_names():
        return
    product_cols = {c["name"] for c in inspector.get_columns("products")}

    branch = ChiNhanh.query.order_by(ChiNhanh.id).first()
    if not branch:
        branch = ChiNhanh(code="CN01", name="Chi nhánh 1", is_active=True)
        db.session.add(branch)
        db.session.commit()

    with db.engine.begin() as conn:
        if "stock" in product_cols:
            conn.execute(text(
                "INSERT INTO ton_kho (product_id, branch_id, quantity) "
                "SELECT id, :b, COALESCE(stock, 0) FROM products "
                "WHERE id NOT IN (SELECT product_id FROM ton_kho)"), {"b": branch.id})
        for table in ("orders", "phieu_nhap"):
            conn.execute(text(f"UPDATE {table} SET branch_id = :b WHERE branch_id IS NULL"), {"b": branch.id})
    if "stock" in product_cols:
        try:
            with db.engine.begin() as conn:
                conn.execute(text("ALTER TABLE products DROP COLUMN stock"))
        except Exception:  # noqa: BLE001 - DB quá cũ không hỗ trợ DROP COLUMN: để nguyên cột cũ
            pass
