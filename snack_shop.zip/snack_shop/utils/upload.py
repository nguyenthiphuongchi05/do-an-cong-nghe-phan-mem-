import os
import uuid
from werkzeug.utils import secure_filename
from flask import current_app


def allowed_file(filename):
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    return ext in current_app.config["ALLOWED_EXTENSIONS"]


def save_product_image(file_storage):
    """
    Lưu ảnh sản phẩm admin upload vào uploads/products/.
    Trả về tên file đã lưu (để ghi vào cột image_filename, với image_source='upload'),
    hoặc None nếu không có file hợp lệ.
    """
    if not file_storage or file_storage.filename == "":
        return None

    if not allowed_file(file_storage.filename):
        raise ValueError("Định dạng ảnh không hợp lệ. Chỉ chấp nhận: png, jpg, jpeg, webp")

    ext = file_storage.filename.rsplit(".", 1)[-1].lower()
    # Đặt tên file ngẫu nhiên để tránh trùng và tránh lộ tên gốc
    filename = secure_filename(f"{uuid.uuid4().hex}.{ext}")

    upload_folder = current_app.config["UPLOAD_FOLDER"]
    os.makedirs(upload_folder, exist_ok=True)
    file_storage.save(os.path.join(upload_folder, filename))

    return filename


def delete_product_image(filename):
    """Xóa ảnh cũ khi cập nhật/xóa sản phẩm (chỉ áp dụng ảnh trong uploads/, không đụng ảnh mặc định)."""
    if not filename:
        return
    upload_folder = current_app.config["UPLOAD_FOLDER"]
    path = os.path.join(upload_folder, filename)
    if os.path.exists(path):
        os.remove(path)


def save_logo_image(file_storage):
    """Lưu logo cửa hàng vào uploads/system/. Trả về tên file hoặc None."""
    if not file_storage or file_storage.filename == "":
        return None
    if not allowed_file(file_storage.filename):
        raise ValueError("Định dạng logo không hợp lệ. Chỉ chấp nhận: png, jpg, jpeg, webp")
    ext = file_storage.filename.rsplit(".", 1)[-1].lower()
    filename = secure_filename(f"logo-{uuid.uuid4().hex[:12]}.{ext}")
    folder = current_app.config["SYSTEM_UPLOAD_FOLDER"]
    os.makedirs(folder, exist_ok=True)
    file_storage.save(os.path.join(folder, filename))
    return filename


def delete_logo_image(filename):
    if not filename:
        return
    path = os.path.join(current_app.config["SYSTEM_UPLOAD_FOLDER"], filename)
    if os.path.exists(path):
        os.remove(path)
