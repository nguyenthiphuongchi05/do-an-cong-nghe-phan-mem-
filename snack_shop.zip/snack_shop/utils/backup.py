"""Sao lưu / khôi phục CSDL SQLite bằng sqlite3 backup API (an toàn cả khi DB đang được dùng).
Với MySQL/PostgreSQL hãy dùng mysqldump / pg_dump (xem README)."""
import os
import re
import sqlite3
from datetime import datetime

from utils.timeutil import vn_now

from flask import current_app
from extensions import db

BACKUP_NAME_RE = re.compile(r"^[A-Za-z0-9_\-]+\.db$")


def is_sqlite():
    return db.engine.url.get_backend_name() == "sqlite"


def db_path():
    return db.engine.url.database


def backup_dir():
    path = current_app.config["BACKUP_FOLDER"]
    os.makedirs(path, exist_ok=True)
    return path


def list_backups():
    folder = backup_dir()
    rows = []
    for name in os.listdir(folder):
        if BACKUP_NAME_RE.match(name):
            st = os.stat(os.path.join(folder, name))
            rows.append({"name": name, "size": st.st_size, "created": datetime.utcfromtimestamp(st.st_mtime)})
    rows.sort(key=lambda r: r["created"], reverse=True)
    return rows


def backup_path(name):
    """Đường dẫn an toàn tới file sao lưu (chặn path traversal). Trả None nếu không hợp lệ/không tồn tại."""
    if not name or not BACKUP_NAME_RE.match(name):
        return None
    path = os.path.join(backup_dir(), name)
    return path if os.path.isfile(path) else None


def create_backup(prefix="sao-luu"):
    name = f"{prefix}-{vn_now().strftime('%Y%m%d-%H%M%S')}.db"
    path = os.path.join(backup_dir(), name)
    src = sqlite3.connect(db_path())
    dst = sqlite3.connect(path)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    return name


def restore_backup(name):
    """Khôi phục từ file sao lưu. Tự tạo thêm 1 bản sao lưu 'truoc-khoi-phuc' để có đường lui."""
    path = backup_path(name)
    if not path:
        raise ValueError("File sao lưu không tồn tại.")
    probe = sqlite3.connect(path)
    try:
        tables = {r[0] for r in probe.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    except sqlite3.DatabaseError as exc:
        raise ValueError("File không phải CSDL SQLite hợp lệ.") from exc
    finally:
        probe.close()
    if "users" not in tables:
        raise ValueError("File sao lưu không chứa dữ liệu của hệ thống này.")

    safety = create_backup(prefix="truoc-khoi-phuc")
    db.session.remove()
    db.engine.dispose()
    src = sqlite3.connect(path)
    dst = sqlite3.connect(db_path())
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    return safety
