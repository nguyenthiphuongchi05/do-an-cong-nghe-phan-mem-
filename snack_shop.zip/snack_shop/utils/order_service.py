"""Nghiệp vụ đơn hàng dùng chung cho nhân viên / quản lý (đổi trạng thái, xử lý yêu cầu đổi-hủy)."""
from datetime import datetime, timedelta

from sqlalchemy import update as sa_update
from sqlalchemy.exc import IntegrityError

from extensions import db
from models import Product
from utils.audit import log_event
from utils.branch import default_branch_id
from utils.inventory import add_stock
from utils.helpers import order_status_label, generate_order_code

# Luồng trạng thái hợp lệ: chỉ đi tiến hoặc hủy, đơn đã hoàn thành/đã hủy là trạng thái cuối
ALLOWED_TRANSITIONS = {
    "pending": ["confirmed", "cancelled"],
    "confirmed": ["shipping", "cancelled"],
    "shipping": ["completed", "cancelled"],
    "completed": [],
    "cancelled": [],
}

EXCHANGE_WINDOW_DAYS = 7  # khách được yêu cầu đổi hàng trong 7 ngày kể từ khi đơn hoàn thành
CANCEL_ALLOWED_STATUSES = ("pending", "confirmed")  # khách chỉ được yêu cầu hủy khi đơn chưa giao

REQUEST_TYPE_LABELS = {"cancel": "Hủy đơn", "exchange": "Đổi hàng"}
REQUEST_STATUS_LABELS = {"pending": "Chờ xử lý", "approved": "Đã chấp nhận", "rejected": "Đã từ chối"}


BANK_PAID_REQUIRED = ("shipping", "completed")  # đơn chuyển khoản phải thu tiền trước khi giao / hoàn thành


def awaiting_bank_payment(order):
    """Đơn chuyển khoản ngân hàng mà chưa ghi nhận đã thu tiền."""
    return order.payment_method == "bank_transfer" and not order.is_paid


def add_order_with_unique_code(order, max_attempts=10):
    """Lưu đơn (add + flush) với mã đơn không trùng.

    Mã đơn tính theo giây nên 2 đơn cùng giây sẽ trùng; cột `code` là UNIQUE nên lần lưu thứ hai
    sẽ lỗi. Ở đây thử lại với hậu tố 01, 02, ... trong một SAVEPOINT (không ảnh hưởng phần còn lại
    của giao dịch). Gọi hàm này thay cho db.session.add(order) + flush() khi tạo đơn mới."""
    base = generate_order_code()
    last_error = None
    for n in range(max_attempts):
        order.code = base if n == 0 else f"{base}{n:02d}"
        try:
            with db.session.begin_nested():
                db.session.add(order)
                db.session.flush()
            return order
        except IntegrityError as exc:
            last_error = exc
    raise last_error


def restock_items(order):
    """Hoàn tồn kho các dòng của đơn về ĐÚNG chi nhánh đã bán, bằng UPDATE nguyên tử (không đọc-rồi-ghi)
    để không ghi đè lên lượt bán / nhập diễn ra cùng lúc."""
    branch_id = order.branch_id or default_branch_id()
    for item in order.items:
        if item.product_id:
            add_stock(item.product_id, branch_id, item.quantity)


def change_order_status(order, new_status, actor):
    """Đổi trạng thái đơn theo luồng hợp lệ. Trả về (ok, message).
    - Hủy đơn: hoàn lại tồn kho đã trừ lúc đặt.
    - Hoàn thành: đơn COD được coi là đã thu tiền.
    - Ghi lại nhân viên xử lý để thống kê hiệu suất.
    """
    if new_status == order.status:
        return False, "Đơn hàng đã ở trạng thái này."
    if new_status not in ALLOWED_TRANSITIONS.get(order.status, []):
        return False, (
            f"Không thể chuyển đơn từ '{order_status_label(order.status)}' "
            f"sang '{order_status_label(new_status)}'."
        )

    if new_status in BANK_PAID_REQUIRED and awaiting_bank_payment(order):
        return False, (f"Đơn {order.code} thanh toán chuyển khoản nhưng chưa thu được tiền, chưa thể "
                       f"{'giao hàng' if new_status == 'shipping' else 'hoàn thành'}. "
                       "Hãy kiểm tra sao kê rồi bấm \"Đánh dấu đã nhận tiền\" trong Chi tiết đơn.")

    old_status = order.status
    if new_status == "cancelled":
        restock_items(order)
    if new_status == "completed":
        order.completed_at = datetime.utcnow()
        if order.payment_method == "cod":
            order.is_paid = True

    order.status = new_status
    order.handled_by_id = actor.id
    order.handled_at = datetime.utcnow()
    db.session.commit()

    log_event(
        "order_status",
        f"Đơn {order.code}: {order_status_label(old_status)} → {order_status_label(new_status)}",
        category="order", user=actor,
    )
    return True, f"Đã cập nhật đơn {order.code}: {order_status_label(new_status)}."


def can_request(order, request_type):
    """Kiểm tra khách có được gửi yêu cầu đổi/hủy cho đơn này không. Trả về (ok, lý_do_nếu_không)."""
    if order.request_status == "pending":
        return False, "Đơn hàng này đang có một yêu cầu chờ xử lý."
    if request_type == "cancel":
        if order.status not in CANCEL_ALLOWED_STATUSES:
            return False, "Chỉ có thể yêu cầu hủy khi đơn chưa được giao đi."
        return True, ""
    if request_type == "exchange":
        if order.status != "completed":
            return False, "Chỉ có thể yêu cầu đổi hàng sau khi đơn đã hoàn thành."
        done_at = order.completed_at or order.created_at
        if datetime.utcnow() - done_at > timedelta(days=EXCHANGE_WINDOW_DAYS):
            return False, f"Đã quá {EXCHANGE_WINDOW_DAYS} ngày kể từ khi nhận hàng, không thể yêu cầu đổi."
        return True, ""
    return False, "Loại yêu cầu không hợp lệ."


def resolve_request(order, approve, note, actor):
    """Nhân viên chấp nhận / từ chối yêu cầu. Trả về (ok, message)."""
    if order.request_status != "pending":
        return False, "Đơn này không có yêu cầu nào đang chờ xử lý."

    if approve and order.request_type == "cancel":
        ok, message = change_order_status(order, "cancelled", actor)
        if not ok:
            return False, message

    order.request_status = "approved" if approve else "rejected"
    order.request_note = (note or "").strip()[:255] or None
    order.request_handled_by_id = actor.id
    db.session.commit()

    log_event(
        "order_request",
        f"{'Chấp nhận' if approve else 'Từ chối'} yêu cầu {REQUEST_TYPE_LABELS.get(order.request_type, '')} "
        f"của đơn {order.code}",
        category="order", user=actor,
    )
    return True, "Đã xử lý yêu cầu."
