"""
Bộ tạo mã QR (ISO/IEC 18004) bằng Python thuần — không cần cài thư viện ngoài.

Phạm vi: chế độ byte (UTF-8), mức sửa lỗi M, version 1–10 (tối đa 213 byte) — đủ cho
nội dung thanh toán của đồ án. Xuất ra SVG để nhúng thẳng vào template.

    from utils.qr import make_qr_svg
    svg = make_qr_svg("SNACKSHOP DEMO ...")
"""
from markupsafe import Markup

# ---------------------------------------------------------------- bảng tham số (mức M)
# version: (số byte EC / block, [(số block, số byte dữ liệu / block), ...])
_EC_M = {
    1: (10, [(1, 16)]),
    2: (16, [(1, 28)]),
    3: (26, [(1, 44)]),
    4: (18, [(2, 32)]),
    5: (24, [(2, 43)]),
    6: (16, [(4, 27)]),
    7: (18, [(4, 31)]),
    8: (22, [(2, 38), (2, 39)]),
    9: (22, [(3, 36), (2, 37)]),
    10: (26, [(4, 43), (1, 44)]),
}
_ALIGN = {
    1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34],
    7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50],
}
_ECL_M_BITS = 0  # mã 2 bit của mức M trong thông tin định dạng
_MAX_VERSION = 10


def data_capacity(version):
    ec, groups = _EC_M[version]
    return sum(n * d for n, d in groups)


# ---------------------------------------------------------------- Reed–Solomon trên GF(256)
_EXP = [0] * 512
_LOG = [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i] = _x
    _LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]


def _gf_mul(a, b):
    return 0 if a == 0 or b == 0 else _EXP[_LOG[a] + _LOG[b]]


def _rs_generator(degree):
    poly = [1]
    for i in range(degree):
        nxt = [0] * (len(poly) + 1)
        for j, c in enumerate(poly):
            nxt[j] ^= c
            nxt[j + 1] ^= _gf_mul(c, _EXP[i])
        poly = nxt
    return poly  # hệ số từ bậc cao xuống thấp


def rs_remainder(data, degree):
    """Phần dư RS (các byte sửa lỗi) của `data`."""
    gen = _rs_generator(degree)
    rem = list(data) + [0] * degree
    for i in range(len(data)):
        coef = rem[i]
        if coef:
            for j, g in enumerate(gen):
                rem[i + j] ^= _gf_mul(g, coef)
    return rem[len(data):]


# ---------------------------------------------------------------- đóng gói dữ liệu
def _choose_version(n_bytes):
    for v in range(1, _MAX_VERSION + 1):
        count_bits = 8 if v <= 9 else 16
        if 4 + count_bits + 8 * n_bytes <= 8 * data_capacity(v):
            return v
    raise ValueError(f"Nội dung quá dài cho mã QR ({n_bytes} byte, tối đa 213).")


def _data_codewords(payload, version):
    bits = []

    def put(value, length):
        for i in range(length - 1, -1, -1):
            bits.append((value >> i) & 1)

    put(0b0100, 4)  # chế độ byte
    put(len(payload), 8 if version <= 9 else 16)
    for b in payload:
        put(b, 8)
    capacity_bits = 8 * data_capacity(version)
    put(0, min(4, capacity_bits - len(bits)))  # ký hiệu kết thúc
    while len(bits) % 8:
        bits.append(0)
    words = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = (0xEC, 0x11)
    i = 0
    while len(words) < data_capacity(version):
        words.append(pad[i % 2])
        i += 1
    return words


def _interleave(words, version):
    ec_len, groups = _EC_M[version]
    blocks, pos = [], 0
    for n_blocks, size in groups:
        for _ in range(n_blocks):
            blocks.append(words[pos:pos + size])
            pos += size
    ecs = [rs_remainder(b, ec_len) for b in blocks]
    out = []
    for i in range(max(len(b) for b in blocks)):
        for b in blocks:
            if i < len(b):
                out.append(b[i])
    for i in range(ec_len):
        for e in ecs:
            out.append(e[i])
    return out


# ---------------------------------------------------------------- thông tin định dạng / phiên bản
def format_bits(mask):
    data = (_ECL_M_BITS << 3) | mask
    rem = data
    for _ in range(10):
        rem = (rem << 1) ^ ((rem >> 9) * 0x537)
    return ((data << 10) | rem) ^ 0x5412


def version_bits(version):
    rem = version
    for _ in range(12):
        rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
    return (version << 12) | rem


def _bit(value, i):
    return (value >> i) & 1


# ---------------------------------------------------------------- ma trận
class _Matrix:
    def __init__(self, version):
        self.version = version
        self.size = 17 + 4 * version
        n = self.size
        self.mod = [[0] * n for _ in range(n)]
        self.func = [[False] * n for _ in range(n)]
        self._draw_function_patterns()

    def _set(self, x, y, dark):
        self.mod[y][x] = 1 if dark else 0
        self.func[y][x] = True

    def _draw_function_patterns(self):
        n = self.size
        for i in range(n):  # đường timing
            self._set(6, i, i % 2 == 0)
            self._set(i, 6, i % 2 == 0)
        for cx, cy in ((3, 3), (n - 4, 3), (3, n - 4)):  # 3 ô định vị + dải phân cách
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if 0 <= x < n and 0 <= y < n:
                        self._set(x, y, max(abs(dx), abs(dy)) not in (2, 4))
        centers = _ALIGN[self.version]
        last = len(centers) - 1
        for i, cy in enumerate(centers):  # ô căn chỉnh
            for j, cx in enumerate(centers):
                if (i == 0 and j == 0) or (i == 0 and j == last) or (i == last and j == 0):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self._set(cx + dx, cy + dy, max(abs(dx), abs(dy)) != 1)
        self._draw_format(0)  # chỉ để đánh dấu vùng dành riêng
        if self.version >= 7:
            bits = version_bits(self.version)
            for i in range(18):
                a, b = n - 11 + i % 3, i // 3
                self._set(a, b, _bit(bits, i))
                self._set(b, a, _bit(bits, i))

    def _draw_format(self, mask):
        n = self.size
        bits = format_bits(mask)
        for i in range(0, 6):
            self._set(8, i, _bit(bits, i))
        self._set(8, 7, _bit(bits, 6))
        self._set(8, 8, _bit(bits, 7))
        self._set(7, 8, _bit(bits, 8))
        for i in range(9, 15):
            self._set(14 - i, 8, _bit(bits, i))
        for i in range(0, 8):
            self._set(n - 1 - i, 8, _bit(bits, i))
        for i in range(8, 15):
            self._set(8, n - 15 + i, _bit(bits, i))
        self._set(8, n - 8, True)  # ô tối cố định

    def place_data(self, codewords):
        n = self.size
        total = len(codewords) * 8
        i = 0
        right = n - 1
        while right >= 1:
            if right == 6:
                right = 5
            for vert in range(n):
                for j in range(2):
                    x = right - j
                    upward = ((right + 1) & 2) == 0
                    y = n - 1 - vert if upward else vert
                    if not self.func[y][x] and i < total:
                        self.mod[y][x] = _bit(codewords[i >> 3], 7 - (i & 7))
                        i += 1
            right -= 2

    @staticmethod
    def mask_hit(mask, y, x):
        if mask == 0:
            return (x + y) % 2 == 0
        if mask == 1:
            return y % 2 == 0
        if mask == 2:
            return x % 3 == 0
        if mask == 3:
            return (x + y) % 3 == 0
        if mask == 4:
            return (x // 3 + y // 2) % 2 == 0
        if mask == 5:
            return x * y % 2 + x * y % 3 == 0
        if mask == 6:
            return (x * y % 2 + x * y % 3) % 2 == 0
        return ((x + y) % 2 + x * y % 3) % 2 == 0

    def apply_mask(self, mask):
        for y in range(self.size):
            for x in range(self.size):
                if not self.func[y][x] and self.mask_hit(mask, y, x):
                    self.mod[y][x] ^= 1

    def penalty(self):
        n, m = self.size, self.mod
        score = 0
        lines = [row for row in m] + [[m[y][x] for y in range(n)] for x in range(n)]
        pat_a = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0]
        pat_b = pat_a[::-1]
        for line in lines:
            run = 1
            for k in range(1, n):
                if line[k] == line[k - 1]:
                    run += 1
                else:
                    if run >= 5:
                        score += 3 + run - 5
                    run = 1
            if run >= 5:
                score += 3 + run - 5
            for k in range(n - 10):
                seg = line[k:k + 11]
                if seg == pat_a or seg == pat_b:
                    score += 40
        for y in range(n - 1):
            for x in range(n - 1):
                if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                    score += 3
        dark = sum(sum(r) for r in m)
        k = abs(dark * 20 - n * n * 10) // (n * n)
        return score + 10 * k


def build_matrix(text):
    """Trả về ma trận QR (list các hàng 0/1, 1 = ô tối) cho chuỗi `text`."""
    payload = text.encode("utf-8")
    version = _choose_version(len(payload))
    codewords = _interleave(_data_codewords(payload, version), version)
    best = None
    for mask in range(8):
        mx = _Matrix(version)
        mx.place_data(codewords)
        mx.apply_mask(mask)
        mx._draw_format(mask)
        score = mx.penalty()
        if best is None or score < best[0]:
            best = (score, mx)
    return best[1].mod


def make_qr_svg(text, module=6, border=4, label="Mã QR chuyển khoản (mô phỏng)"):
    """SVG của mã QR (Markup — an toàn để in thẳng trong Jinja)."""
    grid = build_matrix(text)
    n = len(grid)
    size = (n + 2 * border) * module
    parts = []
    for y, row in enumerate(grid):
        x = 0
        while x < n:
            if row[x]:
                start = x
                while x < n and row[x]:
                    x += 1
                parts.append(f"M{start + border},{y + border}h{x - start}v1h-{x - start}z")
            else:
                x += 1
    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {n + 2 * border} {n + 2 * border}" '
        f'width="{size}" height="{size}" role="img" aria-label="{label}" shape-rendering="crispEdges">'
        f'<rect width="100%" height="100%" fill="#fff"/><path d="{"".join(parts)}" fill="#000"/></svg>'
    )
    return Markup(svg)
