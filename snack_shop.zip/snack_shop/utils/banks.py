"""
Danh sách ngân hàng hỗ trợ chuyển khoản thủ công.

LƯU Ý QUAN TRỌNG: số tài khoản/tên chủ tài khoản bên dưới là DỮ LIỆU DEMO.
Khi triển khai thật, đổi lại đúng thông tin tài khoản ngân hàng của bạn.
Ảnh trong static/images/banks/ là huy hiệu tự tạo (màu + chữ viết tắt), KHÔNG phải
logo chính thức của ngân hàng (logo thật là tài sản thương hiệu, cần xin phép mới
được dùng) — bạn có thể tự thay bằng logo chính thức nếu có bản quyền/được phép.
"""

# ---------------------------------------------------------------------------
# CHẾ ĐỘ MÔ PHỎNG: chưa tích hợp cổng thanh toán / API ngân hàng thật.
# - Số tài khoản bên dưới là dữ liệu giả; hệ thống KHÔNG tự biết khách đã chuyển tiền hay chưa
#   (nhân viên đối chiếu thủ công rồi bấm "Đánh dấu đã nhận tiền").
# - Mã QR chỉ chứa văn bản mô phỏng, KHÔNG phải mã VietQR/NAPAS nên app ngân hàng không thể
#   tạo lệnh chuyển tiền thật từ mã này (tránh chuyển nhầm vào tài khoản không tồn tại).
# Khi có tài khoản thật + cần QR thanh toán thật: đổi DEMO_PAYMENT = False, thay số tài khoản
# trong BANKS, và thay hàm qr_payload() bằng chuỗi VietQR (chuẩn EMVCo/NAPAS) của ngân hàng.
# ---------------------------------------------------------------------------
DEMO_PAYMENT = True
DEMO_NOTICE = (
    "Đây là thông tin thanh toán MÔ PHỎNG phục vụ đồ án — chưa kết nối ngân hàng thật. "
    "Vui lòng KHÔNG chuyển tiền thật vào tài khoản và mã QR này."
)

BANKS = [
    {
        "code": "vcb",
        "name": "Vietcombank",
        "account_number": "0011002233445",
        "account_holder": "CONG TY TNHH SNACKSHOP",
        "color": "#00693C",
    },
    {
        "code": "tcb",
        "name": "Techcombank",
        "account_number": "19036789012345",
        "account_holder": "CONG TY TNHH SNACKSHOP",
        "color": "#DA291C",
    },
    {
        "code": "mb",
        "name": "MB Bank",
        "account_number": "0987654321012",
        "account_holder": "CONG TY TNHH SNACKSHOP",
        "color": "#8B1E3F",
    },
    {
        "code": "acb",
        "name": "ACB",
        "account_number": "1234567890",
        "account_holder": "CONG TY TNHH SNACKSHOP",
        "color": "#003DA5",
    },
    {
        "code": "bidv",
        "name": "BIDV",
        "account_number": "21110009998888",
        "account_holder": "CONG TY TNHH SNACKSHOP",
        "color": "#00A651",
    },
    {
        "code": "tpb",
        "name": "TPBank",
        "account_number": "00369852147",
        "account_holder": "CONG TY TNHH SNACKSHOP",
        "color": "#7B2D8E",
    },
]

BANKS_BY_CODE = {b["code"]: b for b in BANKS}


def get_bank(code):
    return BANKS_BY_CODE.get(code)


def transfer_content(order):
    """Nội dung chuyển khoản: chính là mã đơn hàng (để nhân viên đối chiếu)."""
    return order.code


def qr_payload(order, bank):
    """Chuỗi được mã hóa trong QR. Ở chế độ mô phỏng đây chỉ là văn bản đọc được (không phải VietQR)."""
    lines = []
    if DEMO_PAYMENT:
        lines.append("SNACKSHOP - THONG TIN THANH TOAN MO PHONG (DO AN)")
        lines.append("KHONG PHAI GIAO DICH THAT")
    lines += [
        f"Ngan hang: {bank['name']}",
        f"STK: {bank['account_number']}",
        f"Chu TK: {bank['account_holder']}",
        f"So tien: {order.total_amount} VND",
        f"Noi dung: {transfer_content(order)}",
    ]
    return "\n".join(lines)
