"""Hàm SQL dùng chung cho nhiều hệ quản trị CSDL (SQLite, MySQL)."""
from sqlalchemy import Date
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.sql.expression import FunctionElement


class day_of(FunctionElement):
    """Lấy phần ngày của một cột datetime: date(x)."""
    type = Date()
    name = "day_of"
    inherit_cache = True


@compiles(day_of)
def _day_default(element, compiler, **kw):
    return "date(%s)" % compiler.process(element.clauses, **kw)
