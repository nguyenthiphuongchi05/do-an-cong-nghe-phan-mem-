from flask import current_app
from flask_mail import Message

from extensions import mail
from utils.helpers import format_vnd


def send_order_confirmation(order):
    """
    Gửi email xác nhận đơn hàng tới user đã đặt đơn.
    Nếu chưa cấu hình SMTP (thiếu MAIL_USERNAME trong .env) thì bỏ qua im lặng,
    không làm crash luồng đặt hàng. Trả về True nếu gửi thành công, False nếu không.
    """
    if not current_app.config.get("MAIL_USERNAME"):
        current_app.logger.info(
            "MAIL_USERNAME chưa được cấu hình trong .env - bỏ qua gửi email xác nhận đơn %s", order.code
        )
        return False

    recipient = order.user.email if order.user else None
    if not recipient:
        return False

    try:
        lines = [f"- {item.product_name} x{item.quantity}: {format_vnd(item.subtotal)}" for item in order.items]

        body_parts = [
            f"Xin chào {order.receiver_name},",
            "",
            f"Cảm ơn bạn đã đặt hàng tại SnackShop! Đơn hàng {order.code} của bạn đã được ghi nhận.",
            "",
            "Chi tiết đơn hàng:",
            *lines,
            "",
            f"Tạm tính: {format_vnd(order.subtotal_amount)}",
        ]
        if order.discount_amount:
            codes = ", ".join(order.voucher_code_list) or "—"
            body_parts.append(f"Giảm giá ({codes}): -{format_vnd(order.discount_amount)}")

        body_parts += [
            f"Tổng thanh toán: {format_vnd(order.total_amount)}",
            "",
            f"Phương thức thanh toán: {order.payment_method.upper()}",
            f"Địa chỉ giao hàng: {order.shipping_address}",
            f"Số điện thoại liên hệ: {order.receiver_phone}",
            "",
            "Chúng tôi sẽ liên hệ để xác nhận và giao hàng trong thời gian sớm nhất.",
            "",
            "Cảm ơn bạn đã ủng hộ SnackShop! 🍿",
        ]
        body = "\n".join(body_parts)

        msg = Message(
            subject=f"Xác nhận đơn hàng {order.code} - SnackShop",
            recipients=[recipient],
            body=body,
        )
        mail.send(msg)
        return True

    except Exception as e:
        # Không để lỗi gửi mail (SMTP sai, mất mạng...) làm hỏng luồng đặt hàng của user
        current_app.logger.warning("Gửi email xác nhận đơn %s thất bại: %s", order.code, e)
        return False
