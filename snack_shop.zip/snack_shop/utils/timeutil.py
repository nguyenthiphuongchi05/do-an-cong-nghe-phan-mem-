"""
Múi giờ Việt Nam (UTC+7, không có giờ mùa hè).

Quy ước của dự án: dữ liệu giờ trong DB lưu theo UTC (datetime.utcnow) — đúng chuẩn, không đổi.
Mọi nơi HIỂN THỊ giờ hoặc NHÓM THEO NGÀY phải đổi sang giờ Việt Nam bằng các hàm ở đây, nếu không
đơn đặt lúc 0h–7h sáng sẽ bị tính vào ngày hôm trước và giờ hiển thị lệch 7 tiếng.
"""
from datetime import date, datetime, time, timedelta

from sqlalchemy import func, text

VN_OFFSET = timedelta(hours=7)


def vn_now():
    """Giờ hiện tại theo Việt Nam (datetime không kèm tzinfo)."""
    return datetime.utcnow() + VN_OFFSET


def to_vn(value):
    """UTC (naive) -> giờ Việt Nam. Giá trị `date` thuần (không có giờ) giữ nguyên."""
    if isinstance(value, datetime):
        return value + VN_OFFSET
    return value


def vn_midnight_utc(vn_date):
    """0h của ngày `vn_date` (giờ VN) tính theo UTC — dùng làm mốc lọc `created_at >= ...`."""
    if isinstance(vn_date, datetime):
        vn_date = vn_date.date()
    return datetime.combine(vn_date, time.min) - VN_OFFSET


def vn_date_sql(column):
    """Biểu thức SQL: ngày (giờ VN) của một cột DateTime lưu UTC — dùng trong GROUP BY."""
    from extensions import db
    dialect = db.engine.dialect.name
    if dialect == "sqlite":
        return func.date(column, "+7 hours")
    if dialect == "postgresql":
        return func.date(column + text("interval '7 hours'"))
    return func.date(func.date_add(column, text("INTERVAL 7 HOUR")))  # MySQL / MariaDB


def vn_dt_filter(value, fmt="%d/%m/%Y %H:%M"):
    """Jinja filter: {{ order.created_at | vn_dt('%d/%m/%Y %H:%M') }}"""
    if value is None:
        return ""
    return to_vn(value).strftime(fmt)
