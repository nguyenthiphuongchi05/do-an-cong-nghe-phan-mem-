from functools import wraps
from flask import abort
from flask_login import current_user


def permission_required(*permissions):
    """Cho phép truy cập nếu user có ÍT NHẤT MỘT trong các quyền được liệt kê.
    Chưa đăng nhập -> 401, đăng nhập nhưng thiếu quyền -> 403.
    Danh sách quyền theo vai trò nằm ở utils/permissions.py.
    """
    def decorator(view_func):
        @wraps(view_func)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                abort(401)
            if not any(current_user.has_permission(p) for p in permissions):
                abort(403)
            return view_func(*args, **kwargs)
        return wrapped
    return decorator


def roles_required(*roles):
    """Cho phép truy cập nếu vai trò của user nằm trong danh sách."""
    def decorator(view_func):
        @wraps(view_func)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                abort(401)
            if current_user.role not in roles:
                abort(403)
            return view_func(*args, **kwargs)
        return wrapped
    return decorator


def backoffice_required(view_func):
    """Admin / quản lý / nhân viên (không gồm khách hàng)."""
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if not current_user.is_authenticated:
            abort(401)
        if not current_user.is_backoffice:
            abort(403)
        return view_func(*args, **kwargs)
    return wrapped
