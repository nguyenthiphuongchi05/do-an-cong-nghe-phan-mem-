import re
import unicodedata
from utils.timeutil import vn_now


def format_vnd(amount):
    """Format số tiền theo kiểu Việt Nam: 25000 -> '25.000đ'"""
    if amount is None:
        return "0đ"
    return f"{amount:,.0f}".replace(",", ".") + "đ"


def slugify(text):
    """Chuyển tên tiếng Việt có dấu thành slug không dấu, dùng cho URL.
    Ví dụ: 'Bánh Tráng Trộn' -> 'banh-trang-tron'
    """
    text = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = text.lower().strip()
    text = re.sub(r"[đĐ]", "d", text)
    text = re.sub(r"[^a-z0-9\s-]", "", text)
    text = re.sub(r"[\s-]+", "-", text)
    return text.strip("-")


def generate_order_code():
    """Sinh mã đơn hàng dạng DH + yyyymmddHHMMSS (giờ Việt Nam), ví dụ DH20260822153045.
    Hai đơn cùng giây sẽ trùng -> khi lưu đơn dùng add_order_with_unique_code() (utils/order_service.py)
    để tự thêm hậu tố, đừng gán trực tiếp mã này."""
    return "DH" + vn_now().strftime("%Y%m%d%H%M%S")


def generate_receipt_code(existing_today):
    """Sinh mã phiếu nhập dạng PN + yyyymmdd + số thứ tự 3 chữ số, ví dụ PN20261015001.
    existing_today: số phiếu đã có trong ngày."""
    return "PN" + vn_now().strftime("%Y%m%d") + f"{existing_today + 1:03d}"


VN_PHONE_REGEX = re.compile(r"^0(3[2-9]|5[2-9]|7[0-9]|8[1-9]|9[0-9])[0-9]{7}$")


def is_valid_vn_phone(phone):
    """Kiểm tra số điện thoại di động VN hợp lệ (10 số, bắt đầu 03/05/07/08/09)."""
    return bool(phone) and bool(VN_PHONE_REGEX.match(phone.strip()))


# Nhãn tiếng Việt + màu badge Bootstrap cho từng trạng thái đơn hàng, dùng chung
# giữa trang khách hàng (lịch sử/chi tiết đơn) và trang quản trị.
ORDER_STATUS_META = {
    "pending": {"label": "Chờ xác nhận", "class": "bg-warning text-dark"},
    "confirmed": {"label": "Đã xác nhận", "class": "bg-info text-dark"},
    "shipping": {"label": "Đang giao", "class": "bg-primary"},
    "completed": {"label": "Hoàn thành", "class": "bg-success"},
    "cancelled": {"label": "Đã hủy", "class": "bg-secondary"},
}


def order_status_label(status):
    return ORDER_STATUS_META.get(status, {}).get("label", status)


def order_status_class(status):
    return ORDER_STATUS_META.get(status, {}).get("class", "bg-secondary")
