"""Cập nhật tồn kho theo chi nhánh bằng câu UPDATE nguyên tử (không kiểu đọc rồi ghi)."""
from sqlalchemy import update as sa_update

from extensions import db
from models.branch import TonKho


def deduct_stock(product_id, branch_id, quantity):
    """Trừ tồn: UPDATE ... SET quantity = quantity - n WHERE quantity >= n.
    Trả về True nếu trừ được, False nếu không đủ hàng (tránh bán vượt tồn khi nhiều người mua cùng lúc)."""
    result = db.session.execute(
        sa_update(TonKho)
        .where(TonKho.product_id == product_id, TonKho.branch_id == branch_id, TonKho.quantity >= quantity)
        .values(quantity=TonKho.quantity - quantity)
    )
    return result.rowcount == 1


def add_stock(product_id, branch_id, quantity):
    """Cộng tồn (hoàn kho, nhập kho). Chưa có dòng tồn của chi nhánh thì tạo mới."""
    result = db.session.execute(
        sa_update(TonKho)
        .where(TonKho.product_id == product_id, TonKho.branch_id == branch_id)
        .values(quantity=TonKho.quantity + quantity)
    )
    if result.rowcount == 0:
        db.session.add(TonKho(product_id=product_id, branch_id=branch_id, quantity=quantity))
