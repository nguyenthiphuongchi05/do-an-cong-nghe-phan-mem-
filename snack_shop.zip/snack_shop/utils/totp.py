"""Mã xác thực một lần theo thời gian (TOTP, RFC 6238) viết bằng thư viện chuẩn - tương thích Google Authenticator,
Microsoft Authenticator, Authy... (SHA-1, 6 chữ số, chu kỳ 30 giây)."""
import base64
import hashlib
import hmac
import secrets
import struct
import time
from urllib.parse import quote

STEP = 30
DIGITS = 6


def generate_secret():
    return base64.b32encode(secrets.token_bytes(20)).decode("ascii").rstrip("=")


def _code_at(secret, counter):
    key = base64.b32decode(secret + "=" * (-len(secret) % 8), casefold=True)
    digest = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    value = (struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF) % (10 ** DIGITS)
    return str(value).zfill(DIGITS)


def totp_now(secret, at=None):
    return _code_at(secret, int((time.time() if at is None else at) // STEP))


def verify(secret, code, at=None, window=1):
    """Chấp nhận mã của khoảng hiện tại và ±window khoảng (lệch đồng hồ ~30 giây)."""
    code = (code or "").strip().replace(" ", "")
    if not secret or not code.isdigit() or len(code) != DIGITS:
        return False
    counter = int((time.time() if at is None else at) // STEP)
    return any(hmac.compare_digest(_code_at(secret, counter + d), code) for d in range(-window, window + 1))


def otpauth_uri(secret, account, issuer="SnackShop"):
    return f"otpauth://totp/{quote(issuer)}:{quote(account)}?secret={secret}&issuer={quote(issuer)}&digits={DIGITS}&period={STEP}"


def pretty(secret):
    return " ".join(secret[i:i + 4] for i in range(0, len(secret), 4))
