
CREATE TABLE categories (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	slug VARCHAR(120) NOT NULL, 
	icon VARCHAR(10), 
	PRIMARY KEY (id), 
	UNIQUE (name), 
	UNIQUE (slug)
);

CREATE TABLE cau_hinh_he_thong (
	"key" VARCHAR(60) NOT NULL, 
	value TEXT NOT NULL, 
	PRIMARY KEY ("key")
);

CREATE TABLE chi_nhanh (
	id INTEGER NOT NULL, 
	code VARCHAR(10) NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	address VARCHAR(255), 
	phone VARCHAR(20), 
	is_active BOOLEAN NOT NULL, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (code)
);

CREATE TABLE suppliers (
	id INTEGER NOT NULL, 
	name VARCHAR(150) NOT NULL, 
	contact_name VARCHAR(120), 
	phone VARCHAR(20), 
	email VARCHAR(120), 
	address VARCHAR(255), 
	note VARCHAR(500), 
	created_at DATETIME, 
	PRIMARY KEY (id)
);

CREATE TABLE products (
	id INTEGER NOT NULL, 
	name VARCHAR(180) NOT NULL, 
	slug VARCHAR(200) NOT NULL, 
	description TEXT, 
	price INTEGER NOT NULL, 
	sale_price INTEGER, 
	cost_price INTEGER, 
	image_filename VARCHAR(255), 
	image_source VARCHAR(10), 
	category_id INTEGER NOT NULL, 
	supplier_id INTEGER, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (slug), 
	FOREIGN KEY(category_id) REFERENCES categories (id), 
	FOREIGN KEY(supplier_id) REFERENCES suppliers (id)
);

CREATE TABLE users (
	id INTEGER NOT NULL, 
	full_name VARCHAR(120) NOT NULL, 
	email VARCHAR(120) NOT NULL, 
	phone VARCHAR(20), 
	address VARCHAR(255), 
	password_hash VARCHAR(255) NOT NULL, 
	role VARCHAR(20) NOT NULL, 
	is_locked BOOLEAN NOT NULL, 
	last_login_at DATETIME, 
	branch_id INTEGER, 
	totp_secret VARCHAR(64), 
	totp_enabled BOOLEAN NOT NULL, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(branch_id) REFERENCES chi_nhanh (id)
);

CREATE INDEX ix_users_branch_id ON users (branch_id);

CREATE UNIQUE INDEX ix_users_email ON users (email);

CREATE INDEX ix_users_role ON users (role);

CREATE TABLE vouchers (
	id INTEGER NOT NULL, 
	code VARCHAR(30) NOT NULL, 
	description VARCHAR(255), 
	discount_type VARCHAR(10) NOT NULL, 
	discount_value INTEGER NOT NULL, 
	max_discount_amount INTEGER, 
	min_order_amount INTEGER NOT NULL, 
	usage_limit INTEGER, 
	used_count INTEGER NOT NULL, 
	expires_at DATETIME, 
	active BOOLEAN NOT NULL, 
	branch_id INTEGER, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (code), 
	FOREIGN KEY(branch_id) REFERENCES chi_nhanh (id)
);

CREATE INDEX ix_vouchers_branch_id ON vouchers (branch_id);

CREATE TABLE cart_items (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	product_id INTEGER NOT NULL, 
	quantity INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_user_product UNIQUE (user_id, product_id), 
	FOREIGN KEY(user_id) REFERENCES users (id), 
	FOREIGN KEY(product_id) REFERENCES products (id)
);

CREATE TABLE chuyen_kho (
	id INTEGER NOT NULL, 
	code VARCHAR(20) NOT NULL, 
	product_id INTEGER NOT NULL, 
	from_branch_id INTEGER NOT NULL, 
	to_branch_id INTEGER NOT NULL, 
	quantity INTEGER NOT NULL, 
	note VARCHAR(255), 
	created_by_id INTEGER, 
	created_at DATETIME, 
	status VARCHAR(20) NOT NULL, 
	handled_by_id INTEGER, 
	handled_at DATETIME, 
	response_note VARCHAR(255), 
	PRIMARY KEY (id), 
	UNIQUE (code), 
	FOREIGN KEY(product_id) REFERENCES products (id), 
	FOREIGN KEY(from_branch_id) REFERENCES chi_nhanh (id), 
	FOREIGN KEY(to_branch_id) REFERENCES chi_nhanh (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(handled_by_id) REFERENCES users (id)
);

CREATE INDEX ix_chuyen_kho_created_at ON chuyen_kho (created_at);

CREATE INDEX ix_chuyen_kho_from_branch_id ON chuyen_kho (from_branch_id);

CREATE INDEX ix_chuyen_kho_product_id ON chuyen_kho (product_id);

CREATE INDEX ix_chuyen_kho_status ON chuyen_kho (status);

CREATE INDEX ix_chuyen_kho_to_branch_id ON chuyen_kho (to_branch_id);

CREATE TABLE nhat_ky_he_thong (
	id INTEGER NOT NULL, 
	user_id INTEGER, 
	user_email VARCHAR(120), 
	user_role VARCHAR(20), 
	category VARCHAR(20) NOT NULL, 
	action VARCHAR(60) NOT NULL, 
	level VARCHAR(10) NOT NULL, 
	description VARCHAR(500) NOT NULL, 
	ip_address VARCHAR(45), 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE SET NULL
);

CREATE INDEX ix_nhat_ky_he_thong_category ON nhat_ky_he_thong (category);

CREATE INDEX ix_nhat_ky_he_thong_created_at ON nhat_ky_he_thong (created_at);

CREATE INDEX ix_nhat_ky_he_thong_level ON nhat_ky_he_thong (level);

CREATE INDEX ix_nhat_ky_he_thong_user_id ON nhat_ky_he_thong (user_id);

CREATE TABLE orders (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	code VARCHAR(20) NOT NULL, 
	receiver_name VARCHAR(120) NOT NULL, 
	receiver_phone VARCHAR(20) NOT NULL, 
	shipping_address VARCHAR(255) NOT NULL, 
	note VARCHAR(255), 
	subtotal_amount INTEGER NOT NULL, 
	discount_amount INTEGER NOT NULL, 
	voucher_codes VARCHAR(255), 
	total_amount INTEGER NOT NULL, 
	status VARCHAR(20) NOT NULL, 
	payment_method VARCHAR(20), 
	bank_code VARCHAR(20), 
	is_paid BOOLEAN NOT NULL, 
	channel VARCHAR(20) NOT NULL, 
	branch_id INTEGER, 
	handled_by_id INTEGER, 
	handled_at DATETIME, 
	completed_at DATETIME, 
	request_type VARCHAR(20), 
	request_reason VARCHAR(255), 
	request_status VARCHAR(20), 
	request_at DATETIME, 
	request_note VARCHAR(255), 
	request_handled_by_id INTEGER, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id), 
	UNIQUE (code), 
	FOREIGN KEY(branch_id) REFERENCES chi_nhanh (id), 
	FOREIGN KEY(handled_by_id) REFERENCES users (id), 
	FOREIGN KEY(request_handled_by_id) REFERENCES users (id)
);

CREATE INDEX ix_orders_branch_id ON orders (branch_id);

CREATE INDEX ix_orders_created_at ON orders (created_at);

CREATE INDEX ix_orders_status ON orders (status);

CREATE TABLE phieu_dieu_chinh (
	id INTEGER NOT NULL, 
	code VARCHAR(20) NOT NULL, 
	branch_id INTEGER NOT NULL, 
	product_id INTEGER NOT NULL, 
	system_qty INTEGER NOT NULL, 
	actual_qty INTEGER NOT NULL, 
	diff INTEGER NOT NULL, 
	reason VARCHAR(20) NOT NULL, 
	note VARCHAR(255), 
	status VARCHAR(20) NOT NULL, 
	created_by_id INTEGER NOT NULL, 
	created_at DATETIME, 
	reviewed_by_id INTEGER, 
	reviewed_at DATETIME, 
	review_note VARCHAR(255), 
	PRIMARY KEY (id), 
	UNIQUE (code), 
	FOREIGN KEY(branch_id) REFERENCES chi_nhanh (id), 
	FOREIGN KEY(product_id) REFERENCES products (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(reviewed_by_id) REFERENCES users (id)
);

CREATE INDEX ix_phieu_dieu_chinh_branch_id ON phieu_dieu_chinh (branch_id);

CREATE INDEX ix_phieu_dieu_chinh_created_at ON phieu_dieu_chinh (created_at);

CREATE INDEX ix_phieu_dieu_chinh_product_id ON phieu_dieu_chinh (product_id);

CREATE INDEX ix_phieu_dieu_chinh_status ON phieu_dieu_chinh (status);

CREATE TABLE phieu_nhap (
	id INTEGER NOT NULL, 
	code VARCHAR(20) NOT NULL, 
	supplier_id INTEGER NOT NULL, 
	created_by_id INTEGER NOT NULL, 
	assigned_to_id INTEGER, 
	received_by_id INTEGER, 
	branch_id INTEGER, 
	status VARCHAR(20) NOT NULL, 
	note VARCHAR(500), 
	total_amount INTEGER NOT NULL, 
	created_at DATETIME, 
	received_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (code), 
	FOREIGN KEY(supplier_id) REFERENCES suppliers (id), 
	FOREIGN KEY(created_by_id) REFERENCES users (id), 
	FOREIGN KEY(assigned_to_id) REFERENCES users (id), 
	FOREIGN KEY(received_by_id) REFERENCES users (id), 
	FOREIGN KEY(branch_id) REFERENCES chi_nhanh (id)
);

CREATE INDEX ix_phieu_nhap_branch_id ON phieu_nhap (branch_id);

CREATE TABLE reviews (
	id INTEGER NOT NULL, 
	product_id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	rating INTEGER NOT NULL, 
	comment TEXT, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_product_user_review UNIQUE (product_id, user_id), 
	FOREIGN KEY(product_id) REFERENCES products (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
);

CREATE TABLE saved_vouchers (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	voucher_id INTEGER NOT NULL, 
	saved_at DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_user_voucher UNIQUE (user_id, voucher_id), 
	FOREIGN KEY(user_id) REFERENCES users (id), 
	FOREIGN KEY(voucher_id) REFERENCES vouchers (id)
);

CREATE TABLE ton_kho (
	id INTEGER NOT NULL, 
	product_id INTEGER NOT NULL, 
	branch_id INTEGER NOT NULL, 
	quantity INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_ton_kho_product_branch UNIQUE (product_id, branch_id), 
	FOREIGN KEY(product_id) REFERENCES products (id), 
	FOREIGN KEY(branch_id) REFERENCES chi_nhanh (id)
);

CREATE INDEX ix_ton_kho_branch_id ON ton_kho (branch_id);

CREATE INDEX ix_ton_kho_product_id ON ton_kho (product_id);

CREATE TABLE wishlists (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	product_id INTEGER NOT NULL, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_user_product_wishlist UNIQUE (user_id, product_id), 
	FOREIGN KEY(user_id) REFERENCES users (id), 
	FOREIGN KEY(product_id) REFERENCES products (id)
);

CREATE TABLE chi_tiet_phieu_nhap (
	id INTEGER NOT NULL, 
	receipt_id INTEGER NOT NULL, 
	product_id INTEGER NOT NULL, 
	quantity INTEGER NOT NULL, 
	received_quantity INTEGER, 
	import_price INTEGER NOT NULL, 
	expiry_date DATE, 
	PRIMARY KEY (id), 
	FOREIGN KEY(receipt_id) REFERENCES phieu_nhap (id), 
	FOREIGN KEY(product_id) REFERENCES products (id)
);

CREATE TABLE order_items (
	id INTEGER NOT NULL, 
	order_id INTEGER NOT NULL, 
	product_id INTEGER NOT NULL, 
	product_name VARCHAR(180) NOT NULL, 
	price INTEGER NOT NULL, 
	quantity INTEGER NOT NULL, 
	cost_price INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(order_id) REFERENCES orders (id), 
	FOREIGN KEY(product_id) REFERENCES products (id)
);

CREATE TABLE order_vouchers (
	id INTEGER NOT NULL, 
	order_id INTEGER NOT NULL, 
	voucher_code VARCHAR(30) NOT NULL, 
	discount_amount INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(order_id) REFERENCES orders (id)
);
