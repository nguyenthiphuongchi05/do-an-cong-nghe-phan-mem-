"""Phiếu điều chỉnh kho có duyệt.

- Nhân viên / quản lý chi nhánh lập phiếu cho chi nhánh của mình (sản phẩm, số đếm thực tế, lý do).
- Phiếu của nhân viên do QUẢN LÝ CHI NHÁNH duyệt; phiếu của quản lý chi nhánh do QUẢN LÝ CHUỖI duyệt.
  Không ai tự duyệt phiếu của chính mình.
- Tồn kho chỉ đổi khi duyệt: áp dụng phần chênh lệch (thực tế - tồn lúc lập) vào tồn hiện tại, bằng câu UPDATE nguyên tử.
  Mỗi phiếu chỉ xử lý một lần (cập nhật có điều kiện status = 'pending').
"""
from datetime import datetime

from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from sqlalchemy import update as sa_update

from extensions import db
from models import ChiNhanh, PhieuDieuChinh, Product
from models.branch import ADJUST_REASONS
from models.user import ROLE_STAFF, ROLE_MANAGER
from utils.audit import log_event
from utils.branch import current_branch_id
from utils.decorators import permission_required
from utils.inventory import add_stock, deduct_stock

adjust_bp = Blueprint("adjust", __name__)


def can_review(ticket):
    """Người dùng hiện tại có quyền duyệt / từ chối phiếu này không (kiểm tra ở server, không chỉ ẩn nút)."""
    if not current_user.has_permission("stock.adjust.approve") or ticket.status != "pending":
        return False
    if ticket.created_by_id == current_user.id:
        return False  # không tự duyệt phiếu của mình
    creator_role = ticket.created_by.role if ticket.created_by else None
    if current_user.is_chain_manager:
        return True  # quản lý chuỗi duyệt mọi phiếu (đặc biệt là phiếu của quản lý chi nhánh)
    # quản lý chi nhánh: chỉ phiếu của NHÂN VIÊN thuộc chi nhánh mình
    return (current_user.role == ROLE_MANAGER and current_user.branch_id == ticket.branch_id
            and creator_role == ROLE_STAFF)


@adjust_bp.route("/admin/dieu-chinh-kho")
@login_required
@permission_required("stock.adjust", "stock.adjust.approve")
def adjustments():
    q = PhieuDieuChinh.query
    bid = current_branch_id()
    if bid:
        q = q.filter(PhieuDieuChinh.branch_id == bid)
    status = request.args.get("status", "")
    if status in PhieuDieuChinh.STATUS_LABELS:
        q = q.filter(PhieuDieuChinh.status == status)
    rows = q.order_by(PhieuDieuChinh.created_at.desc(), PhieuDieuChinh.id.desc()).limit(200).all()
    return render_template("admin/adjustments.html", rows=rows, status=status, can_review=can_review,
                           can_create=current_user.has_permission("stock.adjust"))


@adjust_bp.route("/admin/dieu-chinh-kho/tao", methods=["GET", "POST"])
@login_required
@permission_required("stock.adjust")
def create_adjustment():
    branch_id = current_user.branch_id
    if not branch_id:
        abort(403)  # chỉ nhân sự thuộc một chi nhánh mới lập phiếu cho chi nhánh đó
    branch = db.session.get(ChiNhanh, branch_id)
    products = Product.query.order_by(Product.name).all()

    def page():
        return render_template("admin/adjustment-form.html", branch=branch, products=products,
                               reasons=ADJUST_REASONS, stock_of=lambda p: p.stock_at(branch_id))

    if request.method == "POST":
        try:
            product_id = int(request.form.get("product_id", ""))
            actual = int(request.form.get("actual_qty", ""))
        except ValueError:
            flash("Dữ liệu không hợp lệ.", "danger")
            return page()
        product = db.session.get(Product, product_id)
        reason = request.form.get("reason", "")
        note = (request.form.get("note") or "").strip()[:255]
        if not product or reason not in ADJUST_REASONS or actual < 0:
            flash("Sản phẩm, số lượng thực tế hoặc lý do không hợp lệ.", "danger")
            return page()
        if reason == "other" and not note:
            flash("Chọn lý do khác thì phải ghi rõ ở ô ghi chú.", "danger")
            return page()
        system_qty = product.stock_at(branch_id)
        diff = actual - system_qty
        if diff == 0:
            flash("Số thực tế bằng tồn trên hệ thống, không cần điều chỉnh.", "warning")
            return page()
        today = datetime.utcnow().strftime("%Y%m%d")
        count = PhieuDieuChinh.query.filter(PhieuDieuChinh.code.like(f"DC{today}-%")).count()
        t = PhieuDieuChinh(code=f"DC{today}-{count + 1:03d}", branch_id=branch_id, product_id=product.id,
                           system_qty=system_qty, actual_qty=actual, diff=diff, reason=reason, note=note or None,
                           created_by_id=current_user.id, status="pending")
        db.session.add(t)
        db.session.commit()
        log_event("stock_adjust_create",
                  f"Lập phiếu điều chỉnh {t.code}: {product.name} {system_qty} → {actual} ({diff:+d}) tại {branch.code}",
                  category="inventory")
        who = "quản lý chuỗi" if current_user.is_manager else "quản lý chi nhánh"
        flash(f"Đã lập phiếu {t.code}. Tồn kho chỉ thay đổi sau khi {who} duyệt.", "success")
        return redirect(url_for("adjust.adjustments"))
    return page()


def _load(ticket_id):
    t = db.session.get(PhieuDieuChinh, ticket_id)
    if not t:
        abort(404)
    bid = current_branch_id()
    if bid and t.branch_id != bid:
        abort(404)
    return t


def _claim(ticket, status, note):
    res = db.session.execute(
        sa_update(PhieuDieuChinh).where(PhieuDieuChinh.id == ticket.id, PhieuDieuChinh.status == "pending")
        .values(status=status, reviewed_by_id=current_user.id, reviewed_at=datetime.utcnow(), review_note=note or None))
    return res.rowcount == 1


@adjust_bp.route("/admin/dieu-chinh-kho/<int:ticket_id>/duyet", methods=["POST"])
@login_required
@permission_required("stock.adjust.approve")
def approve_adjustment(ticket_id):
    t = _load(ticket_id)
    if not can_review(t):
        abort(403)
    if not _claim(t, "approved", (request.form.get("note") or "").strip()[:255]):
        db.session.rollback()
        flash("Phiếu này đã được xử lý rồi.", "warning")
        return redirect(url_for("adjust.adjustments"))
    if t.diff > 0:
        add_stock(t.product_id, t.branch_id, t.diff)
    elif not deduct_stock(t.product_id, t.branch_id, -t.diff):
        db.session.rollback()  # hoàn tác cả việc đánh dấu "đã duyệt"
        flash("Tồn hiện tại thấp hơn số cần trừ (đã có hàng bán ra từ lúc lập phiếu). Hãy từ chối phiếu và lập lại phiếu mới.", "danger")
        return redirect(url_for("adjust.adjustments"))
    db.session.commit()
    log_event("stock_adjust_approve", f"Duyệt phiếu {t.code}: {t.product.name} {t.diff:+d} tại {t.branch.code}",
              category="inventory", level="warning")
    flash(f"Đã duyệt phiếu {t.code}, tồn kho đã được điều chỉnh {t.diff:+d}.", "success")
    return redirect(url_for("adjust.adjustments"))


@adjust_bp.route("/admin/dieu-chinh-kho/<int:ticket_id>/tu-choi", methods=["POST"])
@login_required
@permission_required("stock.adjust.approve")
def reject_adjustment(ticket_id):
    t = _load(ticket_id)
    if not can_review(t):
        abort(403)
    note = (request.form.get("note") or "").strip()[:255]
    if not note:
        flash("Từ chối phiếu cần ghi lý do.", "danger")
    elif not _claim(t, "rejected", note):
        db.session.rollback()
        flash("Phiếu này đã được xử lý rồi.", "warning")
    else:
        db.session.commit()
        log_event("stock_adjust_reject", f"Từ chối phiếu {t.code}: {note}", category="inventory")
        flash(f"Đã từ chối phiếu {t.code}.", "info")
    return redirect(url_for("adjust.adjustments"))
