"""Quản lý nhân sự trong phạm vi quyền của người thao tác (khác với /admin/he-thong/tai-khoan là của Admin).

- Quản lý chi nhánh: chỉ tạo / sửa / khóa / đặt lại mật khẩu NHÂN VIÊN thuộc chi nhánh của mình.
- Quản lý chuỗi: tạo / quản lý QUẢN LÝ CHI NHÁNH và NHÂN VIÊN ở mọi chi nhánh.
- Không ai được tạo hoặc sửa Admin, Quản lý chuỗi, khách hàng, hay chính tài khoản của mình (đổi quyền, tự khóa).
Mọi giới hạn được kiểm tra ở server: vai trò và chi nhánh gửi lên từ form luôn bị đối chiếu lại, không tin giao diện.
"""
import secrets
import string

from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user

from extensions import db
from forms.team_form import TeamForm
from models import User, ChiNhanh
from models.user import ROLE_MANAGER, ROLE_STAFF, ROLE_LABELS
from utils.audit import log_event
from utils.decorators import permission_required
from utils.password_policy import password_error

team_bp = Blueprint("team", __name__, url_prefix="/admin/nhan-su")


def allowed_roles(actor):
    """Vai trò actor được phép tạo / quản lý."""
    if actor.has_permission("staff.manage.chain"):
        return [ROLE_MANAGER, ROLE_STAFF]
    if actor.role == ROLE_MANAGER and actor.branch_id:
        return [ROLE_STAFF]
    return []


def allowed_branch_ids(actor):
    if actor.has_permission("staff.manage.chain"):
        return [b.id for b in ChiNhanh.query.filter_by(is_active=True).all()]
    return [actor.branch_id] if actor.branch_id else []


def manageable(actor, target):
    """actor có được xem / sửa / khóa / đặt lại mật khẩu của target không."""
    if target.id == actor.id or target.role not in allowed_roles(actor):
        return False
    return actor.has_permission("staff.manage.chain") or target.branch_id == actor.branch_id


def _random_password(length=12):
    alphabet = string.ascii_letters + string.digits
    while True:
        pw = "".join(secrets.choice(alphabet) for _ in range(length))
        if password_error(pw) is None and any(c.isupper() for c in pw) and any(c.islower() for c in pw):
            return pw


def _target_or_404(user_id):
    u = db.session.get(User, user_id)
    if not u:
        abort(404)
    if not manageable(current_user, u):
        abort(403)
    return u


def _fill_choices(form, creating):
    roles = allowed_roles(current_user)
    if "role" in form:
        form.role.choices = [(r, ROLE_LABELS[r]) for r in roles]
    form.branch_id.choices = [(b.id, f"{b.code} - {b.name}") for b in ChiNhanh.query.filter(
        ChiNhanh.id.in_(allowed_branch_ids(current_user))).order_by(ChiNhanh.id).all()]


@team_bp.route("/")
@login_required
@permission_required("staff.manage")
def members():
    roles = allowed_roles(current_user)
    if not roles:
        abort(403)
    q = User.query.filter(User.role.in_(roles), User.id != current_user.id)
    if not current_user.has_permission("staff.manage.chain"):
        q = q.filter(User.branch_id == current_user.branch_id)
    elif request.args.get("branch", "").isdigit():
        q = q.filter(User.branch_id == int(request.args["branch"]))
    users = q.order_by(User.branch_id, User.role, User.full_name).all()
    return render_template("admin/team.html", users=users, chain=current_user.has_permission("staff.manage.chain"),
                           all_branches=ChiNhanh.query.order_by(ChiNhanh.id).all(),
                           branch_filter=request.args.get("branch", ""))


@team_bp.route("/them", methods=["GET", "POST"])
@login_required
@permission_required("staff.manage")
def add_member():
    if not allowed_roles(current_user):
        abort(403)
    form = TeamForm()
    _fill_choices(form, True)
    if form.validate_on_submit():
        # đối chiếu lại với quyền thật, bỏ qua mọi giá trị giả mạo từ form
        role = form.role.data
        branch_id = form.branch_id.data if current_user.has_permission("staff.manage.chain") else current_user.branch_id
        email = form.email.data.strip().lower()
        if role not in allowed_roles(current_user):
            abort(403)
        if branch_id not in allowed_branch_ids(current_user):
            abort(403)
        if User.query.filter(db.func.lower(User.email) == email).first():
            flash("Email này đã được sử dụng.", "danger")
        else:
            password = form.password.data or _random_password()
            user = User(full_name=form.full_name.data.strip(), email=email, phone=form.phone.data or None,
                        role=role, branch_id=branch_id)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            log_event("team_create", f"Tạo tài khoản {user.email} ({user.role_label}) tại chi nhánh {user.branch.code}",
                      category="account")
            msg = f"Đã tạo tài khoản {user.email}."
            if not form.password.data:
                msg += f" Mật khẩu tạm: {password} (chỉ hiển thị một lần, hãy gửi cho người dùng và nhắc đổi mật khẩu)."
            flash(msg, "success")
            return redirect(url_for("team.members"))
    if request.method == "GET" and not current_user.has_permission("staff.manage.chain"):
        form.branch_id.data = current_user.branch_id
    return render_template("admin/team-form.html", form=form, mode="add",
                           chain=current_user.has_permission("staff.manage.chain"))


@team_bp.route("/<int:user_id>/sua", methods=["GET", "POST"])
@login_required
@permission_required("staff.manage")
def edit_member(user_id):
    user = _target_or_404(user_id)
    form = TeamForm(obj=user)
    del form.email, form.role  # không cho sửa email / vai trò: bỏ hẳn khỏi form (giao diện chỉ hiển thị, không gửi lên)
    _fill_choices(form, False)
    chain = current_user.has_permission("staff.manage.chain")
    if request.method == "GET":
        form.branch_id.data = user.branch_id
    if form.validate_on_submit():
        # chỉ đổi tên, số điện thoại và (với quản lý chuỗi) chi nhánh; KHÔNG đổi vai trò / email / quyền
        user.full_name = form.full_name.data.strip()
        user.phone = form.phone.data or None
        if chain and form.branch_id.data in allowed_branch_ids(current_user):
            user.branch_id = form.branch_id.data
        if form.password.data:
            user.set_password(form.password.data)
        db.session.commit()
        log_event("team_update", f"Cập nhật tài khoản {user.email}", category="account")
        flash("Đã cập nhật tài khoản.", "success")
        return redirect(url_for("team.members"))
    return render_template("admin/team-form.html", form=form, mode="edit", user=user, chain=chain)


@team_bp.route("/<int:user_id>/khoa", methods=["POST"])
@login_required
@permission_required("staff.manage")
def toggle_lock(user_id):
    user = _target_or_404(user_id)
    user.is_locked = not user.is_locked
    db.session.commit()
    log_event("team_lock" if user.is_locked else "team_unlock",
              f"{'Khóa' if user.is_locked else 'Mở khóa'} tài khoản {user.email}", category="account", level="warning")
    flash(f"Đã {'khóa' if user.is_locked else 'mở khóa'} tài khoản {user.email}.", "success")
    return redirect(url_for("team.members"))


@team_bp.route("/<int:user_id>/dat-lai-mat-khau", methods=["POST"])
@login_required
@permission_required("staff.manage")
def reset_member_password(user_id):
    user = _target_or_404(user_id)
    password = (request.form.get("new_password") or "").strip()
    err = password_error(password, user.email) if password else None
    if err:
        flash(err, "danger")
        return redirect(url_for("team.members"))
    password = password or _random_password()
    user.set_password(password)
    db.session.commit()
    log_event("team_password_reset", f"Đặt lại mật khẩu tài khoản {user.email}", category="account", level="warning")
    flash(f"Đã đặt lại mật khẩu cho {user.email}. Mật khẩu mới: {password} (chỉ hiển thị một lần).", "success")
    return redirect(url_for("team.members"))
