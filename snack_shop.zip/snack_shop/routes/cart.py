from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from sqlalchemy import func

from extensions import db
from models import Product, CartItem

cart_bp = Blueprint("cart", __name__, url_prefix="/gio-hang")


def _wants_json():
    return request.headers.get("X-Requested-With") == "XMLHttpRequest"


def _cart_count(user_id):
    return db.session.query(func.sum(CartItem.quantity)).filter_by(user_id=user_id).scalar() or 0


@cart_bp.route("/")
@login_required
def view_cart():
    items = CartItem.query.filter_by(user_id=current_user.id).all()
    total = sum(item.subtotal for item in items)
    return render_template("cart/cart.html", items=items, total=total)


@cart_bp.route("/them/<int:product_id>", methods=["POST"])
@login_required
def add_to_cart(product_id):
    product = Product.query.get_or_404(product_id)
    quantity = request.form.get("quantity", 1, type=int) or 1

    if product.stock < quantity:
        message = f"Chỉ còn {product.stock} sản phẩm '{product.name}' trong kho."
        if _wants_json():
            return jsonify(ok=False, message=message, cart_count=_cart_count(current_user.id)), 400
        flash(message, "warning")
        return redirect(request.referrer or url_for("product.list_products"))

    item = CartItem.query.filter_by(user_id=current_user.id, product_id=product.id).first()
    if item:
        item.quantity += quantity
    else:
        item = CartItem(user_id=current_user.id, product_id=product.id, quantity=quantity)
        db.session.add(item)

    db.session.commit()
    message = f"Đã thêm '{product.name}' vào giỏ hàng."

    if _wants_json():
        return jsonify(ok=True, message=message, cart_count=_cart_count(current_user.id))

    flash(message, "success")
    return redirect(request.referrer or url_for("cart.view_cart"))


@cart_bp.route("/cap-nhat/<int:item_id>", methods=["POST"])
@login_required
def update_quantity(item_id):
    item = CartItem.query.filter_by(id=item_id, user_id=current_user.id).first_or_404()
    quantity = request.form.get("quantity", 1, type=int)

    if quantity <= 0:
        db.session.delete(item)
    else:
        item.quantity = quantity

    db.session.commit()
    return redirect(url_for("cart.view_cart"))


@cart_bp.route("/xoa/<int:item_id>", methods=["POST"])
@login_required
def remove_item(item_id):
    item = CartItem.query.filter_by(id=item_id, user_id=current_user.id).first_or_404()
    db.session.delete(item)
    db.session.commit()
    flash("Đã xóa sản phẩm khỏi giỏ hàng.", "info")
    return redirect(url_for("cart.view_cart"))
