"""Chi nhánh: chọn chi nhánh đang xem (khách, admin, quản lý chưa gán chi nhánh) và quản lý danh sách chi nhánh (Admin)."""
from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from flask_login import login_required, current_user
from sqlalchemy import func

from extensions import db
from models import ChiNhanh, TonKho, User, Order, PhieuNhap
from forms.branch_form import BranchForm
from utils.audit import log_event
from utils.branch import SESSION_KEY
from utils.decorators import permission_required

branch_bp = Blueprint("branch", __name__)


def _safe_back():
    ref = request.referrer or ""
    # chỉ quay lại trang cùng máy chủ, tránh chuyển hướng ra ngoài
    if ref.startswith(request.host_url):
        return ref
    return url_for("home.index")


@branch_bp.route("/chi-nhanh/chon", methods=["POST"])
def select_branch():
    """Chọn chi nhánh đang xem. branch_id = 0 nghĩa là tất cả chi nhánh (chỉ nhân sự nội bộ chưa gán chi nhánh)."""
    raw = request.form.get("branch_id", "")
    backoffice_free = current_user.is_authenticated and current_user.is_backoffice and not current_user.branch_id
    if current_user.is_authenticated and current_user.is_backoffice and current_user.branch_id:
        flash("Bạn được gán cố định vào một chi nhánh nên không đổi được.", "warning")
        return redirect(_safe_back())
    if raw == "0" and backoffice_free:
        session.pop(SESSION_KEY, None)
        flash("Đang xem tất cả chi nhánh.", "info")
        return redirect(_safe_back())
    branch = db.session.get(ChiNhanh, int(raw)) if raw.isdigit() else None
    if not branch or not (branch.is_active or backoffice_free):
        flash("Chi nhánh không hợp lệ.", "danger")
        return redirect(_safe_back())
    session[SESSION_KEY] = branch.id
    flash(f"Đã chọn {branch.name}.", "success")
    return redirect(_safe_back())


# ---------------- Quản lý chi nhánh (Admin) ----------------

@branch_bp.route("/admin/chi-nhanh")
@login_required
@permission_required("branch.manage")
def branches():
    rows = []
    for b in ChiNhanh.query.order_by(ChiNhanh.id).all():
        rows.append({
            "b": b,
            "users": User.query.filter(User.branch_id == b.id).count(),
            "orders": db.session.query(func.count(Order.id)).filter(Order.branch_id == b.id).scalar(),
            "receipts": db.session.query(func.count(PhieuNhap.id)).filter(PhieuNhap.branch_id == b.id).scalar(),
            "units": db.session.query(func.coalesce(func.sum(TonKho.quantity), 0)).filter(TonKho.branch_id == b.id).scalar(),
        })
    return render_template("admin/branches.html", rows=rows)


def _form_page(form, mode, branch=None):
    return render_template("admin/branch-form.html", form=form, mode=mode, branch=branch)


@branch_bp.route("/admin/chi-nhanh/them", methods=["GET", "POST"])
@login_required
@permission_required("branch.manage")
def add_branch():
    form = BranchForm()
    if form.validate_on_submit():
        code = form.code.data.strip().upper()
        if ChiNhanh.query.filter(ChiNhanh.code == code).first():
            flash("Mã chi nhánh đã tồn tại.", "danger")
            return _form_page(form, "add")
        b = ChiNhanh(code=code, name=form.name.data.strip(), address=form.address.data or None,
                     phone=form.phone.data or None, is_active=form.is_active.data)
        db.session.add(b)
        db.session.commit()
        log_event("branch_create", f"Thêm chi nhánh {b.code} - {b.name}", category="system")
        flash("Đã thêm chi nhánh. Tồn kho chi nhánh mới bắt đầu từ 0, hãy lập phiếu nhập hàng cho chi nhánh này.", "success")
        return redirect(url_for("branch.branches"))
    if request.method == "GET":
        form.is_active.data = True
    return _form_page(form, "add")


@branch_bp.route("/admin/chi-nhanh/<int:branch_id>/sua", methods=["GET", "POST"])
@login_required
@permission_required("branch.manage")
def edit_branch(branch_id):
    b = db.session.get(ChiNhanh, branch_id) or ChiNhanh.query.get_or_404(branch_id)
    form = BranchForm(obj=b)
    if form.validate_on_submit():
        code = form.code.data.strip().upper()
        if ChiNhanh.query.filter(ChiNhanh.code == code, ChiNhanh.id != b.id).first():
            flash("Mã chi nhánh đã được dùng.", "danger")
            return _form_page(form, "edit", b)
        if not form.is_active.data and b.is_active and ChiNhanh.query.filter_by(is_active=True).count() <= 1:
            flash("Hệ thống phải còn ít nhất một chi nhánh đang hoạt động.", "danger")
            return _form_page(form, "edit", b)
        b.code, b.name = code, form.name.data.strip()
        b.address, b.phone = form.address.data or None, form.phone.data or None
        b.is_active = form.is_active.data
        db.session.commit()
        log_event("branch_update", f"Cập nhật chi nhánh {b.code} - {b.name}", category="system")
        flash("Đã cập nhật chi nhánh.", "success")
        return redirect(url_for("branch.branches"))
    return _form_page(form, "edit", b)
