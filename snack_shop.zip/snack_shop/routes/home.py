from flask import Blueprint, render_template
from models import Product, Category, Voucher, SavedVoucher, Wishlist
from routes.voucher import _get_used_codes
from flask_login import current_user
from utils.branch import current_branch_id

home_bp = Blueprint("home", __name__)


@home_bp.route("/")
def index():
    featured_products = Product.query.order_by(Product.created_at.desc()).limit(24).all()
    categories = Category.query.all()
    candidate_vouchers = Voucher.for_branch(Voucher.query.filter_by(active=True), current_branch_id()).order_by(Voucher.created_at.desc()).limit(10).all()
    vouchers = [v for v in candidate_vouchers if not v.is_expired and not v.is_used_up][:3]

    saved_ids = set()
    used_codes = set()
    wishlist_ids = set()
    if current_user.is_authenticated:
        saved_ids = {
            sv.voucher_id
            for sv in SavedVoucher.query.filter_by(user_id=current_user.id).all()
        }
        used_codes = _get_used_codes(current_user.id)
        wishlist_ids = {w.product_id for w in Wishlist.query.filter_by(user_id=current_user.id).all()}

    return render_template(
        "index.html",
        products=featured_products,
        categories=categories,
        vouchers=vouchers,
        saved_ids=saved_ids,
        used_codes=used_codes,
        wishlist_ids=wishlist_ids,
    )
