from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user

from extensions import db
from utils.branch import current_branch_id
from models import Voucher, SavedVoucher, Order, OrderVoucher

voucher_bp = Blueprint("voucher", __name__, url_prefix="/voucher")


def _get_used_codes(user_id):
    return {
        code for (code,) in db.session.query(OrderVoucher.voucher_code)
        .join(Order, Order.id == OrderVoucher.order_id)
        .filter(Order.user_id == user_id)
        .all()
    }


@voucher_bp.route("/")
def list_vouchers():
    all_active = Voucher.for_branch(Voucher.query.filter_by(active=True), current_branch_id()).order_by(Voucher.created_at.desc()).all()
    vouchers = [v for v in all_active if not v.is_expired and not v.is_used_up]
    saved_ids = set()
    used_codes = set()
    if current_user.is_authenticated:
        saved_ids = {
            sv.voucher_id
            for sv in SavedVoucher.query.filter_by(user_id=current_user.id).all()
        }
        used_codes = _get_used_codes(current_user.id)
    return render_template("voucher/list.html", vouchers=vouchers, saved_ids=saved_ids, used_codes=used_codes)


@voucher_bp.route("/luu/<int:voucher_id>", methods=["POST"])
@login_required
def save_voucher(voucher_id):
    voucher = Voucher.query.get_or_404(voucher_id)

    if not voucher.is_valid_now or not voucher.applies_to_branch(current_branch_id()):
        flash("Voucher này hiện không còn khả dụng.", "warning")
        return redirect(url_for("voucher.list_vouchers"))

    existing = SavedVoucher.query.filter_by(user_id=current_user.id, voucher_id=voucher.id).first()
    if existing:
        flash("Bạn đã lưu mã này rồi.", "info")
    else:
        db.session.add(SavedVoucher(user_id=current_user.id, voucher_id=voucher.id))
        db.session.commit()
        flash(f"Đã lưu mã {voucher.code} vào ví voucher của bạn.", "success")

    return redirect(url_for("voucher.list_vouchers"))


@voucher_bp.route("/cua-toi")
@login_required
def my_vouchers():
    saved = (
        SavedVoucher.query.filter_by(user_id=current_user.id)
        .join(Voucher)
        .order_by(SavedVoucher.saved_at.desc())
        .all()
    )
    used_codes = _get_used_codes(current_user.id)
    return render_template("voucher/my_vouchers.html", saved_vouchers=saved, used_codes=used_codes)
