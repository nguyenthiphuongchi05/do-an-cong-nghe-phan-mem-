"""Khu vực Admin: tài khoản & phân quyền, cấu hình hệ thống, sao lưu/khôi phục, nhật ký, bảo trì.
Admin KHÔNG xử lý nghiệp vụ bán hàng hằng ngày (sản phẩm, đơn hàng, nhập hàng...)."""
import os
import secrets
import string
from datetime import datetime, timedelta

from flask import Blueprint, render_template, redirect, url_for, flash, request, send_file, current_app
from flask_login import login_required, current_user
from sqlalchemy import or_, text

from extensions import db
from utils.password_policy import password_error
from models import User, NhatKyHeThong, Product, Order, PhieuNhap, ChiNhanh
from models.setting import get_all_settings, set_setting
from models.system_log import LOG_CATEGORIES, LOG_LEVELS
from models.user import ROLES, ROLE_ADMIN, BRANCH_ROLES, WALKIN_EMAIL
from forms.system_form import UserForm, SettingsForm
from utils.decorators import permission_required
from utils.audit import log_event
from utils.permissions import permission_matrix
from utils.upload import save_logo_image, delete_logo_image
from utils import backup as backup_util

system_bp = Blueprint("system", __name__, url_prefix="/admin/he-thong")


def _active_admin_count(exclude_id=None):
    q = User.query.filter_by(role=ROLE_ADMIN, is_locked=False)
    if exclude_id:
        q = q.filter(User.id != exclude_id)
    return q.count()


def _branch_choices(form):
    form.branch_id.choices = [(0, "-- Chọn chi nhánh --")] + [
        (b.id, f"{b.code} - {b.name}") for b in ChiNhanh.query.order_by(ChiNhanh.id).all()]


def _branch_for(form, role=None):
    """Chỉ quản lý chi nhánh / nhân viên mới có chi nhánh; admin, quản lý chuỗi và khách hàng luôn để trống."""
    role = role or form.role.data
    if role not in BRANCH_ROLES or not form.branch_id.data:
        return None
    return form.branch_id.data if db.session.get(ChiNhanh, form.branch_id.data) else None


def _branch_missing(form, role=None):
    """Quản lý chi nhánh và nhân viên bắt buộc phải thuộc một chi nhánh còn tồn tại."""
    role = role or form.role.data
    if role in BRANCH_ROLES and _branch_for(form, role) is None:
        flash("Quản lý chi nhánh và nhân viên phải được gán vào một chi nhánh.", "danger")
        return True
    return False


def _random_password(length=12):
    """Mật khẩu tạm ngẫu nhiên, luôn có cả chữ hoa, chữ thường và số."""
    alphabet = string.ascii_letters + string.digits
    while True:
        pw = "".join(secrets.choice(alphabet) for _ in range(length))
        if password_error(pw) is None and any(c.isupper() for c in pw) and any(c.islower() for c in pw):
            return pw


# ======================================================================
# Tài khoản & phân quyền
# ======================================================================

@system_bp.route("/tai-khoan")
@login_required
@permission_required("account.manage")
def users():
    role = request.args.get("role", "")
    q = request.args.get("q", "").strip()
    query = User.query.filter(User.email != WALKIN_EMAIL)
    if role in ROLES:
        query = query.filter(User.role == role)
    if q:
        like = f"%{q}%"
        query = query.filter(or_(User.full_name.ilike(like), User.email.ilike(like), User.phone.ilike(like)))
    return render_template("system/users.html", users=query.order_by(User.role, User.created_at.desc()).limit(300).all(),
                           role=role, q=q, matrix=permission_matrix())


@system_bp.route("/tai-khoan/tao", methods=["GET", "POST"])
@login_required
@permission_required("account.manage")
def create_user():
    form = UserForm()
    _branch_choices(form)
    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        if User.query.filter(db.func.lower(User.email) == email).first():
            flash("Email này đã được sử dụng.", "danger")
        elif _branch_missing(form):
            pass
        else:
            password = form.password.data or _random_password()
            user = User(full_name=form.full_name.data.strip(), email=email,
                        phone=form.phone.data or None, role=form.role.data,
                        branch_id=_branch_for(form))
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            log_event("account_create", f"Tạo tài khoản {user.email} ({user.role_label})", category="account")
            msg = f"Đã tạo tài khoản {user.email}."
            if not form.password.data:
                msg += f" Mật khẩu tạm: {password} (chỉ hiển thị một lần, hãy gửi cho người dùng)."
            flash(msg, "success")
            return redirect(url_for("system.users"))
    return render_template("system/user-form.html", form=form, mode="add")


@system_bp.route("/tai-khoan/<int:user_id>/sua", methods=["GET", "POST"])
@login_required
@permission_required("account.manage")
def edit_user(user_id):
    user = User.query.get_or_404(user_id)
    form = UserForm(obj=user)
    _branch_choices(form)
    if request.method == "GET":
        form.branch_id.data = user.branch_id or 0
    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        clash = User.query.filter(db.func.lower(User.email) == email, User.id != user.id).first()
        new_role = form.role.data
        if clash:
            flash("Email này đã được dùng bởi tài khoản khác.", "danger")
        elif _branch_missing(form, new_role):
            pass
        elif new_role != user.role and not current_user.has_permission("role.assign"):
            flash("Bạn không có quyền đổi vai trò.", "danger")
        elif new_role != user.role and user.id == current_user.id:
            flash("Không thể tự đổi vai trò của chính mình.", "danger")
        elif new_role != user.role and user.role == ROLE_ADMIN and _active_admin_count(exclude_id=user.id) == 0:
            flash("Hệ thống phải còn ít nhất một admin đang hoạt động.", "danger")
        else:
            old_role = user.role_label
            role_changed = new_role != user.role
            user.full_name = form.full_name.data.strip()
            user.email = email
            user.phone = form.phone.data or None
            user.role = new_role
            user.branch_id = _branch_for(form, new_role)
            if form.password.data:
                user.set_password(form.password.data)
            db.session.commit()
            if role_changed:
                log_event("role_change", f"Đổi vai trò {user.email}: {old_role} → {user.role_label}",
                          category="account", level="warning")
            log_event("account_update", f"Cập nhật tài khoản {user.email}", category="account")
            flash("Đã cập nhật tài khoản.", "success")
            return redirect(url_for("system.users"))
    return render_template("system/user-form.html", form=form, mode="edit", user=user)


@system_bp.route("/tai-khoan/<int:user_id>/khoa", methods=["POST"])
@login_required
@permission_required("account.manage")
def toggle_lock(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("Không thể tự khóa tài khoản của chính mình.", "danger")
    elif not user.is_locked and user.role == ROLE_ADMIN and _active_admin_count(exclude_id=user.id) == 0:
        flash("Hệ thống phải còn ít nhất một admin đang hoạt động.", "danger")
    else:
        user.is_locked = not user.is_locked
        db.session.commit()
        log_event("account_lock" if user.is_locked else "account_unlock",
                  f"{'Khóa' if user.is_locked else 'Mở khóa'} tài khoản {user.email}",
                  category="account", level="warning" if user.is_locked else "info")
        flash(f"Đã {'khóa' if user.is_locked else 'mở khóa'} tài khoản {user.email}.", "success")
    return redirect(request.referrer or url_for("system.users"))


@system_bp.route("/tai-khoan/<int:user_id>/tat-2-lop", methods=["POST"])
@login_required
@permission_required("account.manage")
def reset_two_factor(user_id):
    """Admin gỡ xác thực hai lớp khi người dùng mất điện thoại (họ đăng nhập lại và bật lại)."""
    user = User.query.get_or_404(user_id)
    user.totp_enabled, user.totp_secret = False, None
    db.session.commit()
    log_event("2fa_reset", f"Gỡ xác thực hai lớp của {user.email}", category="account", level="warning")
    flash(f"Đã gỡ xác thực hai lớp của {user.email}.", "success")
    return redirect(url_for("system.users"))


@system_bp.route("/tai-khoan/<int:user_id>/dat-lai-mat-khau", methods=["POST"])
@login_required
@permission_required("account.manage")
def reset_password(user_id):
    user = User.query.get_or_404(user_id)
    password = request.form.get("new_password", "").strip()
    err = password_error(password, user.email) if password else None
    if err:
        flash(err, "danger")
        return redirect(url_for("system.users"))
    password = password or _random_password()
    user.set_password(password)
    db.session.commit()
    log_event("password_reset", f"Đặt lại mật khẩu tài khoản {user.email}", category="account", level="warning")
    flash(f"Đã đặt lại mật khẩu cho {user.email}. Mật khẩu mới: {password} (chỉ hiển thị một lần).", "success")
    return redirect(url_for("system.users"))


# ======================================================================
# Cấu hình hệ thống
# ======================================================================

@system_bp.route("/cau-hinh", methods=["GET", "POST"])
@login_required
@permission_required("system.config")
def config():
    settings = get_all_settings()
    form = SettingsForm(data=settings)
    if form.validate_on_submit():
        try:
            new_logo = save_logo_image(form.logo.data)
        except ValueError as exc:
            flash(str(exc), "danger")
            return render_template("system/config.html", form=form, settings=settings)
        for key in ("store_name", "store_slogan", "store_address", "store_phone", "store_email"):
            set_setting(key, (getattr(form, key).data or "").strip())
        old_logo = settings.get("logo_filename")
        if new_logo:
            set_setting("logo_filename", new_logo)
            delete_logo_image(old_logo)
        elif form.remove_logo.data and old_logo:
            set_setting("logo_filename", "")
            delete_logo_image(old_logo)
        db.session.commit()
        log_event("config_update", "Cập nhật cấu hình / thông tin cửa hàng", category="config")
        flash("Đã lưu cấu hình hệ thống.", "success")
        return redirect(url_for("system.config"))
    return render_template("system/config.html", form=form, settings=settings)


# ======================================================================
# Sao lưu / khôi phục
# ======================================================================

@system_bp.route("/sao-luu")
@login_required
@permission_required("system.backup")
def backups():
    sqlite = backup_util.is_sqlite()
    return render_template("system/backups.html", backups=backup_util.list_backups() if sqlite else [], sqlite=sqlite)


@system_bp.route("/sao-luu/tao", methods=["POST"])
@login_required
@permission_required("system.backup")
def create_backup():
    if not backup_util.is_sqlite():
        flash("Sao lưu trong giao diện chỉ hỗ trợ SQLite. Với CSDL khác hãy dùng công cụ sao lưu của chính nó.", "warning")
    else:
        name = backup_util.create_backup()
        log_event("backup_create", f"Tạo bản sao lưu {name}", category="backup")
        flash(f"Đã tạo bản sao lưu {name}.", "success")
    return redirect(url_for("system.backups"))


@system_bp.route("/sao-luu/tai/<name>")
@login_required
@permission_required("system.backup")
def download_backup(name):
    path = backup_util.backup_path(name)
    if not path:
        flash("Không tìm thấy bản sao lưu.", "danger")
        return redirect(url_for("system.backups"))
    log_event("backup_download", f"Tải bản sao lưu {name}", category="backup")
    return send_file(path, as_attachment=True, download_name=name)


@system_bp.route("/sao-luu/khoi-phuc", methods=["POST"])
@login_required
@permission_required("system.backup")
def restore_backup():
    name = request.form.get("name", "")
    if request.form.get("confirm", "").strip().upper() != "KHOI PHUC":
        flash("Cần nhập đúng 'KHOI PHUC' để xác nhận khôi phục.", "danger")
        return redirect(url_for("system.backups"))
    try:
        safety = backup_util.restore_backup(name)
    except ValueError as exc:
        flash(str(exc), "danger")
        return redirect(url_for("system.backups"))
    from utils.migrate import upgrade_schema
    upgrade_schema()  # bản sao lưu cũ có thể thiếu cột mới
    log_event("backup_restore", f"Khôi phục dữ liệu từ {name} (bản an toàn trước đó: {safety})",
              category="backup", level="warning")
    flash(f"Đã khôi phục dữ liệu từ {name}. Bản sao lưu trước khi khôi phục: {safety}.", "success")
    return redirect(url_for("system.backups"))


@system_bp.route("/sao-luu/xoa/<name>", methods=["POST"])
@login_required
@permission_required("system.backup")
def delete_backup(name):
    path = backup_util.backup_path(name)
    if path:
        os.remove(path)
        log_event("backup_delete", f"Xóa bản sao lưu {name}", category="backup", level="warning")
        flash("Đã xóa bản sao lưu.", "info")
    return redirect(url_for("system.backups"))


# ======================================================================
# Nhật ký hoạt động
# ======================================================================

@system_bp.route("/nhat-ky")
@login_required
@permission_required("system.log")
def logs():
    category = request.args.get("category", "")
    level = request.args.get("level", "")
    q = request.args.get("q", "").strip()
    page = request.args.get("page", 1, type=int)
    query = NhatKyHeThong.query
    if category in LOG_CATEGORIES:
        query = query.filter(NhatKyHeThong.category == category)
    if level in LOG_LEVELS:
        query = query.filter(NhatKyHeThong.level == level)
    for key, col in (("start", ">="), ("end", "<")):
        raw = request.args.get(key, "")
        try:
            d = datetime.strptime(raw, "%Y-%m-%d")
        except ValueError:
            continue
        if col == ">=":
            query = query.filter(NhatKyHeThong.created_at >= d)
        else:
            query = query.filter(NhatKyHeThong.created_at < d + timedelta(days=1))
    if q:
        like = f"%{q}%"
        query = query.filter(or_(NhatKyHeThong.description.ilike(like), NhatKyHeThong.user_email.ilike(like),
                                 NhatKyHeThong.action.ilike(like)))
    pagination = query.order_by(NhatKyHeThong.created_at.desc(), NhatKyHeThong.id.desc()).paginate(page=page, per_page=50, error_out=False)
    return render_template("system/logs.html", pagination=pagination, category=category, level=level, q=q,
                           start=request.args.get("start", ""), end=request.args.get("end", ""),
                           categories=LOG_CATEGORIES, levels=LOG_LEVELS)


# ======================================================================
# Kiểm tra lỗi & bảo trì
# ======================================================================

def _health_checks():
    checks = []
    try:
        db.session.execute(text("SELECT 1"))
        checks.append(("Kết nối cơ sở dữ liệu", True, "Hoạt động bình thường"))
    except Exception as exc:  # noqa: BLE001
        checks.append(("Kết nối cơ sở dữ liệu", False, str(exc)[:120]))

    if backup_util.is_sqlite():
        size = os.path.getsize(backup_util.db_path()) if os.path.exists(backup_util.db_path()) else 0
        checks.append(("Dung lượng CSDL", True, f"{size / 1024:.0f} KB"))
        backups = backup_util.list_backups()
        if not backups:
            checks.append(("Sao lưu gần nhất", False, "Chưa có bản sao lưu nào — nên sao lưu ngay"))
        else:
            age = datetime.now() - backups[0]["created"]
            checks.append(("Sao lưu gần nhất", age < timedelta(days=7),
                           f"{backups[0]['created']:%d/%m/%Y %H:%M} ({age.days} ngày trước)"))

    for label, folder in (("Thư mục ảnh sản phẩm", current_app.config["UPLOAD_FOLDER"]),
                          ("Thư mục logo", current_app.config["SYSTEM_UPLOAD_FOLDER"])):
        os.makedirs(folder, exist_ok=True)
        checks.append((label, os.access(folder, os.W_OK), "Ghi được" if os.access(folder, os.W_OK) else "Không ghi được"))

    checks.append(("SECRET_KEY", current_app.config["SECRET_KEY"] != "chuoi-bi-mat-mac-dinh-khong-an-toan",
                   "Đã đặt riêng" if current_app.config["SECRET_KEY"] != "chuoi-bi-mat-mac-dinh-khong-an-toan"
                   else "Đang dùng khóa mặc định — hãy đặt SECRET_KEY trong .env"))
    checks.append(("Gửi email", bool(current_app.config.get("MAIL_USERNAME")),
                   "Đã cấu hình SMTP" if current_app.config.get("MAIL_USERNAME") else "Chưa cấu hình (email xác nhận đơn bị bỏ qua)"))
    checks.append(("Chế độ debug", not current_app.debug, "Tắt" if not current_app.debug else "Đang bật — không dùng khi triển khai thật"))
    return checks


@system_bp.route("/bao-tri")
@login_required
@permission_required("system.maintenance")
def maintenance():
    now = datetime.utcnow()
    recent_errors = (NhatKyHeThong.query.filter(NhatKyHeThong.level.in_(["error", "warning"]))
                     .order_by(NhatKyHeThong.created_at.desc()).limit(15).all())
    counts = {
        "users": User.query.count(), "products": Product.query.count(), "orders": Order.query.count(),
        "receipts": PhieuNhap.query.count(), "logs": NhatKyHeThong.query.count(),
        "errors_24h": NhatKyHeThong.query.filter(NhatKyHeThong.level == "error",
                                                 NhatKyHeThong.created_at >= now - timedelta(hours=24)).count(),
    }
    return render_template("system/maintenance.html", checks=_health_checks(), counts=counts,
                           recent_errors=recent_errors, settings=get_all_settings())


@system_bp.route("/bao-tri/che-do", methods=["POST"])
@login_required
@permission_required("system.maintenance")
def toggle_maintenance():
    enable = get_all_settings().get("maintenance_mode") != "1"
    message = request.form.get("message", "").strip()
    if message:
        set_setting("maintenance_message", message[:300])
    set_setting("maintenance_mode", "1" if enable else "0")
    db.session.commit()
    log_event("maintenance_on" if enable else "maintenance_off",
              f"{'Bật' if enable else 'Tắt'} chế độ bảo trì", category="maintenance", level="warning")
    flash("Đã bật chế độ bảo trì — khách hàng tạm thời không truy cập được." if enable else "Đã tắt chế độ bảo trì.",
          "warning" if enable else "success")
    return redirect(url_for("system.maintenance"))


@system_bp.route("/bao-tri/don-nhat-ky", methods=["POST"])
@login_required
@permission_required("system.maintenance")
def purge_logs():
    days = request.form.get("days", 90, type=int)
    if days < 7:
        flash("Chỉ được xóa nhật ký cũ hơn 7 ngày.", "danger")
        return redirect(url_for("system.maintenance"))
    cutoff = datetime.utcnow() - timedelta(days=days)
    deleted = NhatKyHeThong.query.filter(NhatKyHeThong.created_at < cutoff).delete()
    db.session.commit()
    log_event("logs_purge", f"Dọn {deleted} dòng nhật ký cũ hơn {days} ngày", category="maintenance", level="warning")
    flash(f"Đã xóa {deleted} dòng nhật ký cũ hơn {days} ngày.", "success")
    return redirect(url_for("system.maintenance"))
