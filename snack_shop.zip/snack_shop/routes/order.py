from flask import Blueprint, render_template, redirect, url_for, flash, request, session, jsonify
from flask_login import login_required, current_user
import json

from extensions import db
from models import CartItem, Order, OrderItem, OrderVoucher, Voucher, Product
from utils.helpers import is_valid_vn_phone, format_vnd
from utils.email import send_order_confirmation
from utils.banks import get_bank, BANKS
from utils.audit import log_event
from utils.branch import write_branch_id, current_branch_id
from utils.inventory import deduct_stock
from utils.order_service import (can_request, add_order_with_unique_code, REQUEST_TYPE_LABELS,
                                 EXCHANGE_WINDOW_DAYS)

order_bp = Blueprint("order", __name__, url_prefix="/don-hang")

SESSION_VOUCHER_KEY = "applied_voucher_codes"  # list các mã đang áp dụng cho đơn sắp đặt
MAX_VOUCHERS_PER_ORDER = 5  # giới hạn số mã tối đa được cộng dồn trong 1 đơn hàng


def _wants_json():
    """JS phía checkout gọi fetch() kèm header này để nhận về JSON thay vì redirect
    cả trang -- nhờ vậy các trường thông tin giao hàng người dùng đang gõ dở không bị mất."""
    return request.headers.get("X-Requested-With") == "XMLHttpRequest"


def _get_codes():
    return list(session.get(SESSION_VOUCHER_KEY, []))


def _get_applied_vouchers(subtotal, user_id):
    """
    Đọc danh sách mã voucher đang áp dụng trong session, kiểm tra lại từng mã theo
    tổng tiền giỏ hàng hiện tại. Mã không còn hợp lệ sẽ tự động bị gỡ khỏi session.
    Trả về (danh_sach_tuple(voucher, so_tien_giam), tong_tien_giam_da_gioi_han_theo_subtotal).
    """
    codes = _get_codes()
    valid = []
    changed = False

    for code in codes:
        voucher = Voucher.query.filter_by(code=code).first()
        if not voucher:
            changed = True
            continue
        ok, message, discount = voucher.compute_discount(subtotal, user_id=user_id)
        if not ok:
            flash(f"Mã {voucher.code} không còn áp dụng được: {message}", "warning")
            changed = True
            continue
        valid.append((voucher, discount))

    if changed:
        session[SESSION_VOUCHER_KEY] = [v.code for v, _ in valid]

    total_discount = sum(d for _, d in valid)
    total_discount = min(total_discount, subtotal)  # không giảm quá tổng tiền đơn hàng
    return valid, total_discount


def _serialize_summary(subtotal, user_id):
    applied, discount = _get_applied_vouchers(subtotal, user_id)
    total = subtotal - discount
    return {
        "subtotal": subtotal,
        "subtotal_display": format_vnd(subtotal),
        "discount": discount,
        "discount_display": format_vnd(discount),
        "total": total,
        "total_display": format_vnd(total),
        "applied": [
            {
                "code": v.code,
                "description": v.description or "",
                "discount": d,
                "discount_display": format_vnd(d),
            }
            for v, d in applied
        ],
    }


def _current_subtotal():
    items = CartItem.query.filter_by(user_id=current_user.id).all()
    return sum(item.subtotal for item in items)


@order_bp.route("/thanh-toan", methods=["GET", "POST"])
@login_required
def checkout():
    items = CartItem.query.filter_by(user_id=current_user.id).all()
    if not items:
        flash("Giỏ hàng của bạn đang trống.", "warning")
        return redirect(url_for("product.list_products"))

    subtotal = sum(item.subtotal for item in items)

    if request.method == "POST":
        receiver_name = request.form.get("receiver_name", "").strip()
        receiver_phone = request.form.get("receiver_phone", "").strip()
        shipping_address = request.form.get("shipping_address", "").strip()
        note = request.form.get("note", "").strip()
        payment_method = request.form.get("payment_method", "cod")
        bank_code = request.form.get("bank_code", "").strip() or None

        applied, discount = _get_applied_vouchers(subtotal, current_user.id)
        total = subtotal - discount

        def _render_error(message):
            flash(message, "danger")
            return render_template(
                "order/checkout.html", items=items, subtotal=subtotal,
                applied=applied, discount=discount, total=total,
                banks=BANKS, banks_json=json.dumps(BANKS),
            )

        if not (receiver_name and receiver_phone and shipping_address):
            return _render_error("Vui lòng điền đầy đủ thông tin giao hàng.")

        if not is_valid_vn_phone(receiver_phone):
            return _render_error("Số điện thoại người nhận không đúng định dạng VN (vd: 0912345678).")

        if payment_method == "bank_transfer" and not (bank_code and get_bank(bank_code)):
            return _render_error("Vui lòng chọn ngân hàng để chuyển khoản.")

        # Kiểm tra tồn kho lần cuối trước khi tạo đơn
        for item in items:
            if item.product.stock < item.quantity:
                flash(f"Sản phẩm '{item.product.name}' không đủ hàng.", "danger")
                return redirect(url_for("cart.view_cart"))

        # Kiểm tra lại voucher lần cuối ngay trước khi tạo đơn (tránh trường hợp dùng
        # song song ở tab khác trong lúc điền form)
        applied, discount = _get_applied_vouchers(subtotal, current_user.id)
        total = subtotal - discount

        order = Order(
            user_id=current_user.id,
            branch_id=write_branch_id(),
            code="",  # được gán trong add_order_with_unique_code()
            receiver_name=receiver_name,
            receiver_phone=receiver_phone,
            shipping_address=shipping_address,
            note=note,
            payment_method=payment_method,
            bank_code=bank_code if payment_method == "bank_transfer" else None,
            subtotal_amount=subtotal,
            discount_amount=discount,
            voucher_codes=",".join(v.code for v, _ in applied) or None,
            total_amount=total,
            status="pending",
            is_paid=False,
        )
        add_order_with_unique_code(order)  # add + flush: lấy order.id, mã đơn không trùng

        # Trừ tồn kho của chi nhánh bằng UPDATE nguyên tử (WHERE quantity >= số mua) thay vì kiểu
        # "đọc rồi ghi" -- tránh trường hợp 2 người mua sản phẩm cuối cùng gần như
        # đồng thời khiến tồn kho bị âm (race condition).
        stock_shortage_name = None
        for item in items:
            if not deduct_stock(item.product_id, order.branch_id, item.quantity):
                stock_shortage_name = item.product.name
                break

            order_item = OrderItem(
                order_id=order.id,
                product_id=item.product_id,
                product_name=item.product.name,
                price=item.product.final_price,
                quantity=item.quantity,
                cost_price=item.product.cost_price,
            )
            db.session.add(order_item)
            db.session.delete(item)  # xóa khỏi giỏ hàng sau khi đặt

        if stock_shortage_name:
            db.session.rollback()
            flash(f"Rất tiếc, sản phẩm '{stock_shortage_name}' vừa hết hàng hoặc không đủ số lượng. Vui lòng kiểm tra lại giỏ hàng.", "danger")
            return redirect(url_for("cart.view_cart"))

        for voucher, voucher_discount in applied:
            voucher.used_count += 1
            db.session.add(OrderVoucher(order_id=order.id, voucher_code=voucher.code, discount_amount=voucher_discount))

        session.pop(SESSION_VOUCHER_KEY, None)
        db.session.commit()

        # Gửi email xác nhận đơn hàng (không chặn luồng nếu gửi lỗi/chưa cấu hình SMTP)
        send_order_confirmation(order)
        log_event("order_create", f"Khách đặt đơn {order.code} ({order.total_amount:,}đ)", category="order")

        flash("Đặt hàng thành công!", "success")
        return redirect(url_for("order.success", order_code=order.code))

    applied, discount = _get_applied_vouchers(subtotal, current_user.id)
    total = subtotal - discount
    return render_template(
        "order/checkout.html", items=items, subtotal=subtotal, applied=applied,
        discount=discount, total=total, banks=BANKS, banks_json=json.dumps(BANKS),
    )


@order_bp.route("/voucher-goi-y")
@login_required
def voucher_suggestions():
    """Danh sách voucher có thể áp dụng ngay tại trang checkout (JSON), để hiện dropdown
    chọn nhanh mà không cần sang trang /voucher khác."""
    subtotal = _current_subtotal()
    applied_codes = set(_get_codes())

    candidates = Voucher.for_branch(Voucher.query.filter_by(active=True), current_branch_id()).order_by(Voucher.created_at.desc()).limit(30).all()
    result = []
    for v in candidates:
        if v.code in applied_codes or v.is_expired or v.is_used_up:
            continue
        if v.is_used_by(current_user.id):
            continue
        if v.discount_type == "percent":
            discount_text = f"Giảm {v.discount_value}%"
            if v.max_discount_amount:
                discount_text += f" (tối đa {format_vnd(v.max_discount_amount)})"
        else:
            discount_text = f"Giảm {format_vnd(v.discount_value)}"
        result.append({
            "code": v.code,
            "description": v.description or "",
            "discount_text": discount_text,
            "min_order_amount": v.min_order_amount,
            "min_order_display": format_vnd(v.min_order_amount),
            "meets_min": subtotal >= v.min_order_amount,
        })
    return jsonify(result)


@order_bp.route("/ap-dung-voucher", methods=["POST"])
@login_required
def apply_voucher():
    subtotal = _current_subtotal()
    code = request.form.get("voucher_code", "").strip().upper()

    def _fail(message):
        if _wants_json():
            payload = _serialize_summary(subtotal, current_user.id)
            payload.update(ok=False, message=message)
            return jsonify(payload)
        flash(message, "danger")
        return redirect(url_for("order.checkout"))

    if not code:
        return _fail("Vui lòng nhập mã voucher.")

    codes = _get_codes()
    if code in codes:
        return _fail(f"Mã {code} đã được áp dụng rồi.")

    if len(codes) >= MAX_VOUCHERS_PER_ORDER:
        return _fail(f"Mỗi đơn hàng chỉ được áp dụng tối đa {MAX_VOUCHERS_PER_ORDER} mã giảm giá.")

    voucher = Voucher.query.filter_by(code=code).first()
    if not voucher:
        return _fail("Mã voucher không tồn tại.")

    ok, message, discount = voucher.compute_discount(subtotal, user_id=current_user.id)
    if not ok:
        return _fail(message)

    codes.append(code)
    session[SESSION_VOUCHER_KEY] = codes

    if _wants_json():
        payload = _serialize_summary(subtotal, current_user.id)
        payload.update(ok=True, message=f"Đã áp dụng mã {voucher.code}!")
        return jsonify(payload)

    flash(f"Đã áp dụng mã {voucher.code}!", "success")
    return redirect(url_for("order.checkout"))


@order_bp.route("/go-voucher/<code>", methods=["POST"])
@login_required
def remove_voucher(code):
    subtotal = _current_subtotal()
    codes = _get_codes()
    code = code.strip().upper()
    message = None
    if code in codes:
        codes.remove(code)
        session[SESSION_VOUCHER_KEY] = codes
        message = f"Đã gỡ mã {code} khỏi đơn hàng."

    if _wants_json():
        payload = _serialize_summary(subtotal, current_user.id)
        payload.update(ok=True, message=message or "")
        return jsonify(payload)

    if message:
        flash(message, "info")
    return redirect(url_for("order.checkout"))


@order_bp.route("/go-tat-ca-voucher", methods=["POST"])
@login_required
def clear_vouchers():
    subtotal = _current_subtotal()
    session.pop(SESSION_VOUCHER_KEY, None)

    if _wants_json():
        payload = _serialize_summary(subtotal, current_user.id)
        payload.update(ok=True, message="Đã gỡ toàn bộ mã giảm giá.")
        return jsonify(payload)

    flash("Đã gỡ toàn bộ mã giảm giá.", "info")
    return redirect(url_for("order.checkout"))


@order_bp.route("/thanh-cong/<order_code>")
@login_required
def success(order_code):
    order = Order.query.filter_by(code=order_code, user_id=current_user.id).first_or_404()
    bank = get_bank(order.bank_code) if order.bank_code else None
    return render_template("order/success.html", order=order, bank=bank)


@order_bp.route("/lich-su")
@login_required
def history():
    orders = Order.query.filter_by(user_id=current_user.id).order_by(Order.created_at.desc()).all()
    return render_template("order/history.html", orders=orders)


@order_bp.route("/chi-tiet/<order_code>")
@login_required
def detail(order_code):
    order = Order.query.filter_by(code=order_code, user_id=current_user.id).first_or_404()
    bank = get_bank(order.bank_code) if order.bank_code else None
    return render_template(
        "order/detail.html", order=order, bank=bank,
        can_cancel=can_request(order, "cancel")[0], can_exchange=can_request(order, "exchange")[0],
        type_labels=REQUEST_TYPE_LABELS, exchange_days=EXCHANGE_WINDOW_DAYS,
    )


@order_bp.route("/yeu-cau/<order_code>", methods=["POST"])
@login_required
def submit_request(order_code):
    """Khách gửi yêu cầu hủy / đổi đơn (chỉ với đơn của chính mình). Nhân viên sẽ xử lý."""
    order = Order.query.filter_by(code=order_code, user_id=current_user.id).first_or_404()
    request_type = request.form.get("request_type", "")
    reason = request.form.get("reason", "").strip()
    ok, why = can_request(order, request_type)
    if not ok:
        flash(why, "danger")
    elif len(reason) < 5:
        flash("Vui lòng nhập lý do (ít nhất 5 ký tự).", "danger")
    else:
        from datetime import datetime
        order.request_type = request_type
        order.request_reason = reason[:255]
        order.request_status = "pending"
        order.request_at = datetime.utcnow()
        order.request_note = None
        order.request_handled_by_id = None
        db.session.commit()
        log_event("order_request_create", f"Khách gửi yêu cầu {REQUEST_TYPE_LABELS[request_type]} cho đơn {order.code}", category="order")
        flash("Đã gửi yêu cầu, nhân viên sẽ xử lý sớm nhất.", "success")
    return redirect(url_for("order.detail", order_code=order.code))
