from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from sqlalchemy import func, or_
from datetime import datetime, timedelta, date

from extensions import db
from models import (Product, Category, Supplier, Order, OrderItem, User, Voucher, OrderVoucher,
                    PhieuNhap, ChiTietPhieuNhap, NhatKyHeThong)
from models.user import WALKIN_EMAIL
from models.setting import get_setting
from utils.audit import log_event
from utils.branch import current_branch_id, write_branch_id
from utils.inventory import deduct_stock
from utils.order_service import (add_order_with_unique_code, change_order_status, resolve_request, ALLOWED_TRANSITIONS,
                                 REQUEST_TYPE_LABELS, REQUEST_STATUS_LABELS)
from utils.helpers import generate_order_code, is_valid_vn_phone
from utils.timeutil import vn_now, vn_midnight_utc, vn_date_sql
from utils.backup import list_backups, is_sqlite, db_path
from forms.product_form import ProductForm, CategoryForm
from forms.supplier_form import SupplierForm
from forms.voucher_form import VoucherForm
from utils.decorators import permission_required, backoffice_required
from utils.upload import save_product_image, delete_product_image
from utils.helpers import slugify
from routes.reports import daily_series

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


def _safe_next(target):
    """Chỉ cho phép chuyển hướng về đường dẫn nội bộ (tránh open-redirect)."""
    if target and target.startswith("/") and not target.startswith("//"):
        return target
    return None


# ---------- Sản phẩm ----------

@admin_bp.route("/san-pham")
@login_required
@permission_required("product.manage", "product.view")
def products():
    """Danh sách sản phẩm: quản lý chuỗi sửa được; quản lý chi nhánh / nhân viên chỉ xem (tồn theo chi nhánh đang làm việc)."""
    all_products = Product.query.order_by(Product.created_at.desc()).all()
    return render_template("admin/products.html", products=all_products,
                           can_manage=current_user.has_permission("product.manage"))


@admin_bp.route("/san-pham/them", methods=["GET", "POST"])
@login_required
@permission_required("product.manage")
def add_product():
    form = ProductForm()
    form.category_id.choices = [(c.id, c.name) for c in Category.query.all()]
    form.supplier_id.choices = [(0, "-- Không chọn --")] + [(s.id, s.name) for s in Supplier.query.all()]

    if form.validate_on_submit():
        name_clean = form.name.data.strip()
        new_slug = slugify(name_clean)

        duplicate = Product.query.filter(
            db.func.lower(Product.name) == name_clean.lower()
        ).first()
        if duplicate or Product.query.filter_by(slug=new_slug).first():
            flash(f"Tên sản phẩm '{name_clean}' đã tồn tại. Vui lòng đặt tên khác.", "danger")
            return render_template("admin/product-form.html", form=form, mode="add")

        try:
            filename = save_product_image(form.image.data)
        except ValueError as e:
            flash(str(e), "danger")
            return render_template("admin/product-form.html", form=form, mode="add")

        product = Product(
            name=name_clean,
            slug=new_slug,
            description=form.description.data,
            price=form.price.data,
            sale_price=form.sale_price.data or None,
            cost_price=form.cost_price.data,
            category_id=form.category_id.data,
            supplier_id=form.supplier_id.data or None,
            image_filename=filename,
            image_source="upload" if filename else "default",
        )
        db.session.add(product)
        db.session.commit()
        log_event("product_create", f"Thêm sản phẩm '{product.name}' giá {product.price:,}đ", category="product")
        flash("Đã thêm sản phẩm mới.", "success")
        return redirect(url_for("admin.products"))

    return render_template("admin/product-form.html", form=form, mode="add")


@admin_bp.route("/san-pham/sua/<int:product_id>", methods=["GET", "POST"])
@login_required
@permission_required("product.manage")
def edit_product(product_id):
    product = Product.query.get_or_404(product_id)
    form = ProductForm(obj=product)
    form.category_id.choices = [(c.id, c.name) for c in Category.query.all()]
    form.supplier_id.choices = [(0, "-- Không chọn --")] + [(s.id, s.name) for s in Supplier.query.all()]
    if request.method == "GET":
        form.supplier_id.data = product.supplier_id or 0

    if form.validate_on_submit():
        name_clean = form.name.data.strip()
        new_slug = slugify(name_clean)

        duplicate = Product.query.filter(
            Product.id != product.id,
            db.func.lower(Product.name) == name_clean.lower(),
        ).first()
        slug_conflict = Product.query.filter(
            Product.id != product.id, Product.slug == new_slug
        ).first()
        if duplicate or slug_conflict:
            flash(f"Tên sản phẩm '{name_clean}' đã được dùng bởi sản phẩm khác.", "danger")
            return render_template("admin/product-form.html", form=form, mode="edit", product=product)

        try:
            new_filename = save_product_image(form.image.data)
        except ValueError as e:
            flash(str(e), "danger")
            return render_template("admin/product-form.html", form=form, mode="edit", product=product)

        if new_filename:
            if product.image_source == "upload":
                delete_product_image(product.image_filename)
            product.image_filename = new_filename
            product.image_source = "upload"

        product.name = name_clean
        product.slug = new_slug
        product.description = form.description.data
        product.price = form.price.data
        product.sale_price = form.sale_price.data or None
        product.cost_price = form.cost_price.data
        product.category_id = form.category_id.data
        product.supplier_id = form.supplier_id.data or None

        db.session.commit()
        log_event("product_update", f"Sửa sản phẩm '{product.name}' (giá {product.price:,}đ, KM {product.sale_price or 0:,}đ)", category="product")
        flash("Đã cập nhật sản phẩm.", "success")
        return redirect(url_for("admin.products"))

    return render_template("admin/product-form.html", form=form, mode="edit", product=product)


@admin_bp.route("/san-pham/xoa/<int:product_id>", methods=["POST"])
@login_required
@permission_required("product.manage")
def delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    if product.image_source == "upload":
        delete_product_image(product.image_filename)
    name = product.name
    db.session.delete(product)
    db.session.commit()
    log_event("product_delete", f"Xóa sản phẩm '{name}'", category="product", level="warning")
    flash("Đã xóa sản phẩm.", "info")
    return redirect(url_for("admin.products"))


# ---------- Danh mục ----------

@admin_bp.route("/danh-muc", methods=["GET", "POST"])
@login_required
@permission_required("product.manage")
def categories():
    form = CategoryForm()
    if form.validate_on_submit():
        category = Category(name=form.name.data, slug=slugify(form.name.data), icon=form.icon.data or "🍬")
        db.session.add(category)
        db.session.commit()
        flash("Đã thêm danh mục.", "success")
        return redirect(url_for("admin.categories"))

    all_categories = Category.query.all()
    return render_template("admin/categories.html", categories=all_categories, form=form)


@admin_bp.route("/danh-muc/xoa/<int:category_id>", methods=["POST"])
@login_required
@permission_required("product.manage")
def delete_category(category_id):
    category = Category.query.get_or_404(category_id)
    if category.products:
        flash("Không thể xóa danh mục còn sản phẩm bên trong.", "danger")
    else:
        db.session.delete(category)
        db.session.commit()
        flash("Đã xóa danh mục.", "info")
    return redirect(url_for("admin.categories"))


# ---------- Nhà cung cấp ----------

@admin_bp.route("/nha-cung-cap")
@login_required
@permission_required("supplier.manage")
def suppliers():
    all_suppliers = Supplier.query.order_by(Supplier.name).all()
    return render_template("admin/suppliers.html", suppliers=all_suppliers)


@admin_bp.route("/nha-cung-cap/them", methods=["GET", "POST"])
@login_required
@permission_required("supplier.manage")
def add_supplier():
    form = SupplierForm()
    if form.validate_on_submit():
        supplier = Supplier(
            name=form.name.data.strip(),
            contact_name=form.contact_name.data,
            phone=form.phone.data,
            email=form.email.data,
            address=form.address.data,
            note=form.note.data,
        )
        db.session.add(supplier)
        db.session.commit()
        flash("Đã thêm nhà cung cấp.", "success")
        return redirect(url_for("admin.suppliers"))

    return render_template("admin/supplier-form.html", form=form, mode="add")


@admin_bp.route("/nha-cung-cap/sua/<int:supplier_id>", methods=["GET", "POST"])
@login_required
@permission_required("supplier.manage")
def edit_supplier(supplier_id):
    supplier = Supplier.query.get_or_404(supplier_id)
    form = SupplierForm(obj=supplier)

    if form.validate_on_submit():
        supplier.name = form.name.data.strip()
        supplier.contact_name = form.contact_name.data
        supplier.phone = form.phone.data
        supplier.email = form.email.data
        supplier.address = form.address.data
        supplier.note = form.note.data
        db.session.commit()
        flash("Đã cập nhật nhà cung cấp.", "success")
        return redirect(url_for("admin.suppliers"))

    return render_template("admin/supplier-form.html", form=form, mode="edit", supplier=supplier)


@admin_bp.route("/nha-cung-cap/xoa/<int:supplier_id>", methods=["POST"])
@login_required
@permission_required("supplier.manage")
def delete_supplier(supplier_id):
    supplier = Supplier.query.get_or_404(supplier_id)
    if supplier.products:
        flash("Không thể xóa nhà cung cấp đang có sản phẩm liên kết.", "danger")
    else:
        db.session.delete(supplier)
        db.session.commit()
        flash("Đã xóa nhà cung cấp.", "info")
    return redirect(url_for("admin.suppliers"))


# ---------- Voucher ----------
# Quy tắc theo chi nhánh: voucher có branch_id = None dùng toàn hệ thống, ngược lại chỉ dùng ở chi nhánh đó.
# Quản lý được gán chi nhánh chỉ thấy mã toàn hệ thống + mã của chi nhánh mình, và chỉ tạo/sửa/xóa mã của chi nhánh mình.
# Quản lý chưa gán chi nhánh (xem tất cả) quản lý được mọi mã.

def _voucher_branch_choices():
    from models import ChiNhanh
    if current_user.branch_id:
        b = db.session.get(ChiNhanh, current_user.branch_id)
        return [(b.id, f"Chỉ {b.name}")]
    return [(0, "Toàn hệ thống")] + [(b.id, f"Chỉ {b.name}") for b in ChiNhanh.query.order_by(ChiNhanh.id).all()]


def _voucher_branch_value(form):
    """Chi nhánh được lưu cho voucher: quản lý gán chi nhánh luôn bị ép về chi nhánh của mình."""
    if current_user.branch_id:
        return current_user.branch_id
    from models import ChiNhanh
    return form.branch_id.data if db.session.get(ChiNhanh, form.branch_id.data or 0) else None


def _can_edit_voucher(voucher):
    return not current_user.branch_id or voucher.branch_id == current_user.branch_id


def _voucher_or_404(voucher_id, editing=False):
    voucher = Voucher.query.get_or_404(voucher_id)
    if current_user.branch_id and voucher.branch_id not in (None, current_user.branch_id):
        abort(404)  # mã của chi nhánh khác: không thấy
    if editing and not _can_edit_voucher(voucher):
        abort(403)  # mã toàn hệ thống: quản lý chi nhánh chỉ xem
    return voucher


@admin_bp.route("/voucher")
@login_required
@permission_required("voucher.manage")
def vouchers():
    q = Voucher.query
    if current_user.branch_id:
        q = Voucher.for_branch(q, current_user.branch_id)
    all_vouchers = q.order_by(Voucher.created_at.desc()).all()
    return render_template("admin/vouchers.html", vouchers=all_vouchers, can_edit=_can_edit_voucher)


@admin_bp.route("/voucher/them", methods=["GET", "POST"])
@login_required
@permission_required("voucher.manage")
def add_voucher():
    form = VoucherForm()
    form.branch_id.choices = _voucher_branch_choices()
    if form.validate_on_submit():
        code = form.code.data.strip().upper()
        if Voucher.query.filter_by(code=code).first():
            flash("Mã voucher này đã tồn tại.", "danger")
            return render_template("admin/voucher-form.html", form=form, mode="add")

        voucher = Voucher(
            code=code,
            description=form.description.data,
            discount_type=form.discount_type.data,
            discount_value=form.discount_value.data,
            max_discount_amount=form.max_discount_amount.data or None,
            min_order_amount=form.min_order_amount.data or 0,
            usage_limit=form.usage_limit.data or None,
            expires_at=form.expires_at.data or None,
            branch_id=_voucher_branch_value(form),
            active=form.active.data,
        )
        db.session.add(voucher)
        db.session.commit()
        log_event("voucher_create", f"Tạo voucher {voucher.code} ({voucher.scope_label})", category="product")
        flash(f"Đã tạo voucher {voucher.code}.", "success")
        return redirect(url_for("admin.vouchers"))

    return render_template("admin/voucher-form.html", form=form, mode="add")


@admin_bp.route("/voucher/sua/<int:voucher_id>", methods=["GET", "POST"])
@login_required
@permission_required("voucher.manage")
def edit_voucher(voucher_id):
    voucher = _voucher_or_404(voucher_id, editing=True)
    form = VoucherForm(obj=voucher)
    form.branch_id.choices = _voucher_branch_choices()
    if request.method == "GET":
        form.branch_id.data = voucher.branch_id or 0

    if form.validate_on_submit():
        code = form.code.data.strip().upper()
        existing = Voucher.query.filter(Voucher.code == code, Voucher.id != voucher.id).first()
        if existing:
            flash("Mã voucher này đã được dùng bởi voucher khác.", "danger")
            return render_template("admin/voucher-form.html", form=form, mode="edit", voucher=voucher)

        voucher.code = code
        voucher.description = form.description.data
        voucher.discount_type = form.discount_type.data
        voucher.discount_value = form.discount_value.data
        voucher.max_discount_amount = form.max_discount_amount.data or None
        voucher.min_order_amount = form.min_order_amount.data or 0
        voucher.usage_limit = form.usage_limit.data or None
        voucher.expires_at = form.expires_at.data or None
        voucher.branch_id = _voucher_branch_value(form)
        voucher.active = form.active.data

        db.session.commit()
        log_event("voucher_update", f"Sửa voucher {voucher.code}", category="product")
        flash(f"Đã cập nhật voucher {voucher.code}.", "success")
        return redirect(url_for("admin.vouchers"))

    return render_template("admin/voucher-form.html", form=form, mode="edit", voucher=voucher)


@admin_bp.route("/voucher/xoa/<int:voucher_id>", methods=["POST"])
@login_required
@permission_required("voucher.manage")
def delete_voucher(voucher_id):
    voucher = _voucher_or_404(voucher_id, editing=True)
    db.session.delete(voucher)
    db.session.commit()
    flash("Đã xóa voucher.", "info")
    return redirect(url_for("admin.vouchers"))


@admin_bp.route("/voucher/<int:voucher_id>/lich-su-dung")
@login_required
@permission_required("voucher.manage")
def voucher_usage(voucher_id):
    voucher = Voucher.query.get_or_404(voucher_id)
    usages = (
        db.session.query(OrderVoucher, Order, User)
        .join(Order, Order.id == OrderVoucher.order_id)
        .join(User, User.id == Order.user_id)
        .filter(OrderVoucher.voucher_code == voucher.code)
        .order_by(Order.created_at.desc())
        .all()
    )
    return render_template("admin/voucher-usage.html", voucher=voucher, usages=usages)




# ======================================================================
# Tổng quan theo vai trò
# ======================================================================

def _revenue_since(since):
    return (
        db.session.query(func.sum(Order.total_amount))
        .filter(Order.created_at >= since, Order.status != "cancelled")
        .scalar() or 0
    )


@admin_bp.route("/")
@login_required
@backoffice_required
def dashboard():
    now = datetime.utcnow()  # mốc UTC (so với cột created_at lưu UTC)
    vn_today = vn_now().date()  # "hôm nay" theo giờ Việt Nam
    today_start = vn_midnight_utc(vn_today)  # 0h hôm nay (giờ VN) quy ra UTC
    month_start = vn_midnight_utc(vn_today.replace(day=1))
    ctx = {"stats": {}}

    if current_user.is_admin:
        # Admin: chỉ số kỹ thuật/hệ thống, KHÔNG có số liệu bán hàng
        backups = list_backups() if is_sqlite() else []
        ctx["stats"] = {
            "total_users": User.query.count(),
            "locked_users": User.query.filter_by(is_locked=True).count(),
            "backoffice_users": User.query.filter(User.role.in_(["admin", "chain_manager", "manager", "staff"])).count(),
            "errors_24h": NhatKyHeThong.query.filter(
                NhatKyHeThong.level == "error", NhatKyHeThong.created_at >= now - timedelta(hours=24)).count(),
            "last_backup": backups[0]["created"] if backups else None,
            "maintenance": get_setting("maintenance_mode") == "1",
        }
        ctx["recent_logs"] = NhatKyHeThong.query.order_by(NhatKyHeThong.created_at.desc()).limit(8).all()
        return render_template("admin/dashboard.html", **ctx)

    stats = {
        "pending_orders": Order.query.filter_by(status="pending").count(),
        "pending_requests": Order.query.filter_by(request_status="pending").count(),
        "shipping_orders": Order.query.filter_by(status="shipping").count(),
        "low_stock": Product.query.filter(Product.stock <= Product.LOW_STOCK_THRESHOLD).count(),
    }
    if current_user.is_any_manager:
        from models import PhieuDieuChinh
        from routes.adjust import can_review
        stats["pending_adjustments"] = sum(1 for t in PhieuDieuChinh.query.filter_by(status="pending").all() if can_review(t))
        if current_user.is_chain_manager:
            from models import ChiNhanh
            rows = (db.session.query(ChiNhanh.code, ChiNhanh.name, func.coalesce(func.sum(Order.total_amount), 0),
                                     func.count(Order.id))
                    .outerjoin(Order, db.and_(Order.branch_id == ChiNhanh.id, Order.created_at >= month_start,
                                              Order.status != "cancelled"))
                    .group_by(ChiNhanh.id, ChiNhanh.code, ChiNhanh.name).order_by(ChiNhanh.id).all())
            ctx["branch_revenue"] = rows
        stats.update(
            total_products=Product.query.count(),
            total_orders=Order.query.count(),
            revenue_today=_revenue_since(today_start),
            revenue_month=_revenue_since(month_start),
            pending_receipts=PhieuNhap.query.filter_by(status="pending").count(),
        )
        ctx["near_expiry"] = _near_expiry_lines(30)[:5]
        since7 = today_start - timedelta(days=6)
        rows7 = (
            db.session.query(vn_date_sql(Order.created_at).label("day"), func.sum(Order.total_amount).label("revenue"))
            .filter(Order.created_at >= since7, Order.status != "cancelled")
            .group_by(vn_date_sql(Order.created_at)).all()
        )
        first_day = datetime.combine(vn_today - timedelta(days=6), datetime.min.time())  # nhãn trục: ngày VN
        ctx["chart_labels"], ctx["chart_values"] = daily_series(rows7, first_day, 7)
    else:
        ctx["my_receipts"] = (
            PhieuNhap.query.filter_by(assigned_to_id=current_user.id, status="pending")
            .order_by(PhieuNhap.created_at.desc()).all()
        )
        stats["my_handled_today"] = Order.query.filter(
            Order.handled_by_id == current_user.id, Order.handled_at >= today_start).count()
    ctx["stats"] = stats
    ctx["recent_orders"] = Order.query.order_by(Order.created_at.desc()).limit(5).all()
    return render_template("admin/dashboard.html", **ctx)


def _near_expiry_lines(days):
    """Dòng nhập hàng (phiếu đã nhập kho) có hạn dùng trong `days` ngày tới hoặc đã quá hạn,
    của sản phẩm còn tồn. Hạn dùng được theo dõi theo lô nhập (không trừ tồn theo từng lô)."""
    limit = vn_now().date() + timedelta(days=days)
    return (
        db.session.query(ChiTietPhieuNhap)
        .join(PhieuNhap, PhieuNhap.id == ChiTietPhieuNhap.receipt_id)
        .join(Product, Product.id == ChiTietPhieuNhap.product_id)
        .filter(PhieuNhap.status == "completed", ChiTietPhieuNhap.expiry_date.isnot(None),
                ChiTietPhieuNhap.expiry_date <= limit, Product.stock > 0,
                ChiTietPhieuNhap.received_quantity > 0)
        .order_by(ChiTietPhieuNhap.expiry_date)
        .all()
    )


# ======================================================================
# Đơn hàng: xem / giám sát / xử lý
# ======================================================================

@admin_bp.route("/don-hang")
@login_required
@permission_required("order.view")
def orders():
    status = request.args.get("status", "")
    q = request.args.get("q", "").strip()
    only_requests = request.args.get("requests") == "1"
    query = Order.query
    if status in ALLOWED_TRANSITIONS:
        query = query.filter(Order.status == status)
    if only_requests:
        query = query.filter(Order.request_status == "pending")
    if q:
        like = f"%{q}%"
        query = query.filter(or_(Order.code.ilike(like), Order.receiver_name.ilike(like), Order.receiver_phone.ilike(like)))
    all_orders = query.order_by(Order.created_at.desc()).limit(300).all()
    return render_template("admin/orders.html", orders=all_orders, status=status, q=q, only_requests=only_requests,
                           request_type_labels=REQUEST_TYPE_LABELS)


@admin_bp.route("/don-hang/chi-tiet/<order_code>")
@login_required
@permission_required("order.view")
def order_detail(order_code):
    order = Order.query.filter_by(code=order_code).first_or_404()
    return render_template("admin/order-detail.html", order=order, transitions=ALLOWED_TRANSITIONS[order.status],
                           request_type_labels=REQUEST_TYPE_LABELS, request_status_labels=REQUEST_STATUS_LABELS)


@admin_bp.route("/don-hang/<order_code>/hoa-don")
@login_required
@permission_required("order.view")
def invoice(order_code):
    order = Order.query.filter_by(code=order_code).first_or_404()
    return render_template("admin/invoice.html", order=order)


@admin_bp.route("/don-hang/cap-nhat/<int:order_id>", methods=["POST"])
@login_required
@permission_required("order.process")
def update_order_status(order_id):
    order = Order.query.get_or_404(order_id)
    ok, message = change_order_status(order, request.form.get("status", ""), current_user)
    flash(message, "success" if ok else "danger")
    return redirect(_safe_next(request.form.get("next")) or url_for("admin.orders"))


@admin_bp.route("/don-hang/xac-nhan-thanh-toan/<int:order_id>", methods=["POST"])
@login_required
@permission_required("order.process")
def mark_paid(order_id):
    order = Order.query.get_or_404(order_id)
    if order.is_paid and order.payment_method == "bank_transfer" and order.status in ("shipping", "completed"):
        flash("Đơn chuyển khoản đã giao hoặc hoàn thành, không thể bỏ đánh dấu đã thu tiền.", "danger")
        return redirect(_safe_next(request.form.get("next")) or url_for("admin.orders"))
    order.is_paid = not order.is_paid
    order.handled_by_id = current_user.id
    order.handled_at = datetime.utcnow()
    db.session.commit()
    log_event("order_paid", f"Đơn {order.code}: {'đã' if order.is_paid else 'chưa'} nhận tiền", category="order")
    flash(f"Đã đánh dấu đơn {order.code} là {'đã' if order.is_paid else 'chưa'} nhận được tiền.", "success")
    return redirect(_safe_next(request.form.get("next")) or url_for("admin.orders"))


@admin_bp.route("/don-hang/<int:order_id>/xu-ly-yeu-cau", methods=["POST"])
@login_required
@permission_required("order.request")
def handle_request(order_id):
    order = Order.query.get_or_404(order_id)
    approve = request.form.get("decision") == "approve"
    note = request.form.get("note", "")
    if not approve and not note.strip():
        flash("Vui lòng nhập lý do khi từ chối yêu cầu.", "danger")
    else:
        ok, message = resolve_request(order, approve, note, current_user)
        flash(message, "success" if ok else "danger")
    return redirect(_safe_next(request.form.get("next")) or url_for("admin.order_detail", order_code=order.code))


# ======================================================================
# Bán hàng tại quầy + hóa đơn
# ======================================================================

def _walkin_user():
    user = User.query.filter_by(email=WALKIN_EMAIL).first()
    if not user:
        user = User(full_name="Khách lẻ (tại quầy)", email=WALKIN_EMAIL, role="customer", is_locked=True)
        user.set_password(generate_order_code() + "-khong-dang-nhap")
        db.session.add(user)
        db.session.flush()
    return user


@admin_bp.route("/ban-hang", methods=["GET", "POST"])
@login_required
@permission_required("sale.create")
def counter_sale():
    products = Product.query.filter(Product.stock > 0).order_by(Product.name).all()
    if request.method == "POST":
        ids = request.form.getlist("product_id")
        qtys = request.form.getlist("quantity")
        wanted = {}
        for pid, qty in zip(ids, qtys):
            if pid.isdigit() and qty.isdigit() and int(qty) > 0:
                wanted[int(pid)] = wanted.get(int(pid), 0) + int(qty)
        customer_name = request.form.get("customer_name", "").strip() or "Khách lẻ"
        customer_phone = request.form.get("customer_phone", "").strip()
        payment = request.form.get("payment_method", "cash")

        if not wanted:
            flash("Vui lòng chọn ít nhất 1 sản phẩm.", "danger")
            return render_template("admin/counter-sale.html", products=products)
        if customer_phone and not is_valid_vn_phone(customer_phone):
            flash("Số điện thoại khách không đúng định dạng.", "danger")
            return render_template("admin/counter-sale.html", products=products)

        walkin = _walkin_user()
        order = Order(
            user_id=walkin.id, branch_id=write_branch_id(), code="", receiver_name=customer_name,
            receiver_phone=customer_phone or "", shipping_address="Mua tại quầy",
            payment_method="cod" if payment == "cash" else "bank_transfer",
            channel="counter", status="completed", is_paid=True,
            handled_by_id=current_user.id, handled_at=datetime.utcnow(), completed_at=datetime.utcnow(),
        )
        add_order_with_unique_code(order)  # mã đơn không trùng kể cả 2 đơn cùng giây

        total = 0
        for pid, qty in wanted.items():
            product = db.session.get(Product, pid)
            if not product or not deduct_stock(pid, order.branch_id, qty):
                db.session.rollback()
                flash(f"Sản phẩm '{product.name if product else pid}' không đủ tồn kho.", "danger")
                return render_template("admin/counter-sale.html", products=Product.query.filter(Product.stock > 0).order_by(Product.name).all())
            db.session.add(OrderItem(order_id=order.id, product_id=pid, product_name=product.name,
                                     price=product.final_price, quantity=qty, cost_price=product.cost_price))
            total += product.final_price * qty
        order.subtotal_amount = total
        order.total_amount = total
        db.session.commit()
        log_event("counter_sale", f"Bán tại quầy {order.code} ({total:,}đ)", category="order")
        flash(f"Đã lập hóa đơn {order.code}.", "success")
        return redirect(url_for("admin.invoice", order_code=order.code))
    return render_template("admin/counter-sale.html", products=products)


# ======================================================================
# Tra cứu khách hàng
# ======================================================================

@admin_bp.route("/khach-hang")
@login_required
@permission_required("customer.view")
def customers():
    q = request.args.get("q", "").strip()
    query = User.query.filter(User.role == "customer", User.email != WALKIN_EMAIL)
    if q:
        like = f"%{q}%"
        query = query.filter(or_(User.full_name.ilike(like), User.email.ilike(like), User.phone.ilike(like)))
    return render_template("admin/customers.html", customers=query.order_by(User.created_at.desc()).limit(200).all(), q=q)


@admin_bp.route("/khach-hang/<int:user_id>")
@login_required
@permission_required("customer.view")
def customer_detail(user_id):
    customer = User.query.filter_by(id=user_id, role="customer").first_or_404()
    orders_ = Order.query.filter_by(user_id=customer.id).order_by(Order.created_at.desc()).all()
    spent = sum(o.total_amount for o in orders_ if o.status != "cancelled")
    return render_template("admin/customer-detail.html", customer=customer, orders=orders_, spent=spent)
