"""Thống kê & báo cáo cho quản lý: doanh thu/lợi nhuận, bán hàng, nhập hàng, xuất hàng, hiệu suất nhân viên."""
import csv
import io
from datetime import datetime, timedelta

from flask import Blueprint, render_template, request, Response
from flask_login import login_required
from sqlalchemy import func, case

from extensions import db
from models import Order, OrderItem, Product, Category, PhieuNhap, ChiTietPhieuNhap, Supplier, User, ChiNhanh
from utils.decorators import permission_required
from utils.helpers import format_vnd
from utils.branch import current_branch_id, current_branch
from utils.timeutil import vn_now, vn_midnight_utc, vn_date_sql

report_bp = Blueprint("report", __name__, url_prefix="/admin/bao-cao")


def _range():
    """Khoảng ngày lọc báo cáo: ?start=YYYY-MM-DD&end=YYYY-MM-DD, mặc định 30 ngày gần nhất.
    Trả về (start_dt, end_dt_exclusive, start_str, end_str)."""
    today = vn_now().date()  # ngày theo giờ Việt Nam
    def parse(v, default):
        try:
            return datetime.strptime(v, "%Y-%m-%d").date()
        except (TypeError, ValueError):
            return default
    start = parse(request.args.get("start"), today - timedelta(days=29))
    end = parse(request.args.get("end"), today)
    if end < start:
        start, end = end, start
    # start/end là NGÀY THEO GIỜ VN -> quy ra mốc UTC để lọc cột created_at (lưu UTC)
    return (vn_midnight_utc(start), vn_midnight_utc(end + timedelta(days=1)), start.isoformat(), end.isoformat())


def _render_table(title, columns, rows, totals, start, end, extra_note=None):
    if request.args.get("format") == "csv":
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(columns)
        writer.writerows(rows)
        if totals:
            writer.writerow(totals)
        return Response("﻿" + buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": f"attachment; filename=bao-cao-{start}-{end}.csv"})
    branch = current_branch()
    scope = f"Phạm vi: {branch.name}." if branch else "Phạm vi: tất cả chi nhánh."
    return render_template("reports/report.html", title=title, columns=columns, rows=rows, totals=totals,
                           start=start, end=end, note=(scope + " " + extra_note) if extra_note else scope)


def _profit_expr():
    return func.sum(case((OrderItem.cost_price.isnot(None), (OrderItem.price - OrderItem.cost_price) * OrderItem.quantity), else_=0))


def daily_series(rows, since, days):
    """Điền đủ mọi ngày trong khoảng (ngày không có đơn = 0) để biểu đồ không nối sai giữa các ngày."""
    by_day = {str(r.day)[:10]: int(r.revenue or 0) for r in rows}
    labels, values = [], []
    for i in range(days):
        d = (since + timedelta(days=i)).date().isoformat()
        labels.append(d)
        values.append(by_day.get(d, 0))
    return labels, values


@report_bp.route("/thong-ke")
@login_required
@permission_required("report.view")
def stats():
    days = request.args.get("days", 30, type=int)
    first_day = vn_now().date() - timedelta(days=days - 1)  # ngày đầu của khoảng (giờ VN)
    since = vn_midnight_utc(first_day)  # mốc UTC để lọc

    rows = (
        db.session.query(vn_date_sql(Order.created_at).label("day"), func.sum(Order.total_amount).label("revenue"),
                         func.count(Order.id).label("order_count"))
        .filter(Order.created_at >= since, Order.status != "cancelled")
        .group_by(vn_date_sql(Order.created_at)).order_by(vn_date_sql(Order.created_at)).all()
    )
    labels, revenues = daily_series(rows, datetime.combine(first_day, datetime.min.time()), days)
    total_revenue = sum(revenues)
    total_orders = sum(r.order_count or 0 for r in rows)

    profit_row = (
        db.session.query(_profit_expr(),
                         func.sum(case((OrderItem.cost_price.isnot(None), OrderItem.price * OrderItem.quantity), else_=0)))
        .join(Order, Order.id == OrderItem.order_id)
        .filter(Order.created_at >= since, Order.status != "cancelled").one()
    )
    total_profit = profit_row[0] or 0
    costed_revenue = profit_row[1] or 0

    top_products = (
        db.session.query(OrderItem.product_name, func.sum(OrderItem.quantity), func.sum(OrderItem.price * OrderItem.quantity))
        .join(Order, Order.id == OrderItem.order_id)
        .filter(Order.created_at >= since, Order.status != "cancelled")
        .group_by(OrderItem.product_name).order_by(func.sum(OrderItem.quantity).desc()).limit(5).all()
    )
    # Biểu đồ 2: so sánh các chi nhánh theo ngày (người xem chỉ thấy 1 chi nhánh thì chuyển sang cơ cấu theo danh mục)
    br_rows = (
        db.session.query(vn_date_sql(Order.created_at).label("day"), Order.branch_id, func.sum(Order.total_amount).label("revenue"))
        .filter(Order.created_at >= since, Order.status != "cancelled")
        .group_by(vn_date_sql(Order.created_at), Order.branch_id).all()
    )
    names = {b.id: b.name for b in ChiNhanh.query.all()}
    by_branch = {}
    for r in br_rows:
        by_branch.setdefault(r.branch_id, []).append(r)
    chart2 = None
    if len(by_branch) > 1:
        series = []
        for bid in sorted(by_branch, key=lambda k: names.get(k, "")):
            _, vals = daily_series(by_branch[bid], datetime.combine(first_day, datetime.min.time()), days)
            series.append({"name": names.get(bid, "Chưa gán chi nhánh"), "values": vals, "total": sum(vals)})
        chart2 = {"kind": "branch", "title": "Doanh thu theo chi nhánh", "series": series}
    else:
        cat_rows = (
            db.session.query(Category.name, func.sum(OrderItem.price * OrderItem.quantity))
            .join(Product, Product.id == OrderItem.product_id).join(Category, Category.id == Product.category_id)
            .join(Order, Order.id == OrderItem.order_id)
            .filter(Order.created_at >= since, Order.status != "cancelled")
            .group_by(Category.name).order_by(func.sum(OrderItem.price * OrderItem.quantity).desc()).all()
        )
        if cat_rows:
            chart2 = {"kind": "category", "title": "Doanh thu theo danh mục",
                      "labels": [n for n, _ in cat_rows], "values": [int(v or 0) for _, v in cat_rows]}
    return render_template(
        "admin/stats.html", days=days, labels=labels, revenues=revenues, chart2=chart2, total_revenue=total_revenue,
        total_orders=total_orders, avg_order_value=total_revenue // total_orders if total_orders else 0,
        total_profit=total_profit, margin=round(total_profit * 100 / costed_revenue, 1) if costed_revenue else None,
        top_products=top_products,
    )


@report_bp.route("/ban-hang")
@login_required
@permission_required("report.view")
def sales():
    start_dt, end_dt, start, end = _range()
    rows_q = (
        db.session.query(Category.name, func.sum(OrderItem.quantity),
                         func.sum(OrderItem.price * OrderItem.quantity), _profit_expr())
        .join(Product, Product.id == OrderItem.product_id).join(Category, Category.id == Product.category_id)
        .join(Order, Order.id == OrderItem.order_id)
        .filter(Order.created_at >= start_dt, Order.created_at < end_dt, Order.status != "cancelled")
        .group_by(Category.name).order_by(func.sum(OrderItem.price * OrderItem.quantity).desc()).all()
    )
    per_product = (
        db.session.query(OrderItem.product_name, func.sum(OrderItem.quantity),
                         func.sum(OrderItem.price * OrderItem.quantity), _profit_expr())
        .join(Order, Order.id == OrderItem.order_id)
        .filter(Order.created_at >= start_dt, Order.created_at < end_dt, Order.status != "cancelled")
        .group_by(OrderItem.product_name).order_by(func.sum(OrderItem.price * OrderItem.quantity).desc()).all()
    )
    rows = [[name, int(q or 0), format_vnd(rev or 0), format_vnd(pr or 0)] for name, q, rev, pr in per_product]
    totals = ["Tổng", sum(int(r[1] or 0) for r in per_product), format_vnd(sum(r[2] or 0 for r in per_product)),
              format_vnd(sum(r[3] or 0 for r in per_product))]
    cat_note = "Theo danh mục: " + "; ".join(f"{n}: {format_vnd(rev or 0)}" for n, _, rev, _ in rows_q) if rows_q else None
    note = ((cat_note + ". ") if cat_note else "") + "Lợi nhuận gộp chỉ tính các dòng đã có giá vốn; không tính đơn đã hủy."
    return _render_table("Báo cáo bán hàng theo sản phẩm", ["Sản phẩm", "Số lượng bán", "Doanh thu", "Lợi nhuận gộp"],
                         rows, totals, start, end, note)


@report_bp.route("/nhap-hang")
@login_required
@permission_required("report.view")
def imports():
    start_dt, end_dt, start, end = _range()
    lines = (
        db.session.query(PhieuNhap.code, PhieuNhap.received_at, Supplier.name, Product.name,
                         ChiTietPhieuNhap.received_quantity, ChiTietPhieuNhap.import_price)
        .join(ChiTietPhieuNhap, ChiTietPhieuNhap.receipt_id == PhieuNhap.id)
        .join(Supplier, Supplier.id == PhieuNhap.supplier_id).join(Product, Product.id == ChiTietPhieuNhap.product_id)
        .filter(PhieuNhap.status == "completed", PhieuNhap.received_at >= start_dt, PhieuNhap.received_at < end_dt)
        .order_by(PhieuNhap.received_at.desc()).all()
    )
    rows = [[c, r.strftime("%d/%m/%Y"), s, p, q or 0, format_vnd(pr), format_vnd((q or 0) * pr)] for c, r, s, p, q, pr in lines]
    totals = ["Tổng", "", "", "", sum(l[4] or 0 for l in lines), "", format_vnd(sum((l[4] or 0) * l[5] for l in lines))]
    return _render_table("Báo cáo nhập hàng", ["Mã phiếu", "Ngày nhập", "Nhà cung cấp", "Sản phẩm", "SL nhập", "Giá nhập", "Thành tiền"],
                         rows, totals, start, end, "Chỉ tính phiếu đã ghi nhận nhập kho.")


@report_bp.route("/xuat-hang")
@login_required
@permission_required("report.view")
def exports():
    """Xuất hàng = số lượng đã bán ra (online + tại quầy) trong kỳ, kèm tồn kho hiện tại."""
    start_dt, end_dt, start, end = _range()
    lines = (
        db.session.query(Product.id, Product.name, func.sum(OrderItem.quantity))
        .join(OrderItem, OrderItem.product_id == Product.id).join(Order, Order.id == OrderItem.order_id)
        .filter(Order.created_at >= start_dt, Order.created_at < end_dt, Order.status != "cancelled")
        .group_by(Product.id, Product.name).order_by(func.sum(OrderItem.quantity).desc()).all()
    )
    stock_by_id = dict(db.session.query(Product.id, Product.stock).filter(Product.id.in_([l[0] for l in lines])).all()) if lines else {}
    channel = dict(db.session.query(Order.channel, func.count(Order.id))
                   .filter(Order.created_at >= start_dt, Order.created_at < end_dt, Order.status != "cancelled")
                   .group_by(Order.channel).all())
    rows = [[n, int(q or 0), stock_by_id.get(pid, 0)] for pid, n, q in lines]
    totals = ["Tổng", sum(r[1] for r in rows), ""]
    note = f"Số đơn xuất: {channel.get('online', 0)} đơn online, {channel.get('counter', 0)} đơn tại quầy. Không tính đơn đã hủy."
    return _render_table("Báo cáo xuất hàng", ["Sản phẩm", "Số lượng xuất", "Tồn kho hiện tại"], rows, totals, start, end, note)


@report_bp.route("/nhan-vien")
@login_required
@permission_required("staff.performance")
def staff_performance():
    start_dt, end_dt, start, end = _range()
    staff_q = User.query.filter(User.role.in_(["staff", "manager"]))
    if current_branch_id() is not None:
        staff_q = staff_q.filter(User.branch_id == current_branch_id())
    staff = staff_q.order_by(User.full_name).all()
    rows = []
    for u in staff:
        base = Order.query.filter(Order.handled_by_id == u.id, Order.handled_at >= start_dt, Order.handled_at < end_dt)
        handled = base.count()
        completed = base.filter(Order.status == "completed").count()
        cancelled = base.filter(Order.status == "cancelled").count()
        counter = base.filter(Order.channel == "counter").count()
        revenue = db.session.query(func.sum(Order.total_amount)).filter(
            Order.handled_by_id == u.id, Order.handled_at >= start_dt, Order.handled_at < end_dt,
            Order.status == "completed").scalar() or 0
        receipts_done = PhieuNhap.query.filter(PhieuNhap.received_by_id == u.id, PhieuNhap.status == "completed",
                                               PhieuNhap.received_at >= start_dt, PhieuNhap.received_at < end_dt).count()
        requests_done = Order.query.filter(Order.request_handled_by_id == u.id, Order.request_at >= start_dt,
                                           Order.request_at < end_dt).count()
        rate = f"{completed * 100 // handled}%" if handled else "—"
        rows.append([u.full_name, u.role_label, handled, completed, cancelled, rate, counter,
                     format_vnd(revenue), receipts_done, requests_done])
    return _render_table(
        "Hiệu suất làm việc của nhân viên",
        ["Nhân viên", "Vai trò", "Đơn xử lý", "Hoàn thành", "Đã hủy", "Tỉ lệ hoàn thành", "Bán tại quầy",
         "Doanh thu đơn hoàn thành", "Phiếu nhập đã ghi nhận", "Yêu cầu đổi/hủy đã xử lý"],
        rows, None, start, end, "Tính theo thời điểm nhân viên xử lý đơn gần nhất.")
