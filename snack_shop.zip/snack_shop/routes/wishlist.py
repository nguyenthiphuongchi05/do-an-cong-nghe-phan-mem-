from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user

from extensions import db
from models import Wishlist, Product

wishlist_bp = Blueprint("wishlist", __name__, url_prefix="/yeu-thich")


@wishlist_bp.route("/")
@login_required
def list_wishlist():
    items = (
        Wishlist.query.filter_by(user_id=current_user.id)
        .join(Product)
        .order_by(Wishlist.created_at.desc())
        .all()
    )
    return render_template("wishlist/list.html", items=items)


@wishlist_bp.route("/toggle/<int:product_id>", methods=["POST"])
@login_required
def toggle(product_id):
    product = Product.query.get_or_404(product_id)
    existing = Wishlist.query.filter_by(user_id=current_user.id, product_id=product.id).first()

    if existing:
        db.session.delete(existing)
        db.session.commit()
        flash(f"Đã bỏ '{product.name}' khỏi danh sách yêu thích.", "info")
    else:
        db.session.add(Wishlist(user_id=current_user.id, product_id=product.id))
        db.session.commit()
        flash(f"Đã thêm '{product.name}' vào danh sách yêu thích.", "success")

    return redirect(request.referrer or url_for("product.list_products"))
