"""Chuyển hàng giữa các chi nhánh (Quản lý), có bước xác nhận nhận hàng.

Gửi: trừ kho chi nhánh gửi, phiếu ở trạng thái "đang chuyển".
Nhận: chi nhánh nhận xác nhận -> cộng kho chi nhánh nhận.
Hủy: chi nhánh gửi thu hồi hoặc chi nhánh nhận từ chối -> hoàn lại kho chi nhánh gửi.
Mỗi bước chuyển trạng thái bằng UPDATE có điều kiện (status = 'in_transit') nên không bị xử lý 2 lần khi bấm đồng thời.
"""
from datetime import datetime

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from sqlalchemy import update as sa_update

from extensions import db
from models import ChiNhanh, ChuyenKho, Product
from utils.audit import log_event
from utils.branch import write_branch_id, current_branch_id
from utils.decorators import permission_required
from utils.inventory import deduct_stock, add_stock

transfer_bp = Blueprint("transfer", __name__)


def _claim(transfer, new_status, note=None):
    """Chuyển phiếu từ 'đang chuyển' sang trạng thái mới; trả về True nếu mình là người xử lý trước."""
    res = db.session.execute(
        sa_update(ChuyenKho).where(ChuyenKho.id == transfer.id, ChuyenKho.status == "in_transit")
        .values(status=new_status, handled_by_id=current_user.id, handled_at=datetime.utcnow(), response_note=note))
    return res.rowcount == 1


@transfer_bp.route("/admin/chuyen-kho")
@login_required
@permission_required("stock.transfer")
def transfers():
    q = ChuyenKho.query
    bid = current_branch_id()
    if bid:  # chỉ thấy các lần chuyển đi hoặc đến chi nhánh của mình
        q = q.filter(db.or_(ChuyenKho.from_branch_id == bid, ChuyenKho.to_branch_id == bid))
    status = request.args.get("status", "")
    if status in ChuyenKho.STATUS_LABELS:
        q = q.filter(ChuyenKho.status == status)
    rows = q.order_by(ChuyenKho.created_at.desc(), ChuyenKho.id.desc()).limit(200).all()
    return render_template("admin/transfers.html", rows=rows, branch_id=bid, status=status)


@transfer_bp.route("/admin/chuyen-kho/tao", methods=["GET", "POST"])
@login_required
@permission_required("stock.transfer")
def create_transfer():
    src = write_branch_id()
    if current_branch_id() is None:
        flash("Hãy chọn chi nhánh gửi (thanh chọn chi nhánh phía trên) trước khi chuyển kho.", "warning")
        return redirect(url_for("transfer.transfers"))
    src_branch = db.session.get(ChiNhanh, src)
    dests = [b for b in ChiNhanh.query.filter_by(is_active=True).order_by(ChiNhanh.id).all() if b.id != src]
    products = [p for p in Product.query.order_by(Product.name).all() if p.stock_at(src) > 0]

    def page():
        return render_template("admin/transfer-form.html", src=src_branch, dests=dests, products=products)

    if request.method == "POST":
        try:
            product_id = int(request.form.get("product_id", ""))
            to_id = int(request.form.get("to_branch_id", ""))
            qty = int(request.form.get("quantity", ""))
        except ValueError:
            flash("Dữ liệu không hợp lệ.", "danger")
            return page()
        product = db.session.get(Product, product_id)
        dest = db.session.get(ChiNhanh, to_id)
        if not product or not dest or not dest.is_active or dest.id == src:
            flash("Sản phẩm hoặc chi nhánh nhận không hợp lệ.", "danger")
            return page()
        if qty <= 0:
            flash("Số lượng phải lớn hơn 0.", "danger")
            return page()
        if not deduct_stock(product.id, src, qty):
            db.session.rollback()
            flash(f"Chi nhánh {src_branch.name} không đủ hàng (còn {product.stock_at(src)}).", "danger")
            return page()
        today = datetime.utcnow().strftime("%Y%m%d")
        count = ChuyenKho.query.filter(ChuyenKho.code.like(f"CK{today}-%")).count()
        t = ChuyenKho(code=f"CK{today}-{count + 1:03d}", product_id=product.id, from_branch_id=src, to_branch_id=dest.id,
                      quantity=qty, note=(request.form.get("note") or "").strip()[:255] or None,
                      created_by_id=current_user.id, status="in_transit")
        db.session.add(t)
        db.session.commit()
        log_event("stock_transfer", f"Gửi {qty} x {product.name}: {src_branch.code} -> {dest.code} ({t.code})",
                  category="inventory")
        flash(f"Đã gửi {qty} x {product.name} sang {dest.name}. Chờ chi nhánh nhận xác nhận.", "success")
        return redirect(url_for("transfer.transfers"))
    return page()


def _load(transfer_id):
    t = db.session.get(ChuyenKho, transfer_id) or ChuyenKho.query.get_or_404(transfer_id)
    bid = current_branch_id()
    if bid and bid not in (t.from_branch_id, t.to_branch_id):
        from flask import abort
        abort(404)
    return t, bid


@transfer_bp.route("/admin/chuyen-kho/<int:transfer_id>/nhan", methods=["POST"])
@login_required
@permission_required("stock.transfer")
def receive_transfer(transfer_id):
    t, bid = _load(transfer_id)
    if bid != t.to_branch_id:
        flash("Chỉ chi nhánh nhận mới xác nhận được đã nhận hàng.", "danger")
    elif not _claim(t, "received"):
        db.session.rollback()
        flash("Phiếu này đã được xử lý rồi.", "warning")
    else:
        add_stock(t.product_id, t.to_branch_id, t.quantity)
        db.session.commit()
        log_event("stock_transfer_receive", f"Nhận {t.quantity} x {t.product.name} từ {t.from_branch.code} ({t.code})",
                  category="inventory")
        flash("Đã xác nhận nhận hàng, tồn kho chi nhánh đã được cộng.", "success")
    return redirect(url_for("transfer.transfers"))


@transfer_bp.route("/admin/chuyen-kho/<int:transfer_id>/huy", methods=["POST"])
@login_required
@permission_required("stock.transfer")
def cancel_transfer(transfer_id):
    t, bid = _load(transfer_id)
    reason = (request.form.get("reason") or "").strip()[:255]
    if bid not in (t.from_branch_id, t.to_branch_id):
        flash("Bạn không thuộc chi nhánh liên quan đến phiếu này.", "danger")
    elif bid == t.to_branch_id and not reason:
        flash("Từ chối nhận hàng cần ghi lý do.", "danger")
    elif not _claim(t, "cancelled", reason or "Chi nhánh gửi thu hồi"):
        db.session.rollback()
        flash("Phiếu này đã được xử lý rồi.", "warning")
    else:
        add_stock(t.product_id, t.from_branch_id, t.quantity)  # hoàn lại kho chi nhánh gửi
        db.session.commit()
        log_event("stock_transfer_cancel", f"Hủy chuyển kho {t.code} ({t.quantity} x {t.product.name}), hoàn kho {t.from_branch.code}",
                  category="inventory", level="warning")
        flash("Đã hủy phiếu chuyển kho, hàng được hoàn lại chi nhánh gửi.", "success")
    return redirect(url_for("transfer.transfers"))
