from datetime import datetime

from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user

from extensions import db
from models import Product, Category, Order, OrderItem, Review, Wishlist

product_bp = Blueprint("product", __name__, url_prefix="/san-pham")


def _get_wishlist_ids(user_id):
    return {
        w.product_id for w in Wishlist.query.filter_by(user_id=user_id).all()
    }


@product_bp.route("/")
def list_products():
    page = request.args.get("page", 1, type=int)
    category_slug = request.args.get("danh-muc")
    keyword = request.args.get("q", "").strip()

    query = Product.query

    if category_slug:
        category = Category.query.filter_by(slug=category_slug).first()
        if category:
            query = query.filter_by(category_id=category.id)

    if keyword:
        query = query.filter(Product.name.ilike(f"%{keyword}%"))

    pagination = query.order_by(Product.created_at.desc()).paginate(page=page, per_page=12, error_out=False)
    categories = Category.query.all()

    wishlist_ids = _get_wishlist_ids(current_user.id) if current_user.is_authenticated else set()

    return render_template(
        "product/list.html",
        products=pagination.items,
        pagination=pagination,
        categories=categories,
        current_category=category_slug,
        keyword=keyword,
        wishlist_ids=wishlist_ids,
    )


@product_bp.route("/goi-y")
def suggest():
    """Gợi ý sản phẩm dùng cho ô tìm kiếm tự động (autocomplete), trả về JSON."""
    keyword = request.args.get("q", "").strip()
    if len(keyword) < 2:
        return jsonify([])

    results = Product.query.filter(Product.name.ilike(f"%{keyword}%")).limit(8).all()
    return jsonify([
        {"name": p.name, "slug": p.slug, "price": p.final_price, "image": p.image_url}
        for p in results
    ])


@product_bp.route("/<slug>")
def detail(slug):
    product = Product.query.filter_by(slug=slug).first_or_404()
    related_products = (
        Product.query.filter_by(category_id=product.category_id)
        .filter(Product.id != product.id)
        .limit(4)
        .all()
    )

    reviews = (
        Review.query.filter_by(product_id=product.id)
        .order_by(Review.created_at.desc())
        .all()
    )

    user_review = None
    can_review = False
    is_wishlisted = False
    if current_user.is_authenticated:
        user_review = Review.query.filter_by(product_id=product.id, user_id=current_user.id).first()
        can_review = (
            db.session.query(OrderItem.id)
            .join(Order, Order.id == OrderItem.order_id)
            .filter(Order.user_id == current_user.id, OrderItem.product_id == product.id)
            .first()
            is not None
        )
        is_wishlisted = Wishlist.query.filter_by(user_id=current_user.id, product_id=product.id).first() is not None

    return render_template(
        "product/detail.html",
        product=product,
        related_products=related_products,
        reviews=reviews,
        user_review=user_review,
        can_review=can_review,
        is_wishlisted=is_wishlisted,
    )


@product_bp.route("/<slug>/danh-gia", methods=["POST"])
@login_required
def add_review(slug):
    product = Product.query.filter_by(slug=slug).first_or_404()
    rating = request.form.get("rating", type=int)
    comment = request.form.get("comment", "").strip()

    if not rating or rating < 1 or rating > 5:
        flash("Vui lòng chọn số sao từ 1 đến 5.", "danger")
        return redirect(url_for("product.detail", slug=slug))

    has_bought = (
        db.session.query(OrderItem.id)
        .join(Order, Order.id == OrderItem.order_id)
        .filter(Order.user_id == current_user.id, OrderItem.product_id == product.id)
        .first()
        is not None
    )
    if not has_bought:
        flash("Bạn cần mua sản phẩm này trước khi có thể đánh giá.", "warning")
        return redirect(url_for("product.detail", slug=slug))

    existing = Review.query.filter_by(product_id=product.id, user_id=current_user.id).first()
    if existing:
        existing.rating = rating
        existing.comment = comment
        existing.created_at = datetime.utcnow()
        flash("Đã cập nhật đánh giá của bạn.", "success")
    else:
        db.session.add(Review(product_id=product.id, user_id=current_user.id, rating=rating, comment=comment))
        flash("Cảm ơn bạn đã đánh giá sản phẩm!", "success")

    db.session.commit()
    return redirect(url_for("product.detail", slug=slug))
