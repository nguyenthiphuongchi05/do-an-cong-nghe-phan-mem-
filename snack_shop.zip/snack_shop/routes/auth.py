from datetime import datetime
from urllib.parse import urlparse

from datetime import timedelta
from flask import session, current_app, Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user

from extensions import db
from models import User
from models.user import ROLE_CUSTOMER
from forms.auth_form import LoginForm, RegisterForm, ProfileForm, ChangePasswordForm
from utils.audit import log_event
from utils.password_policy import is_default_or_weak

auth_bp = Blueprint("auth", __name__, url_prefix="/tai-khoan")


def _too_many_failures(email):
    """Đếm lần đăng nhập sai gần đây của email này (từ nhật ký) để chặn dò mật khẩu."""
    from models.system_log import NhatKyHeThong
    since = datetime.utcnow() - timedelta(minutes=current_app.config["LOGIN_LOCK_MINUTES"])
    n = NhatKyHeThong.query.filter(NhatKyHeThong.action == "login_failed", NhatKyHeThong.created_at >= since,
                                   NhatKyHeThong.user_email == (email or "").lower()[:120]).count()
    return n >= current_app.config["LOGIN_MAX_FAILURES"]


def _too_many_failures_from_ip():
    """Một địa chỉ IP sai quá nhiều lần (thử nhiều tài khoản) cũng bị chặn tạm."""
    from models.system_log import NhatKyHeThong
    from utils.audit import _client_ip
    ip = _client_ip()
    if not ip:
        return False
    since = datetime.utcnow() - timedelta(minutes=current_app.config["LOGIN_LOCK_MINUTES"])
    n = NhatKyHeThong.query.filter(NhatKyHeThong.action == "login_failed", NhatKyHeThong.created_at >= since,
                                   NhatKyHeThong.ip_address == ip).count()
    return n >= current_app.config["LOGIN_MAX_FAILURES_PER_IP"]


def _safe_next(target):
    """Chỉ cho phép chuyển hướng tới đường dẫn nội bộ (chống open redirect)."""
    if not target:
        return None
    parsed = urlparse(target)
    if parsed.scheme or parsed.netloc or not target.startswith("/") or target.startswith("//"):
        return None
    return target


@auth_bp.route("/dang-ky", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("home.index"))

    form = RegisterForm()
    if form.validate_on_submit():
        existing = User.query.filter_by(email=form.email.data).first()
        if existing:
            flash("Email này đã được đăng ký.", "danger")
            return render_template("auth/register.html", form=form)

        # Đăng ký công khai luôn tạo tài khoản KHÁCH HÀNG; chỉ admin mới cấp vai trò khác
        user = User(
            full_name=form.full_name.data,
            email=form.email.data,
            phone=form.phone.data,
            role=ROLE_CUSTOMER,
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        log_event("register", f"Khách hàng mới đăng ký: {user.email}", category="account", user=user)

        flash("Đăng ký thành công, mời bạn đăng nhập.", "success")
        return redirect(url_for("auth.login"))

    return render_template("auth/register.html", form=form)


def _complete_login(user, plain_password, next_page=None):
    """Hoàn tất đăng nhập (sau khi đã qua mật khẩu và, nếu có, mã 2 lớp)."""
    login_user(user)
    # nhắc đổi nếu đang dùng mật khẩu mặc định / yếu (hiện banner ở khu quản trị)
    if plain_password is not None and is_default_or_weak(plain_password):
        session["weak_password"] = True
    else:
        session.pop("weak_password", None)
    user.last_login_at = datetime.utcnow()
    db.session.commit()
    log_event("login", f"Đăng nhập thành công ({user.role_label})", category="auth", user=user)
    flash(f"Chào mừng trở lại, {user.full_name}!", "success")
    if next_page:
        return redirect(next_page)
    if user.is_backoffice:
        return redirect(url_for("admin.dashboard"))
    return redirect(url_for("home.index"))


def _login_failed(email, message="Email hoặc mật khẩu không đúng."):
    log_event("login_failed", f"Đăng nhập sai: {email}", category="auth", level="warning",
              email=(email or "").lower()[:120])
    flash(message, "danger")


def _resolve_login_name(value):
    """'quanlychuoi' -> 'quanlychuoi@snackshop.vn' (nếu có tài khoản đó); có '@' thì giữ nguyên."""
    value = (value or "").strip().lower()
    if "@" in value:
        return value
    hit = User.query.filter(User.email.like(value.replace("%", "").replace("_", "") + "@%")).all() if value else []
    exact = [u for u in hit if u.email.split("@")[0] == value]
    if len(exact) == 1:  # trùng nhiều tài khoản thì không đoán, bắt nhập đủ email
        return exact[0].email
    return value


@auth_bp.route("/dang-nhap", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("home.index"))

    form = LoginForm()
    if form.validate_on_submit():
        form.email.data = _resolve_login_name(form.email.data)
        if _too_many_failures(form.email.data) or _too_many_failures_from_ip():
            log_event("login_blocked", f"Đăng nhập bị chặn do sai nhiều lần: {form.email.data}", category="auth", level="warning")
            flash(f"Đăng nhập sai quá nhiều lần. Vui lòng thử lại sau {current_app.config['LOGIN_LOCK_MINUTES']} phút.", "danger")
            return render_template("auth/login.html", form=form), 429
        user = User.query.filter_by(email=form.email.data).first()
        if user and user.check_password(form.password.data):
            if user.is_locked:
                log_event("login_blocked", f"Tài khoản bị khóa cố đăng nhập: {user.email}",
                          category="auth", level="warning", user=user)
                flash("Tài khoản của bạn đã bị khóa. Vui lòng liên hệ quản trị viên.", "danger")
                return render_template("auth/login.html", form=form)

            next_page = _safe_next(request.args.get("next"))
            if user.totp_enabled and user.totp_secret:
                # bước 2: nhập mã 6 số; chưa đăng nhập cho tới khi mã đúng
                session["2fa"] = {"uid": user.id, "next": next_page, "pw": form.password.data,
                                  "exp": (datetime.utcnow() + timedelta(minutes=5)).timestamp()}
                return redirect(url_for("auth.two_factor"))
            return _complete_login(user, form.password.data, next_page)

        _login_failed(form.email.data)

    return render_template("auth/login.html", form=form)


@auth_bp.route("/xac-thuc-2-lop", methods=["GET", "POST"])
def two_factor():
    """Bước 2 khi đăng nhập: nhập mã từ ứng dụng xác thực."""
    from utils.totp import verify
    pending = session.get("2fa")
    if not pending or pending.get("exp", 0) < datetime.utcnow().timestamp():
        session.pop("2fa", None)
        flash("Phiên xác thực đã hết hạn, vui lòng đăng nhập lại.", "warning")
        return redirect(url_for("auth.login"))
    user = db.session.get(User, pending["uid"])
    if not user or user.is_locked or not user.totp_enabled:
        session.pop("2fa", None)
        return redirect(url_for("auth.login"))
    if request.method == "POST":
        if _too_many_failures(user.email) or _too_many_failures_from_ip():
            session.pop("2fa", None)
            flash("Nhập sai quá nhiều lần. Vui lòng thử lại sau ít phút.", "danger")
            return redirect(url_for("auth.login"))
        if verify(user.totp_secret, request.form.get("code", "")):
            session.pop("2fa", None)
            return _complete_login(user, pending.get("pw"), pending.get("next"))
        _login_failed(user.email, "Mã xác thực không đúng.")
    return render_template("auth/two_factor.html", email=user.email)


@auth_bp.route("/bao-mat-2-lop", methods=["GET", "POST"])
@login_required
def two_factor_setup():
    """Bật / tắt xác thực hai lớp cho chính mình."""
    from utils.totp import generate_secret, verify, otpauth_uri, pretty
    if current_user.totp_enabled:
        if request.method == "POST":
            if not current_user.check_password(request.form.get("password", "")) or \
                    not verify(current_user.totp_secret, request.form.get("code", "")):
                flash("Mật khẩu hoặc mã xác thực không đúng.", "danger")
            else:
                current_user.totp_enabled, current_user.totp_secret = False, None
                db.session.commit()
                log_event("2fa_disable", "Tắt xác thực hai lớp", category="account", level="warning")
                flash("Đã tắt xác thực hai lớp.", "info")
                return redirect(url_for("auth.profile"))
        return render_template("auth/two_factor_setup.html", enabled=True)

    secret = session.get("2fa_setup_secret")
    if not secret:
        secret = session["2fa_setup_secret"] = generate_secret()
    if request.method == "POST":
        if verify(secret, request.form.get("code", "")):
            current_user.totp_secret, current_user.totp_enabled = secret, True
            db.session.commit()
            session.pop("2fa_setup_secret", None)
            log_event("2fa_enable", "Bật xác thực hai lớp", category="account")
            flash("Đã bật xác thực hai lớp. Từ lần đăng nhập sau bạn cần nhập thêm mã từ ứng dụng.", "success")
            return redirect(url_for("auth.profile"))
        flash("Mã chưa đúng, hãy thử lại với mã hiện tại trong ứng dụng.", "danger")
    return render_template("auth/two_factor_setup.html", enabled=False, secret=pretty(secret),
                           uri=otpauth_uri(secret, current_user.email))


@auth_bp.route("/dang-xuat", methods=["POST"])
@login_required
def logout():
    log_event("logout", "Đăng xuất", category="auth")
    logout_user()
    flash("Bạn đã đăng xuất.", "info")
    return redirect(url_for("home.index"))


@auth_bp.route("/thong-tin", methods=["GET", "POST"])
@login_required
def profile():
    """Khách hàng (và mọi người dùng) chỉ xem/sửa thông tin của chính mình."""
    form = ProfileForm(obj=current_user)
    pw_form = ChangePasswordForm(prefix="pw")

    if form.submit.data and form.validate_on_submit():
        current_user.full_name = form.full_name.data.strip()
        current_user.phone = form.phone.data.strip()
        current_user.address = (form.address.data or "").strip() or None
        db.session.commit()
        log_event("profile_update", "Cập nhật thông tin cá nhân", category="account")
        flash("Đã cập nhật thông tin cá nhân.", "success")
        return redirect(url_for("auth.profile"))

    if pw_form.submit.data and pw_form.validate_on_submit():
        if not current_user.check_password(pw_form.current_password.data):
            flash("Mật khẩu hiện tại không đúng.", "danger")
        else:
            current_user.set_password(pw_form.new_password.data)
            db.session.commit()
            session.pop("weak_password", None)
            log_event("password_change", "Tự đổi mật khẩu", category="account")
            flash("Đã đổi mật khẩu.", "success")
            return redirect(url_for("auth.profile"))

    return render_template("auth/profile.html", form=form, pw_form=pw_form)
