"""Nhập hàng (PhieuNhap / ChiTietPhieuNhap) và tồn kho.

Quy trình: Quản lý lập phiếu + phân công nhân viên -> nhân viên ghi nhận số lượng thực nhận,
giá nhập, hạn dùng -> hệ thống cộng tồn kho và cập nhật giá vốn sản phẩm.
"""
from datetime import datetime, date, timedelta

from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from sqlalchemy import update as sa_update, or_

from extensions import db
from models import PhieuNhap, ChiTietPhieuNhap, Supplier, Product, User, Category
from utils.decorators import permission_required
from utils.audit import log_event
from utils.branch import write_branch_id, default_branch_id
from utils.inventory import add_stock
from sqlalchemy.exc import IntegrityError
from utils.helpers import generate_receipt_code
from utils.timeutil import vn_now

receipt_bp = Blueprint("receipt", __name__, url_prefix="/admin")


def _branch_staff(branch_id):
    """Nhân viên có thể được phân công nhận hàng: thuộc chi nhánh của phiếu (hoặc chưa gán chi nhánh)."""
    q = User.query.filter_by(role="staff", is_locked=False)
    if branch_id:
        q = q.filter(or_(User.branch_id == branch_id, User.branch_id.is_(None)))
    return q.order_by(User.full_name).all()


def _parse_date(value):
    try:
        return datetime.strptime(value, "%Y-%m-%d").date() if value else None
    except ValueError:
        return None


def _parse_int(value, default=None):
    try:
        return int(str(value).replace(".", "").replace(",", "").strip())
    except (TypeError, ValueError):
        return default


def _can_access(receipt):
    """Nhân viên chỉ xem/ghi nhận phiếu được phân công cho mình; quản lý xem tất cả."""
    return current_user.has_permission("receipt.manage") or receipt.assigned_to_id == current_user.id


# ---------- Danh sách / chi tiết ----------

@receipt_bp.route("/nhap-hang")
@login_required
@permission_required("receipt.view")
def receipts():
    status = request.args.get("status", "")
    query = PhieuNhap.query
    if not current_user.has_permission("receipt.manage"):
        query = query.filter(PhieuNhap.assigned_to_id == current_user.id)
    if status in ("pending", "completed", "cancelled"):
        query = query.filter(PhieuNhap.status == status)
    return render_template("receipts/list.html", receipts=query.order_by(PhieuNhap.created_at.desc()).limit(200).all(), status=status)


@receipt_bp.route("/nhap-hang/<code>")
@login_required
@permission_required("receipt.view")
def receipt_detail(code):
    receipt = PhieuNhap.query.filter_by(code=code).first_or_404()
    if not _can_access(receipt):
        abort(403)
    staff_list = _branch_staff(receipt.branch_id)
    return render_template("receipts/detail.html", receipt=receipt, staff_list=staff_list)


# ---------- Lập phiếu (quản lý) ----------

@receipt_bp.route("/nhap-hang/tao", methods=["GET", "POST"])
@login_required
@permission_required("receipt.manage")
def create_receipt():
    suppliers = Supplier.query.order_by(Supplier.name).all()
    products = Product.query.order_by(Product.name).all()
    staff_list = _branch_staff(write_branch_id())

    def _render():
        return render_template("receipts/form.html", suppliers=suppliers, products=products, staff_list=staff_list)

    if request.method == "POST":
        supplier_id = _parse_int(request.form.get("supplier_id"))
        assigned_to = _parse_int(request.form.get("assigned_to_id"))
        if not supplier_id or not db.session.get(Supplier, supplier_id):
            flash("Vui lòng chọn nhà cung cấp.", "danger")
            return _render()
        if assigned_to and not User.query.filter_by(id=assigned_to, role="staff").first():
            flash("Nhân viên được phân công không hợp lệ.", "danger")
            return _render()

        lines = {}
        for pid, qty, price, exp in zip(request.form.getlist("product_id"), request.form.getlist("quantity"),
                                        request.form.getlist("import_price"), request.form.getlist("expiry_date")):
            pid, qty, price = _parse_int(pid), _parse_int(qty), _parse_int(price, 0)
            if not pid or not qty or qty <= 0 or price < 0 or not db.session.get(Product, pid):
                continue
            lines[pid] = {"qty": lines.get(pid, {}).get("qty", 0) + qty, "price": price, "exp": _parse_date(exp)}
        if not lines:
            flash("Phiếu nhập cần ít nhất 1 dòng hàng hợp lệ (sản phẩm, số lượng > 0).", "danger")
            return _render()

        today_count = (db.session.query(db.func.count(PhieuNhap.id))
                       .filter(PhieuNhap.code.like("PN" + vn_now().strftime("%Y%m%d") + "%"))
                       .execution_options(skip_branch_scope=True).scalar())
        receipt = PhieuNhap(
            code="", supplier_id=supplier_id, created_by_id=current_user.id,
            branch_id=write_branch_id(),
            assigned_to_id=assigned_to or None, note=request.form.get("note", "").strip()[:500] or None,
        )
        for pid, data in lines.items():
            receipt.items.append(ChiTietPhieuNhap(product_id=pid, quantity=data["qty"],
                                                  import_price=data["price"], expiry_date=data["exp"]))
        # 2 người lập phiếu cùng lúc có thể đếm ra cùng số thứ tự -> thử số kế tiếp nếu mã bị trùng
        for n in range(10):
            receipt.code = generate_receipt_code(today_count + n)
            try:
                with db.session.begin_nested():
                    db.session.add(receipt)
                    db.session.flush()
                break
            except IntegrityError:
                if n == 9:
                    raise
        db.session.commit()
        log_event("receipt_create", f"Lập phiếu nhập {receipt.code} ({len(lines)} dòng), phân công: "
                  f"{receipt.assigned_to.full_name if receipt.assigned_to else 'chưa phân công'}", category="inventory")
        flash(f"Đã lập phiếu nhập {receipt.code}.", "success")
        return redirect(url_for("receipt.receipt_detail", code=receipt.code))
    return _render()


@receipt_bp.route("/nhap-hang/<code>/phan-cong", methods=["POST"])
@login_required
@permission_required("receipt.manage")
def assign_receipt(code):
    receipt = PhieuNhap.query.filter_by(code=code).first_or_404()
    staff_id = _parse_int(request.form.get("assigned_to_id"))
    staff = User.query.filter_by(id=staff_id, role="staff", is_locked=False).first() if staff_id else None
    if receipt.status != "pending":
        flash("Chỉ phân công lại được phiếu đang chờ nhập.", "danger")
    elif not staff:
        flash("Vui lòng chọn nhân viên hợp lệ.", "danger")
    else:
        receipt.assigned_to_id = staff.id
        db.session.commit()
        log_event("receipt_assign", f"Phân công phiếu {receipt.code} cho {staff.full_name}", category="inventory")
        flash(f"Đã phân công cho {staff.full_name}.", "success")
    return redirect(url_for("receipt.receipt_detail", code=code))


@receipt_bp.route("/nhap-hang/<code>/huy", methods=["POST"])
@login_required
@permission_required("receipt.manage")
def cancel_receipt(code):
    receipt = PhieuNhap.query.filter_by(code=code).first_or_404()
    if receipt.status != "pending":
        flash("Chỉ hủy được phiếu đang chờ nhập.", "danger")
    else:
        receipt.status = "cancelled"
        db.session.commit()
        log_event("receipt_cancel", f"Hủy phiếu nhập {receipt.code}", category="inventory", level="warning")
        flash("Đã hủy phiếu nhập.", "info")
    return redirect(url_for("receipt.receipt_detail", code=code))


# ---------- Ghi nhận nhập hàng (nhân viên được phân công) ----------

@receipt_bp.route("/nhap-hang/<code>/ghi-nhan", methods=["POST"])
@login_required
@permission_required("receipt.record")
def record_receipt(code):
    receipt = PhieuNhap.query.filter_by(code=code).first_or_404()
    if not _can_access(receipt):
        abort(403)
    if receipt.status != "pending":
        flash("Phiếu này không còn ở trạng thái chờ nhập.", "danger")
        return redirect(url_for("receipt.receipt_detail", code=code))

    total = 0
    for item in receipt.items:
        qty = _parse_int(request.form.get(f"received_{item.id}"), None)
        price = _parse_int(request.form.get(f"price_{item.id}"), item.import_price)
        if qty is None or qty < 0 or price < 0:
            db.session.rollback()
            flash("Số lượng thực nhận / giá nhập không hợp lệ.", "danger")
            return redirect(url_for("receipt.receipt_detail", code=code))
        item.received_quantity = qty
        item.import_price = price
        item.expiry_date = _parse_date(request.form.get(f"expiry_{item.id}")) or item.expiry_date
        total += qty * price
        if qty > 0:
            add_stock(item.product_id, receipt.branch_id or default_branch_id(), qty)
            db.session.execute(sa_update(Product).where(Product.id == item.product_id).values(cost_price=price))

    receipt.total_amount = total
    receipt.status = "completed"
    receipt.received_by_id = current_user.id
    receipt.received_at = datetime.utcnow()
    db.session.commit()
    log_event("receipt_record", f"Ghi nhận nhập kho phiếu {receipt.code}, tổng {total:,}đ", category="inventory")
    flash(f"Đã ghi nhận nhập kho phiếu {receipt.code}. Tồn kho đã được cập nhật.", "success")
    return redirect(url_for("receipt.receipt_detail", code=code))


# ---------- Tồn kho / tra cứu sản phẩm ----------

@receipt_bp.route("/ton-kho")
@login_required
@permission_required("inventory.view", "product.view")
def inventory():
    from routes.admin import _near_expiry_lines
    q = request.args.get("q", "").strip()
    filt = request.args.get("filter", "")
    category_id = _parse_int(request.args.get("category"))
    query = Product.query
    if q:
        query = query.filter(Product.name.ilike(f"%{q}%"))
    if category_id:
        query = query.filter(Product.category_id == category_id)
    if filt == "low":
        query = query.filter(Product.stock > 0, Product.stock <= Product.LOW_STOCK_THRESHOLD)
    elif filt == "out":
        query = query.filter(Product.stock <= 0)
    products = query.order_by(Product.stock, Product.name).all()

    near_expiry = _near_expiry_lines(30)
    today = vn_now().date()
    return render_template(
        "receipts/inventory.html", products=products, categories=Category.query.all(), q=q, filt=filt,
        category_id=category_id, near_expiry=near_expiry, today=today,
        low_count=Product.query.filter(Product.stock > 0, Product.stock <= Product.LOW_STOCK_THRESHOLD).count(),
        out_count=Product.query.filter(Product.stock <= 0).count(),
    )
